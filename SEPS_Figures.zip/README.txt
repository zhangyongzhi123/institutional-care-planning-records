SEPS independent figure files
Upload these as Figure files in Editorial Manager, together with the editable captions list.
Figure_1.png, Figure_2_matrices.docx, Figure_3.png ... Figure_8.png, Figure_S1.png (+ .svg), Figure_S2.png
Multi-panel figures are composited on a white canvas; original panels are preserved in source/.
Figures are also embedded in the Word manuscript; these files are the separate copies required by the guide.
