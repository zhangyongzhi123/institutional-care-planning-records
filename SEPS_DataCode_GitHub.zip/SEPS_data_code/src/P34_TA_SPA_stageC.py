# -*- coding: utf-8 -*-
"""TA-SPA-QMA-Protocol-v1.0 阶段C/C2：两柳州配置 × 六方法受控验证（GPT6.1 批准 2026-10-10）。

预注册协议（不得据结果调参）：
  配置：UPROUND/NEW/B=50M/b=0/v=13,033；TOTAL-PRESERVING/NEW/B=50M/b=0/v=12,625
  六方法（不得混名）：
    M1 Base-QMA            : max ΣQ̄·T
    M2 Original PA-QMA     : max ΣQ^PA(λ)·T（Policy34 冻结口径）
    M3 TA-SPA-global       : max {ΣQ̄·T + λΣω·w}，ω=π/Σπ（全角色归一化，阶段B原版）
    M4 TA-SPA-reachable    : ω^reach_jk=π_jk/Σ_{(j',k')∈R}π_j'k'，R={(j,k):∃a,χ_ajk=1}
                             max {ΣQ̄·T + λΣω^reach·w}
    M5 Target-constrained  : 两阶段词典序（原生 bound 报告）
        Stage1: max H(T)=Σω·w  → 记录 incumbent/bound/status/gap
        若 OPTIMAL(bound closed): Stage2: 固定 Σω·w=H1*, max ΣQ̄·T
        若 time-limit: Stage2 在 Stage1 incumbent 下界约束上运行，标注 bound-aware
        无法构造证据完整 Stage2 → NOT_CERTIFIED
    M6 Target-only diag.   : max Σω·w（λ无关，诊断性，不作优越基准）
  λ∈{0,1,2}（0 为 sanity check 退化验证；主分析用 λ∈{1,2}）
  冻结：Policy34输入hash、routing hash、候选池=NEW(BASE_15W_PER_BED,M40)、NEW项目集、
        合同、T^ref(正式E__Tref JSON)、R/V/π、h=0.5L(b=0)、预算50M、固定服务量、
        solver=HiGHS threads=1 gapRel=1e-4 TL=600s

禁止：修改Policy34原始结果；修改阶段A/B结果；据结果调参；只保留好配置；混名方法；
      回填论文；使用不同solver设置制造差异；将time-limit解称最优；将无incumbent标为不可行。

输出：experiments/Policy34_TA_SPA_QMA_v1/stage_C/
  solutions/   每方法完整解JSON（T_pos/y/z/S_raw/S_rec2dp/w_rec + metrics + ta_metrics + 审计）
  logs/       每方法原生日志
  results/    stage_C_summary.csv(22字段)、stage_C_constraints_audit.csv、
              pa_vs_G5E_reconciliation.csv、target_only_upper_bound_check.csv
  config/     stage_C_config_frozen.json
  code_snapshot/  P34_TA_SPA_stageC.py
  stage_C_audit.json、stage_C_manifest.csv、stage_C_claim_table.csv、
  stage_C_method_definition.json、README_STAGE_C.md

C1 全 PASS → 执行 C2；C2 完成后停在闸门等审查，不回填 Policy34。
"""
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pulp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from P34_common import (RUN_G5, ROOT as IMPL_ROOT, G2, code_hashes,
                        input_hashes, sha256_file, get_P_variant)
from P15_G4_joint_allocation import (evaluate, native_info, build_keys, CT)
import model_io  # noqa: E402
model_io.CARE_TYPES = ('NH', 'BK', 'WELLNESS')

OUT_C = IMPL_ROOT / 'experiments' / 'Policy34_TA_SPA_QMA_v1' / 'stage_C'
RUN_ID = f'TA_SPA_STAGE_C_C2__{time.strftime("%Y%m%d_%H%M%S")}'
B50M = 50_000_000.0
GAP = 1e-4
TL = 600
LAMS = [0.0, 1.0, 2.0]
DEMS = ('upround', 'total_preserving')
TOL_ABS = 1e-6 * B50M

# 方法名（不得混名）
M1 = 'M1_BASE_QMA'
M2 = 'M2_PA_QMA'
M3 = 'M3_TA_SPA_GLOBAL'
M4 = 'M4_TA_SPA_REACHABLE'
M5 = 'M5_TARGET_CONSTRAINED'
M6 = 'M6_TARGET_ONLY'
ALL_METHODS = [M1, M2, M3, M4, M5, M6]
LAM_METHODS = [M2, M3, M4]
NO_LAM_METHODS = [M1, M5, M6]

METHOD_DEFS = {
    M1: 'max ΣQ̄·T',
    M2: 'max ΣQ^PA(λ)·T，Q^PA=χ·Q̄·(1+λπ)/(1+λ)',
    M3: 'max {ΣQ̄·T + λΣω·w}，ω=π/Σπ（全角色归一化）',
    M4: 'max {ΣQ̄·T + λΣω^reach·w}，ω^reach=π/Σ_R π（R=可达角色，不可达ω=0）',
    M5: ('两阶段词典序：Stage1 max H(T)=Σω·w → '
         'Stage2 max ΣQ̄·T s.t. H(T)=H1*（bound closed时精确固定；'
         'time-limit用incumbent下界约束标注bound-aware）'),
    M6: 'max Σω·w（λ无关，诊断性，不作优越基准）',
}


# ========== 约束块（所有方法共用，逐字与 Stage B qpa_inner 一致） ==========

def build_base_prob(P, ext, keys, by_ak, by_jk, v_ref, budget):
    """构建基约束块。所有方法共用同一约束生成顺序。"""
    b_use = {kk: 0 for kk in P.b}          # 诊断口径 b:=0
    prob = pulp.LpProblem('stageC', pulp.LpMaximize)
    T = {e: pulp.LpVariable(f'T_{i}', lowBound=0, cat='Integer')
         for i, e in enumerate(keys)}
    yv = {a: pulp.LpVariable(f'y_{a}', cat='Binary') for a in P.facilities}
    zv = {pid: pulp.LpVariable(f'z_{pid}', cat='Binary') for pid in P.projects}
    S = {a: pulp.LpVariable(f'S_{a}', lowBound=0) for a in P.facilities}
    for pid, info in P.projects.items():
        prob += zv[pid] <= yv[info['facility']]
    for a in ext['new_facilities']:
        prob += yv[a] == zv[P.proj_of_fac[a][0]]
    for a in P.facilities:
        for k in CT:
            add = pulp.lpSum(P.deltaC.get((pid, k), 0) * zv[pid]
                             for pid in P.proj_of_fac.get(a, []))
            if (a, k) in by_ak or P.C0.get((a, k), 0) > 0:
                prob += pulp.lpSum(T[e] for e in by_ak.get((a, k), [])) <= \
                    P.C0.get((a, k), 0) + add
    for (j, k), es in by_jk.items():
        prob += pulp.lpSum(T[e] for e in es) >= b_use[(j, k)]
        prob += pulp.lpSum(T[e] for e in es) <= P.L[(j, k)]
    for e in keys:
        prob += T[e] <= P.L[(e[1], e[2])] * yv[e[0]]
    for a in P.facilities:
        rev = pulp.lpSum((P.p[(a, k)] - P.cst[(a, k)]) * T[e]
                         for k in CT for e in by_ak.get((a, k), []))
        fix = (P.F0[a] * yv[a]
               + pulp.lpSum((P.projects[pid]['private']
                             + ext['proj_fixed_f'].get(pid, 0.0))
                            * zv[pid] for pid in P.proj_of_fac.get(a, [])))
        prob += S[a] >= P.Pi0[a] * yv[a] + fix - rev
    prob += (pulp.lpSum(P.projects[pid]['K'] * zv[pid] for pid in P.projects)
             + 12.0 * pulp.lpSum(S.values())) <= float(budget)
    prob += pulp.lpSum(T.values()) == int(v_ref)
    return prob, T, yv, zv, S


def add_w_vars(prob, T, by_jk, omega_w, h_map):
    """添加饱和辅助变量 w（omega_w 中 ω>0 角色）。"""
    W = {}
    for r in omega_w:
        if omega_w[r] <= 0:
            continue
        W[r] = pulp.LpVariable(f'w_{r[0]}_{r[1]}', lowBound=0)
        es = by_jk.get(r, [])
        prob += W[r] <= pulp.lpSum(T[e] for e in es)     # w ≤ N(T)
        prob += W[r] <= h_map[r]                          # w ≤ h
    return W


# ========== 求解 ==========

def solve_single(P, ext, keys, by_ak, by_jk, method, lam, Qbar, QPA_lam,
                 omega_w, h_map, v_ref, budget, tl, gap):
    """单阶段方法 M1/M2/M3/M4/M6 求解。"""
    prob, T, yv, zv, S = build_base_prob(P, ext, keys, by_ak, by_jk, v_ref, budget)
    W = None
    if method == M1:
        prob += pulp.lpSum(Qbar[e] * T[e] for e in keys)
    elif method == M2:
        prob += pulp.lpSum(QPA_lam[e] * T[e] for e in keys)
    elif method == M3:
        W = add_w_vars(prob, T, by_jk, omega_w, h_map)
        prob += (pulp.lpSum(Qbar[e] * T[e] for e in keys)
                 + (lam or 0.0) * pulp.lpSum(omega_w[r] * W[r] for r in W))
    elif method == M4:
        W = add_w_vars(prob, T, by_jk, omega_w, h_map)
        prob += (pulp.lpSum(Qbar[e] * T[e] for e in keys)
                 + (lam or 0.0) * pulp.lpSum(omega_w[r] * W[r] for r in W))
    elif method == M6:
        W = add_w_vars(prob, T, by_jk, omega_w, h_map)
        prob += pulp.lpSum(omega_w[r] * W[r] for r in W)
    t0 = time.time()
    prob.solve(pulp.HiGHS(msg=0, timeLimit=tl, gapRel=gap, threads=1))
    dt = round(time.time() - t0, 1)
    ni = native_info(prob)
    st = {'Optimal': 'OPTIMAL', 'Not Solved': 'FEASIBLE_TIMEOUT',
          'Infeasible': 'PROVEN_INFEASIBLE', 'Unbounded': 'UNKNOWN'}.get(
        pulp.LpStatus[prob.status], 'UNKNOWN')
    try:
        _pv = pulp.value(prob.objective)
        obj_pulp = float(_pv) if _pv is not None else None
    except Exception:
        obj_pulp = None
    out = {'method': method, 'lam': lam, 'status': st, 'native': ni,
           'wall_s': dt, 'obj_pulp': obj_pulp, 'stages': 'single'}
    has_incumbent = ni.get('objective') is not None
    if st != 'OPTIMAL' and not has_incumbent:
        out.update({'T': None, 'y': None, 'z': None, 'S_raw': None, 'W': None})
        return out
    out['T'] = {e: int(round(T[e].value())) for e in keys}
    out['y'] = {a: int(round(yv[a].value())) for a in P.facilities}
    out['z'] = {pid: int(round(zv[pid].value())) for pid in P.projects}
    out['S_raw'] = {a: float(S[a].value()) for a in P.facilities}
    out['W'] = ({f'{r[0]}|{r[1]}': float(var.value()) for r, var in W.items()}
                if W else None)
    return out


def solve_m5(P, ext, keys, by_ak, by_jk, omega_w, h_map, v_ref, budget,
             tl, gap, Qbar):
    """M5 两阶段词典序（bound-aware）。"""
    result = {'method': M5, 'lam': None, 'stages': 'two_stage',
              'stage1': None, 'stage2': None, 'wall_s': 0.0}

    # Stage 1: max H(T) = Σω·w
    p1, T1, y1, z1, S1 = build_base_prob(P, ext, keys, by_ak, by_jk, v_ref, budget)
    W1 = add_w_vars(p1, T1, by_jk, omega_w, h_map)
    H_expr1 = pulp.lpSum(omega_w[r] * W1[r] for r in W1)
    p1 += H_expr1
    t0 = time.time()
    p1.solve(pulp.HiGHS(msg=0, timeLimit=tl, gapRel=gap, threads=1))
    dt1 = round(time.time() - t0, 1)
    ni1 = native_info(p1)
    st1 = pulp.LpStatus[p1.status]
    H1_incumbent = pulp.value(p1.objective) if p1.status == 1 else None
    H1_bound = ni1.get('bound')
    H1_gap = ni1.get('gap')
    stage1 = {
        'stage': 'stage1_max_H', 'status': st1, 'obj_milp': H1_incumbent,
        'native': ni1, 'wall_s': dt1,
        'H1_incumbent': H1_incumbent, 'H1_bound': H1_bound, 'H1_gap': H1_gap,
    }
    if H1_incumbent is not None:
        stage1['T'] = {e: int(round(T1[e].value())) for e in keys}
        stage1['y'] = {a: int(round(y1[a].value())) for a in P.facilities}
        stage1['z'] = {pid: int(round(z1[pid].value())) for pid in P.projects}
        stage1['S_raw'] = {a: float(S1[a].value()) for a in P.facilities}
        stage1['W'] = {f'{r[0]}|{r[1]}': float(var.value()) for r, var in W1.items()}
    result['stage1'] = stage1

    # Stage 2: max ΣQ̄·T s.t. H(T)=H1* 或 H(T)≥H1_incumbent（bound-aware）
    p2, T2, y2, z2, S2 = build_base_prob(P, ext, keys, by_ak, by_jk, v_ref, budget)
    W2 = add_w_vars(p2, T2, by_jk, omega_w, h_map)
    H_expr2 = pulp.lpSum(omega_w[r] * W2[r] for r in W2)
    p2 += pulp.lpSum(Qbar[e] * T2[e] for e in keys)

    stage2 = {'stage': 'stage2_max_baseQMA_s.t._H', 'native': None,
              'obj_milp': None, 'certification': None}
    bound_closed = (st1 == 'Optimal' and H1_bound is not None
                     and H1_gap is not None and H1_gap < 1e-9)
    if bound_closed:
        p2 += H_expr2 == H1_incumbent
        cert = 'BOUND_CLOSED_H_fixed_exact'
    elif H1_incumbent is not None:
        p2 += H_expr2 >= H1_incumbent - 1e-9
        cert = 'BOUND_AWARE_LEXICOGRAPHIC'
    else:
        stage2.update({'status': 'NOT_CERTIFIED', 'certification': 'NOT_CERTIFIED',
                       'note': 'Stage1 无 incumbent，无法构造 Stage2'})
        result['stage2'] = stage2
        result['wall_s'] = dt1
        return result

    t0 = time.time()
    p2.solve(pulp.HiGHS(msg=0, timeLimit=tl, gapRel=gap, threads=1))
    dt2 = round(time.time() - t0, 1)
    ni2 = native_info(p2)
    st2 = pulp.LpStatus[p2.status]
    obj2 = pulp.value(p2.objective) if p2.status == 1 else None
    stage2.update({
        'status': st2, 'obj_milp': obj2, 'native': ni2, 'wall_s': dt2,
        'certification': cert,
        'H1_incumbent': H1_incumbent, 'H1_bound': H1_bound, 'H1_gap': H1_gap,
    })
    if obj2 is not None:
        stage2['T'] = {e: int(round(T2[e].value())) for e in keys}
        stage2['y'] = {a: int(round(y2[a].value())) for a in P.facilities}
        stage2['z'] = {pid: int(round(z2[pid].value())) for pid in P.projects}
        stage2['S_raw'] = {a: float(S2[a].value()) for a in P.facilities}
        stage2['W'] = {f'{r[0]}|{r[1]}': float(var.value()) for r, var in W2.items()}
    result['stage2'] = stage2
    result['wall_s'] = round(dt1 + dt2, 1)
    return result


# ========== TA 指标 ==========

def ta_metrics_C(P, keys, omega_global, omega_reach, h_map, Tv, W_rec,
                 method, lam, Qbar, QPA_lam):
    """计算 TA 专属指标（同时报告 global 和 reachable 口径）。"""
    N = {}
    for e, t in Tv.items():
        if t:
            N[(e[1], e[2])] = N.get((e[1], e[2]), 0) + t
    roles = list(h_map)
    w_true = {r: min(N.get(r, 0), h_map[r]) for r in roles}

    H_T_global = sum(omega_global.get(r, 0) * w_true[r] for r in roles)
    H_up_global = sum(omega_global.get(r, 0) * h_map[r] for r in roles)
    G_h_global = sum(omega_global.get(r, 0) * max(0.0, h_map[r] - N.get(r, 0))
                     for r in roles)

    H_T_reach = sum(omega_reach.get(r, 0) * w_true[r] for r in roles)
    H_up_reach = sum(omega_reach.get(r, 0) * h_map[r] for r in roles)
    G_h_reach = sum(omega_reach.get(r, 0) * max(0.0, h_map[r] - N.get(r, 0))
                    for r in roles)

    met = [r for r in roles if N.get(r, 0) >= h_map[r] - 1e-9]
    covs = [N.get(r, 0) / h_map[r] for r in roles if h_map[r] > 1e-9]
    base_qma = float(sum(Qbar[e] * t for e, t in Tv.items() if t))

    w_get = lambda r: (W_rec or {}).get(f'{r[0]}|{r[1]}', 0.0)
    omega_for_method = (omega_reach if method == M4 else omega_global)
    target_reward_w = (sum(omega_for_method.get(r, 0) * w_get(r) for r in roles)
                       if W_rec is not None else None)

    # combined objective recomputed
    if method == M1:
        combined = base_qma
    elif method == M2:
        combined = float(sum(QPA_lam[e] * t for e, t in Tv.items() if t))
    elif method in (M3, M4):
        H_use = H_T_reach if method == M4 else H_T_global
        combined = base_qma + (lam or 0.0) * H_use
    elif method == M6:
        combined = H_T_global
    else:  # M5
        combined = None  # 词典序，非单一目标

    return {
        'sum_omega_global': sum(omega_global.values()),
        'max_omega_global': max(omega_global.values()) if omega_global else None,
        'min_omega_global': min(omega_global.values()) if omega_global else None,
        'sum_omega_reachable': sum(omega_reach.get(r, 0) for r in roles),
        'H_T_global': H_T_global, 'H_upper_global': H_up_global,
        'G_h_global': G_h_global,
        'H_T_reachable': H_T_reach, 'H_upper_reachable': H_up_reach,
        'G_h_reachable': G_h_reach,
        # 方法自身口径
        'H_T': (H_T_reach if method == M4 else H_T_global),
        'H_upper': (H_up_reach if method == M4 else H_up_global),
        'G_h': (G_h_reach if method == M4 else G_h_global),
        'n_targets_met': len(met),
        'n_targets_unmet': len(roles) - len(met),
        'worst_role_coverage': min(covs) if covs else None,
        'base_qma_score': base_qma,
        'target_reward_from_w_vars': target_reward_w,
        'combined_objective_recomputed': combined,
        'w_vs_minNh_max_abs_diff': (max([abs(w_get(r) - w_true[r])
                                         for r in roles if omega_for_method.get(r, 0) > 0]
                                        or [0.0]) if W_rec is not None else None),
    }


# ========== 约束审计（与 Stage B 一致） ==========

def constraints_audit(P, ext, keys, Tv, yv, zv, S_raw, v_ref, budget):
    viol = []
    N = {}
    cap = {}
    for e, t in Tv.items():
        a, j, k = e
        if t < 0:
            viol.append(('T_negative', str(e)))
        if t > P.L[(j, k)] * yv.get(a, 0) + 1e-9:
            viol.append(('T_le_Ly', str(e)))
        N[(j, k)] = N.get((j, k), 0) + t
        cap[(a, k)] = cap.get((a, k), 0) + t
    for (j, k), n in N.items():
        if n > P.L[(j, k)] + 1e-9:
            viol.append(('role_le_L', f'{j}|{k}'))
    for (a, k), s in cap.items():
        add = sum(P.deltaC.get((pid, k), 0) * zv.get(pid, 0)
                  for pid in P.proj_of_fac.get(a, []))
        if s > P.C0.get((a, k), 0) + add + 1e-9:
            viol.append(('facility_le_cap', f'{a}|{k}'))
    if sum(Tv.values()) != int(v_ref):
        viol.append(('sum_T_eq_v', str(sum(Tv.values()))))
    Kz = sum(P.projects[pid]['K'] * zv.get(pid, 0) for pid in P.projects)
    for a in P.facilities:
        rev = sum((P.p[(a, k)] - P.cst[(a, k)]) * t for (aa, j, k), t in Tv.items()
                  if aa == a)
        fix = (P.F0[a] * yv.get(a, 0)
               + sum((P.projects[pid]['private'] + ext['proj_fixed_f'].get(pid, 0.0))
                     * zv.get(pid, 0) for pid in P.proj_of_fac.get(a, [])))
        D = P.Pi0[a] * yv.get(a, 0) + fix - rev
        if S_raw[a] < D - TOL_ABS:
            viol.append(('IR_S_ge_D', a))
    spend_raw = Kz + 12.0 * sum(S_raw.values())
    if spend_raw > budget + TOL_ABS:
        viol.append(('budget', f'{spend_raw:.2f}'))
    return {'n_violations': len(viol), 'violations': viol[:20],
            'K_z_yuan': Kz, 'spend_first_year_with_rawS_yuan': round(spend_raw, 2),
            'all_pass': not viol}


# ========== Geo ==========

def build_geo():
    from run_E1_full import load_liuzhou
    _P, _c, fcoords, _d, _m = load_liuzhou(use_osm=True)
    geo = {a: {'lon': fcoords[a][0], 'lat': fcoords[a][1]} for a in fcoords}
    sites_df = pd.read_excel(G2 / 'candidate_sites.xlsx', sheet_name='candidate_sites',
                             dtype={'township_code': str})
    for r in sites_df.itertuples():
        geo[f'NEW_{r.site_id}'] = {'lon': float(r.lon), 'lat': float(r.lat),
                                   'district': r.district_name, 'site_type': 'PLANNING_PROXY'}
    return geo


# ========== Main ==========

def main():
    for sub in ('solutions', 'logs', 'results', 'config', 'code_snapshot'):
        (OUT_C / sub).mkdir(parents=True, exist_ok=True)

    # 代码快照
    shutil.copy2(Path(__file__), OUT_C / 'code_snapshot' / 'P34_TA_SPA_stageC.py')

    # 冻结配置
    code = code_hashes()
    code['P34_TA_SPA_stageC.py'] = sha256_file(Path(__file__))
    snap = {
        'run_id': RUN_ID, 'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'protocol': 'TA-SPA-QMA-Protocol-v1.0', 'stage': 'C/C2',
        'authorization': ('GPT6.1 批准 2026-10-10：阶段C 第三层方法贡献受控验证。'
                          'C1 全 PASS → C2 柳州两配置 × 六方法 × λ∈{0,1,2}。'
                          '禁止结果导向调参、混名、回填 Policy34、将 time-limit 解称最优'),
        'scope': {'demands': list(DEMS), 'project_set': 'NEW (BASE_15W_PER_BED, M40)',
                  'budget_yuan_first_year': B50M, 'b_mode': 'diagnostic (b:=0)',
                  'methods': ALL_METHODS, 'lams': LAMS,
                  'v_ref_source': '正式 run E__Tref__{dem}__B50M.json'},
        'method_definitions': METHOD_DEFS,
        'signal_choice': ('沿用 Policy34 正式参考分配 T^ref（E__Tref JSON）冻结 R/V/π'),
        'h_rule': 'h_jk = 0.5*L_jk（b=0）',
        'omega_rules': {
            'M3_global': 'ω=π/Σπ，归一化域 = L>0 全体角色',
            'M4_reachable': 'ω^reach=π/Σ_R π，R={(j,k):∃a,χ_ajk=1,L>0}；不可达ω=0',
            'M5_M6': '同 M3 global omega',
        },
        'solver': {'engine': f'PuLP {pulp.__version__} + HiGHS', 'threads': 1,
                   'gapRel': GAP, 'time_limit_s': TL, 'msg': 0},
        'code_sha256': code, 'inputs': input_hashes(),
        'tref_sha256': {dem: sha256_file(RUN_G5 / f'E__Tref__{dem}__B50M.json')
                        for dem in DEMS},
    }
    (OUT_C / 'config' / 'stage_C_config_frozen.json').write_text(
        json.dumps(snap, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    (OUT_C / 'stage_C_method_definition.json').write_text(
        json.dumps({'run_id': RUN_ID, 'methods': METHOD_DEFS,
                    'M4_reachable_set_def': 'R = {(j,k) : ∃a, χ_ajk=1, L_jk>0}',
                    'M5_two_stage': 'Stage1 max H(T) → Stage2 max ΣQ̄·T s.t. H=H1*',
                    'note': '不同方法 objective 使用各自定义，不直接比较异尺度 objective'},
                   ensure_ascii=False, indent=2), encoding='utf-8')

    geo = build_geo()
    sum_rows, ca_rows, pa_rows, to_rows = [], [], [], []
    frozen = {}
    n_solved = 0

    for dem in DEMS:
        P, ext = get_P_variant('NEW', dem)
        tref = json.loads((RUN_G5 / f'E__Tref__{dem}__B50M.json').read_text(encoding='utf-8'))
        v_ref = int(tref['v_ref'])
        keys = build_keys(P)
        keyset = set(keys)
        T_ref = {tuple(k.split('|')): int(v) for k, v in tref['T_ref'].items()}
        T_ref = {e: v for e, v in T_ref.items() if e in keyset}
        Q0 = {e: P.Q0(*e) for e in keys}
        delta0 = max(0.01, float(np.std(list(Q0.values()))))
        Qbar, _f = P.qma_Qbar(Q0, delta0)
        R_sig = P.R_signal(T_ref)
        V_sig = P.V_signal()
        pi_sig = P.pi_signal(R_sig, V_sig)

        # omega: global
        roles_all = [r for r in P.L if P.L[r] > 0]
        pi_sum = sum(pi_sig.get(r, 0.0) for r in roles_all)
        omega_global = {r: (pi_sig.get(r, 0.0) / pi_sum if pi_sum > 0
                            else 1.0 / len(roles_all)) for r in roles_all}

        # omega: reachable (M4)
        reachable_roles = set()
        for a in P.facilities:
            for j in P.communities:
                for k in CT:
                    if P.hard_chi(a, j, k)[0] and P.L.get((j, k), 0) > 0:
                        reachable_roles.add((j, k))
        pi_sum_reach = sum(pi_sig.get(r, 0.0) for r in reachable_roles)
        omega_reach = {r: (pi_sig.get(r, 0.0) / pi_sum_reach if pi_sum_reach > 0
                            else 0.0) for r in reachable_roles}
        for r in roles_all:
            if r not in reachable_roles:
                omega_reach[r] = 0.0

        h_map = {r: 0.5 * P.L[r] for r in roles_all}
        edge_roles = {(e[1], e[2]) for e in keys}
        omega_edge = {r: omega_global[r] for r in edge_roles}
        omega_reach_edge = {r: omega_reach.get(r, 0.0) for r in edge_roles}

        by_ak, by_jk = {}, {}
        for e in keys:
            by_ak.setdefault((e[0], e[2]), []).append(e)
            by_jk.setdefault((e[1], e[2]), []).append(e)
        QPAs = {lam: P.QPA(Qbar, pi_sig, lam) for lam in LAMS}

        frozen[dem] = {
            'v_ref': v_ref, 'delta0': round(delta0, 6),
            'n_keys': len(keys), 'n_roles_L_gt0': len(roles_all),
            'n_reachable_roles': len(reachable_roles),
            'n_edge_roles': len(edge_roles),
            'omega_mass_on_no_edge_roles': round(
                sum(omega_global[r] for r in roles_all if r not in edge_roles), 8),
            'omega_mass_on_unreachable_roles': round(
                sum(omega_global[r] for r in roles_all if r not in reachable_roles), 8),
            'sum_omega_global': 1.0,
            'sum_omega_reachable': round(sum(omega_reach[r] for r in reachable_roles), 8),
            'sum_omega_edge_global': round(sum(omega_edge.values()), 8),
            'sum_omega_edge_reachable': round(sum(omega_reach_edge.values()), 8),
            'max_omega_global': max(omega_global.values()),
            'min_omega_global': min(omega_global.values()),
            'max_omega_reachable': max(omega_reach[r] for r in reachable_roles) if reachable_roles else None,
            'min_omega_reachable': min(omega_reach[r] for r in reachable_roles) if reachable_roles else None,
            'H_upper_global': sum(omega_global[r] * h_map[r] for r in roles_all),
            'H_upper_reachable': sum(omega_reach[r] * h_map[r] for r in roles_all),
            'pi_unnormalized_sum': pi_sum,
            'pi_sum_reachable': pi_sum_reach,
            'reachable_equals_edge_roles': bool(reachable_roles == edge_roles),
        }

        for method in ALL_METHODS:
            lams = (LAMS if method in LAM_METHODS
                    else [None] if method in NO_LAM_METHODS else [None])
            for lam in lams:
                tag = (f'TA_C__{method}'
                       + (f'__lam{lam:g}' if lam is not None else '')
                       + f'__{dem}__B50M')
                print(f'--- {tag} ---', flush=True)

                if method == M5:
                    r = solve_m5(P, ext, keys, by_ak, by_jk, omega_edge,
                                 h_map, v_ref, B50M, TL, GAP, Qbar)
                    # 取 Stage2 解作为主解
                    s2 = r.get('stage2') or {}
                    s1 = r.get('stage1') or {}
                    T_sol = s2.get('T')
                    y_sol = s2.get('y')
                    z_sol = s2.get('z')
                    S_raw = s2.get('S_raw')
                    W_rec = s2.get('W')
                    ni = s2.get('native') or {}
                    st = s2.get('status', 'NOT_CERTIFIED')
                    obj_pulp = s2.get('obj_milp')
                    wall = r.get('wall_s', 0.0)
                    H1_inc = s1.get('H1_incumbent')
                    cert = s2.get('certification')
                else:
                    omega_w = (omega_reach_edge if method == M4
                               else omega_edge)
                    r = solve_single(P, ext, keys, by_ak, by_jk, method, lam,
                                     Qbar, QPAs.get(lam), omega_w, h_map,
                                     v_ref, B50M, TL, GAP)
                    T_sol = r.get('T')
                    y_sol = r.get('y')
                    z_sol = r.get('z')
                    S_raw = r.get('S_raw')
                    W_rec = r.get('W')
                    ni = r.get('native', {})
                    st = r.get('status', 'UNKNOWN')
                    obj_pulp = r.get('obj_pulp')
                    wall = r.get('wall_s', 0.0)
                    H1_inc = None
                    cert = None

                has_incumbent = T_sol is not None and obj_pulp is not None
                native_obj = ni.get('objective')
                native_bnd = ni.get('bound')
                native_gap = ni.get('gap')
                native_st = ni.get('model_status')

                wrapper_st = ('OPTIMAL' if st == 'Optimal'
                              else 'UNKNOWN_NO_INCUMBENT' if not has_incumbent
                              else 'FEASIBLE_TIMEOUT')

                rec = {
                    'protocol': 'TA-SPA-QMA-Protocol-v1.0', 'stage': 'C/C2',
                    'run_id': RUN_ID, 'config': tag, 'demand_set': dem,
                    'method': method, 'lam': lam, 'v_ref': v_ref,
                    'budget_yuan_first_year': B50M, 'b_mode': 'diagnostic',
                    'wrapper_status': wrapper_st, 'native_status': native_st,
                    'native_objective': native_obj, 'native_bound': native_bnd,
                    'native_gap': native_gap, 'wall_s': wall,
                    'obj_pulp': obj_pulp, 'certification': cert,
                    'H1_incumbent': H1_inc,
                    'solver': f'PuLP {pulp.__version__} + HiGHS threads=1 '
                              f'gapRel={GAP} TL={TL}s',
                }

                srow = {
                    'demand_set': dem, 'method': method,
                    'lambda': lam, 'v': v_ref,
                    'native_status': native_st,
                    'incumbent': (obj_pulp if obj_pulp is not None
                                  else (-native_obj if native_obj is not None else None)),
                    'dual_bound': (-native_bnd if native_bnd is not None else None),
                    'gap': native_gap, 'wall_s': wall,
                    'wrapper_status': wrapper_st,
                    'certification': cert,
                }

                if has_incumbent:
                    Tv = {e: t for e, t in T_sol.items()}
                    rec['metrics'] = evaluate(P, {'T': Tv, 'y': y_sol, 'z': z_sol},
                                              ext['proj_fixed_f'],
                                              ext['new_facilities'], tag, geo)
                    tam = ta_metrics_C(P, keys, omega_global, omega_reach, h_map,
                                       Tv, W_rec, method, lam, Qbar, QPAs.get(lam))
                    caud = constraints_audit(P, ext, keys, Tv, y_sol, z_sol,
                                              S_raw, v_ref, B50M)
                    rec['ta_metrics'] = tam
                    rec['constraints_audit'] = caud
                    rec['budget_first_year'] = {
                        'cap': B50M, 'K_z': caud['K_z_yuan'],
                        'min_subsidy_annual_12x': rec['metrics']['subsidy_annual'],
                        'spend_min_subsidy': rec['metrics']['spend_annual_accountingA'],
                        'spend_with_rawS': caud['spend_first_year_with_rawS_yuan'],
                    }
                    rec['T_pos'] = {f'{e[0]}|{e[1]}|{e[2]}': v
                                    for e, v in Tv.items() if v > 0}
                    rec['y'] = y_sol
                    rec['z'] = z_sol
                    rec['S_raw'] = S_raw
                    rec['S_rec2dp'] = {a: round(v, 2) for a, v in S_raw.items()}
                    rec['w_rec'] = W_rec
                    Kz = caud['K_z_yuan']

                    srow.update({
                        'H_T': tam['H_T'], 'H_upper': tam['H_upper'],
                        'G_h': tam['G_h'],
                        'H_T_global': tam['H_T_global'],
                        'H_T_reachable': tam['H_T_reachable'],
                        'G_h_global': tam['G_h_global'],
                        'G_h_reachable': tam['G_h_reachable'],
                        'n_targets_met': tam['n_targets_met'],
                        'n_targets_unmet': tam['n_targets_unmet'],
                        'worst_role_coverage': tam['worst_role_coverage'],
                        'base_qma_score': tam['base_qma_score'],
                        'SDM': rec['metrics'].get('SDM'),
                        'travel_p90': rec['metrics'].get('travel_p90'),
                        'burden_mean': rec['metrics'].get('burden_mean'),
                        'subsidy_annual': rec['metrics'].get('subsidy_annual'),
                        'spend_first_year': rec['metrics'].get('spend_annual_accountingA'),
                        'n_active_facilities': rec['metrics'].get('n_active_facilities'),
                        'buildK': rec['metrics'].get('buildK_one_time'),
                        'constraints_all_pass': caud['all_pass'],
                        'n_constraint_violations': caud['n_violations'],
                        'combined_objective': tam['combined_objective_recomputed'],
                        'obj_recompute_vs_native_diff': (
                            abs(tam['combined_objective_recomputed'] + native_obj)
                            if tam['combined_objective_recomputed'] is not None
                            and native_obj is not None else None),
                    })
                    ca_rows.append({
                        'config': tag, 'demand_set': dem, 'method': method,
                        'lam': lam, 'all_pass': caud['all_pass'],
                        'n_violations': caud['n_violations'],
                        'violations_head': ';'.join(
                            f'{c}:{e}' for c, e in caud['violations'][:5]),
                        'K_z_yuan': caud['K_z_yuan'],
                        'spend_first_year_with_rawS_yuan':
                            caud['spend_first_year_with_rawS_yuan']})

                    if method == M6:
                        to_rows.append({
                            'config': tag, 'demand_set': dem,
                            'H_T': tam['H_T_global'],
                            'H_upper': tam['H_upper_global'],
                            'reached_upper_bound': bool(
                                abs(tam['H_T_global'] - tam['H_upper_global']) < 1e-6),
                            'n_targets_unmet': tam['n_targets_unmet'],
                            'max_gap_Gh': tam['G_h_global'],
                            'worst_role_coverage': tam['worst_role_coverage'],
                            'claim_allowed': (
                                'reaches upper bound'
                                if abs(tam['H_T_global'] - tam['H_upper_global']) < 1e-6
                                else 'does NOT reach upper bound')})

                    if method == M2:
                        g5e = json.loads(
                            (RUN_G5 / f'E__lam{lam:g}__{dem}__B50M.json')
                            .read_text(encoding='utf-8'))
                        om = g5e['metrics']
                        t_old = g5e.get('T_pos', {})
                        t_new = rec['T_pos']
                        tdiff = sum(1 for kk in set(t_old) | set(t_new)
                                    if t_old.get(kk, 0) != t_new.get(kk, 0))
                        pa_rows.append({
                            'config': tag, 'demand_set': dem, 'lam': lam,
                            'g5e_QPA_objective': om.get('QPA_objective'),
                            'stageC_QPA_objective': tam['combined_objective_recomputed'],
                            'objective_abs_diff': abs(
                                tam['combined_objective_recomputed']
                                - om['QPA_objective']),
                            'g5e_native_status': (g5e.get('native', {}).get('model_status')
                                                  if g5e.get('native')
                                                  else g5e.get('inner_status')),
                            'stageC_native_status': native_st,
                            'T_pos_diff_entries': tdiff,
                            'g5e_SDM': om.get('SDM'),
                            'stageC_SDM': rec['metrics'].get('SDM'),
                            'verdict': ('OBJECTIVE_MATCH'
                                        if abs(tam['combined_objective_recomputed']
                                               - om['QPA_objective'])
                                        <= max(1e-6, 1e-4 * abs(om['QPA_objective']))
                                        else 'OBJECTIVE_DIFF_CHECK')})
                else:
                    # 无 incumbent
                    srow.update({
                        'H_T': None, 'H_upper': None, 'G_h': None,
                        'H_T_global': None, 'H_T_reachable': None,
                        'G_h_global': None, 'G_h_reachable': None,
                        'n_targets_met': None, 'n_targets_unmet': None,
                        'worst_role_coverage': None, 'base_qma_score': None,
                        'SDM': None, 'travel_p90': None, 'burden_mean': None,
                        'subsidy_annual': None, 'spend_first_year': None,
                        'n_active_facilities': None, 'buildK': None,
                        'constraints_all_pass': None, 'n_constraint_violations': None,
                        'combined_objective': None,
                        'obj_recompute_vs_native_diff': None,
                    })
                    if method == M6:
                        to_rows.append({
                            'config': tag, 'demand_set': dem,
                            'H_T': None, 'H_upper': None,
                            'reached_upper_bound': False,
                            'n_targets_unmet': None, 'max_gap_Gh': None,
                            'worst_role_coverage': None,
                            'claim_allowed': 'no incumbent — cannot claim'})
                    if method == M5 and H1_inc is not None:
                        srow['H_T'] = H1_inc
                        rec['H1_incumbent'] = H1_inc

                n_solved += 1
                rec['summary_row'] = srow
                (OUT_C / 'solutions' / f'{tag}.json').write_text(
                    json.dumps(rec, ensure_ascii=False, indent=2, default=str),
                    encoding='utf-8')
                (OUT_C / 'logs' / f'{tag}__native.json').write_text(
                    json.dumps({'config': tag, 'run_id': RUN_ID, 'wall_s': wall,
                                'native': ni, 'wrapper_status': wrapper_st,
                                'certification': cert,
                                'solver_settings': {'threads': 1, 'gapRel': GAP,
                                                     'timeLimit': TL, 'msg': 0}},
                               ensure_ascii=False, indent=2, default=str), encoding='utf-8')
                sum_rows.append(srow)
                print(f"    {st} obj={obj_pulp} gap={native_gap} "
                      f"v={srow.get('v')} {wall}s", flush=True)

        frozen[dem]['T_ref_sha256'] = snap['tref_sha256'][dem]

    # ========== 汇总 ==========
    sm = pd.DataFrame(sum_rows)
    # 主结果表 22 字段
    main_cols = ['demand_set', 'method', 'lambda', 'v', 'H_T', 'H_upper', 'G_h',
                 'n_targets_met', 'n_targets_unmet', 'worst_role_coverage',
                 'base_qma_score', 'SDM', 'travel_p90', 'burden_mean',
                 'subsidy_annual', 'spend_first_year', 'native_status',
                 'incumbent', 'dual_bound', 'gap', 'wall_s', 'constraints_all_pass']
    sm_main = sm.reindex(columns=main_cols)
    sm_main.to_csv(OUT_C / 'results' / 'stage_C_summary.csv', index=False,
                   encoding='utf-8-sig')
    sm.to_csv(OUT_C / 'results' / 'stage_C_summary_full.csv', index=False,
              encoding='utf-8-sig')

    if ca_rows:
        pd.DataFrame(ca_rows).to_csv(
            OUT_C / 'results' / 'stage_C_constraints_audit.csv',
            index=False, encoding='utf-8-sig')
    pd.DataFrame(pa_rows).to_csv(
        OUT_C / 'results' / 'pa_vs_G5E_reconciliation.csv', index=False,
        encoding='utf-8-sig')
    pd.DataFrame(to_rows).to_csv(
        OUT_C / 'results' / 'target_only_upper_bound_check.csv', index=False,
        encoding='utf-8-sig')

    # ========== Claim 表 ==========
    claim_rows = []
    for dem in DEMS:
        dem_rows = sm[sm['demand_set'] == dem]
        m1 = dem_rows[dem_rows['method'] == M1]
        m1_row = m1.iloc[0] if len(m1) > 0 else None
        for method in [M3, M4, M5]:
            for lam in [1.0, 2.0]:
                mr = dem_rows[(dem_rows['method'] == method)
                              & (dem_rows['lambda'] == lam)]
                if mr.empty:
                    continue
                mr = mr.iloc[0]
                if m1_row is None or mr['base_qma_score'] is None:
                    continue
                spend_inc = (mr['spend_first_year'] - m1_row['spend_first_year']
                             if mr['spend_first_year'] is not None
                             and m1_row['spend_first_year'] is not None else None)
                claim_rows.append({
                    'demand_set': dem, 'method': method, 'lambda': lam,
                    'H_T_vs_M1': (mr['H_T'] - m1_row['H_T']
                                  if mr['H_T'] is not None and m1_row['H_T'] is not None
                                  else None),
                    'G_h_vs_M1': (mr['G_h'] - m1_row['G_h']
                                  if mr['G_h'] is not None and m1_row['G_h'] is not None
                                  else None),
                    'base_qma_vs_M1': (mr['base_qma_score'] - m1_row['base_qma_score']
                                       if mr['base_qma_score'] is not None
                                       and m1_row['base_qma_score'] is not None
                                       else None),
                    'spend_inc_vs_M1': spend_inc,
                    'spend_inc_within_100k': (abs(spend_inc) <= 100_000
                                              if spend_inc is not None else None),
                    'SDM_vs_M1': (mr['SDM'] - m1_row['SDM']
                                  if mr['SDM'] is not None and m1_row['SDM'] is not None
                                  else None),
                    'travel_p90_vs_M1': (mr['travel_p90'] - m1_row['travel_p90']
                                         if mr['travel_p90'] is not None
                                         and m1_row['travel_p90'] is not None
                                         else None),
                    'burden_vs_M1': (mr['burden_mean'] - m1_row['burden_mean']
                                     if mr['burden_mean'] is not None
                                     and m1_row['burden_mean'] is not None
                                     else None),
                    'constraints_same': (mr['constraints_all_pass']
                                         and m1_row['constraints_all_pass']),
                    'H_T_not_decreased': (mr['H_T'] >= m1_row['H_T'] - 1e-9
                                          if mr['H_T'] is not None
                                          and m1_row['H_T'] is not None else None),
                    'G_h_not_increased': (mr['G_h'] <= m1_row['G_h'] + 1e-9
                                          if mr['G_h'] is not None
                                          and m1_row['G_h'] is not None else None),
                })
    pd.DataFrame(claim_rows).to_csv(
        OUT_C / 'stage_C_claim_table.csv', index=False, encoding='utf-8-sig')

    # ========== Audit ==========
    audit = {
        'run_id': RUN_ID, 'protocol': 'TA-SPA-QMA-Protocol-v1.0', 'stage': 'C/C2',
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'authorization': snap['authorization'],
        'c1_prerequisite': 'C1 ALL_PASS=True (2026-10-10)',
        'frozen_per_demand': frozen,
        'method_definitions': METHOD_DEFS,
        'n_solves': n_solved,
        'n_summary_rows': len(sum_rows),
        'main_table_fields': main_cols,
        'pa_vs_g5e_verdicts': pa_rows,
        'target_only_check': to_rows,
        'claim_table_rows': len(claim_rows),
        'solver': snap['solver'],
        'code_sha256': code, 'inputs': snap['inputs'],
        'note': ('阶段C/C2 完成。停在闸门等审查。'
                 '不回填 Policy34 正文/摘要/VII/Conclusion/Fig.8。'
                 '不自动扩大配置。不同方法 objective 不直接比较异尺度。'
                 'time-limit 返回解不称为精确最优。无 incumbent 不称为不可行。'),
    }
    (OUT_C / 'stage_C_audit.json').write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, default=str), encoding='utf-8')

    # ========== Manifest ==========
    inp_h = input_hashes()
    manifest_rows = []
    for fp in sorted(OUT_C.rglob('*')):
        if fp.is_file():
            rel = fp.relative_to(OUT_C).as_posix()
            manifest_rows.append({
                'relative_path': rel,
                'sha256': sha256_file(fp),
                'run_id': RUN_ID,
                'code_hash': code.get('P34_TA_SPA_stageC.py'),
                'input_hash': inp_h.get('input_sha256'),
                'size_bytes': fp.stat().st_size,
                'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
            })
    pd.DataFrame(manifest_rows).to_csv(
        OUT_C / 'stage_C_manifest.csv', index=False, encoding='utf-8-sig')

    # ========== README ==========
    n_inc = sum(1 for r in sum_rows if r.get('incumbent') is not None)
    n_no_inc = len(sum_rows) - n_inc
    (OUT_C / 'README_STAGE_C.md').write_text(f"""# TA-SPA-QMA 阶段C 报告（{RUN_ID}）

- 协议：TA-SPA-QMA-Protocol-v1.0；阶段：C/C2（第三层方法贡献受控验证）
- 授权：GPT6.1 批准 2026-10-10（预注册、独立、可撤回；禁止结果导向调参）
- C1 前提：ALL_PASS=True（2026-10-10，Example A 全枚举核验 M1-M6）
- 配置：UPROUND/NEW/B=50M/b=0/v={frozen['upround']['v_ref']}；
  TOTAL-PRESERVING/NEW/B=50M/b=0/v={frozen['total_preserving']['v_ref']}
- 六方法：M1 Base-QMA / M2 Original PA-QMA / M3 TA-SPA-global / M4 TA-SPA-reachable /
  M5 Target-constrained QMA（两阶段词典序）/ M6 Target-only diagnostic
- λ∈{{0,1,2}}（0 为 sanity check；主分析用 λ∈{{1,2}}）
- 参考信号：Policy34 正式 T^ref（E__Tref JSON）→ R/V/π
- 求解：HiGHS threads=1, gapRel={GAP}, TL={TL}s；共 {n_solved} 次求解
  （{n_inc} 个有 incumbent，{n_no_inc} 个无 incumbent）
- M4 reachable 角色：{frozen['upround']['n_reachable_roles']} 个（UPROUND），
  {frozen['total_preserving']['n_reachable_roles']} 个（TP）
  edge_roles = reachable: {frozen['upround']['reachable_equals_edge_roles']}
- M5 两阶段：Stage1 max H(T) → Stage2 max ΣQ̄·T s.t. H=H1*
  （bound closed 精确固定；time-limit 标注 bound-aware）

## 产出文件
- results/stage_C_summary.csv — 主结果表（22 字段）
- results/stage_C_summary_full.csv — 完整汇总（含 global/reachable 双口径 H_T/G_h）
- results/stage_C_constraints_audit.csv — 约束逐项审计
- results/pa_vs_G5E_reconciliation.csv — M2 PA-QMA 与 Policy34 G5-E 对账
- results/target_only_upper_bound_check.csv — M6 Target-only 上界核验
- stage_C_claim_table.csv — 预注册成功标准对照
- stage_C_method_definition.json — 六方法数学定义
- config/stage_C_config_frozen.json — 冻结配置快照
- stage_C_audit.json — 审计总报告
- stage_C_manifest.csv — 文件清单（逐文件 SHA-256）
- solutions/ — 每方法完整解 JSON
- logs/ — 每方法原生日志
- code_snapshot/ — 主脚本快照

## 停止规则
- 停在 C 阶段闸门，等待审查
- 不回填 Policy34 正文/摘要/VII/Conclusion/Fig.8
- 不自动扩大预算/候选池/λ网格
- 不将 time-limit 返回解称为精确最优
- 不将无 incumbent 标记为不可行
- 不同方法 objective 不直接比较异尺度
""", encoding='utf-8')

    print(f'\n阶段C/C2 完成：{n_solved} 次求解（{n_inc} incumbent, {n_no_inc} no-incumbent）')
    print(f'输出 -> {OUT_C}')
    print(f'主结果表 -> {OUT_C}/results/stage_C_summary.csv')
    print(f'Claim 表 -> {OUT_C}/stage_C_claim_table.csv')
    print('停在闸门等审查。不回填 Policy34。')


if __name__ == '__main__':
    main()
