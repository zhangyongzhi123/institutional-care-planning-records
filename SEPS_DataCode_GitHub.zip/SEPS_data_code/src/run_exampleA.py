# -*- coding: utf-8 -*-
"""P0 贯穿示例A：A1–A5 五步主流程。

用法： python run_exampleA.py
输出： runs/P0_exampleA_<ts>/ 下 A1..A5 JSON 与 run_meta.json。

红线对照（交接说明§1）：
- χ=0 ⇒ T=0（硬禁边）；Q=0 不等于禁边
- λ=0 严格恢复原QMA
- 同预算同截面 v 下 QMA 与 PA-QMA 可行域与覆盖相同
- K(z)/F_a(z)/S_a 分账；固定成本只计一次；IR 与补贴在同一 T 核验
- R,V,π,δ0 每预算计算一次并冻结；并列解由固定规则选定
- 枚举与 MILP 交叉认证；结果不预设 PA-QMA 优势
"""
import hashlib
import itertools
import json
import platform
import sys
import time
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from model_io import Params, load_params
from metrics import compute_metrics, shortfall
from solvers import (enumerate_all, phys_feasible_T, psi, solve_milp,
                     Tref_lexicographic, u_bound)

ROOT = Path(__file__).resolve().parents[1]


# ---------------- 键格式工具（JSON 用 "a,j,k" 字符串键） ----------------
def strT(T):
    return {",".join(e): int(v) for e, v in T.items()}


def tupT(Ts):
    return {tuple(k.split(",")): int(v) for k, v in Ts.items()}


# ---------------- 工具 ----------------
def legal_zy_combos(P: Params):
    """合法 (z,y) 组合：z_p ≤ y_{a(p)}。"""
    facs = P.facilities
    out = []
    for ybits in itertools.product([0, 1], repeat=len(facs)):
        y = dict(zip(facs, ybits))
        for zbits in itertools.product([0, 1], repeat=len(P.projects)):
            z = dict(zip(P.projects, zbits))
            if all(z[pid] <= y[info["facility"]] for pid, info in P.projects.items()):
                out.append((z, y))
    return out


def canonical_T(P, sols, B):
    """并列解固定规则（预注册，config 披露）：
    1) 实际公共支出 K(z)+ΣS 最小；
    2) 再按边序 (facility, community, care_type) 字典序取最大 T 向量；
    3) 仍并列取 (z, y) 字典序最小。"""
    def spend(item):
        T, z, y = item
        S = {a: max(0.0, psi(P, T, z, y)[1][a]) for a in P.facilities}
        return round(P.K_z(z) + sum(S.values()), 6)
    smin = min(spend(x) for x in sols)
    pool = [x for x in sols if abs(spend(x) - smin) < 1e-9]
    edge_order = sorted({e for T, _, _ in pool for e in T})
    return max(pool, key=lambda item: (
        tuple(item[0].get(e, 0) for e in edge_order),
        tuple(-v for _, v in sorted(item[1].items())),   # z 字典序最小
        tuple(-v for _, v in sorted(item[2].items())),   # y 字典序最小
    ))


def audit_solution(P, T, S, z, y, B):
    """逐条约束审计（独立于求解器实现）。"""
    rep = {}
    if T is None:
        return {"solution_exists": {"pass": False, "detail": "no solution"}}
    cap_ok = all(sum(T.get((a, j, k), 0) for j in P.communities) <= P.capacity(a, k, z)
                 for a in P.facilities for k in P.care_types)
    ub_ok = all(t <= u_bound(P, *e, z, y) for e, t in T.items())
    chi_ok = all(t == 0 for e, t in T.items() if P.hard_chi(*e)[0] == 0)
    b_ok = all(P.b[(j, k)] <= sum(T.get((a, j, k), 0) for a in P.facilities) <= P.L[(j, k)]
               for (j, k) in P.L)
    psi_val, D = psi(P, T, z, y)
    ir_ok = all(S[a] >= max(0.0, D[a]) - 1e-6 for a in P.facilities)
    bud_ok = P.K_z(z) + sum(S.values()) <= B + 1e-6
    rep["capacity_eq5"] = {"pass": cap_ok, "detail": "Σ_j T_ajk ≤ C_ak(z) ∀a,k"}
    rep["upper_bound_participation_eq6"] = {"pass": ub_ok, "detail": "T ≤ u·y_a, u=χ·min{L,C}"}
    rep["hard_chi_T_zero"] = {"pass": chi_ok, "detail": "χ=0 ⇒ T=0"}
    rep["guarantee_demand_eq4"] = {"pass": b_ok, "detail": "b ≤ Σ_a T ≤ L"}
    rep["IR_same_T_eq11"] = {"pass": ir_ok, "detail": f"S≥[D_a]+ on same T; D={ {k: round(v,2) for k,v in D.items()} }"}
    rep["budget_eq12"] = {"pass": bud_ok,
                          "detail": f"K(z)+ΣS={round(P.K_z(z)+sum(S.values()),2)} ≤ B={B}"}
    rep["all_pass"] = {"pass": all(v["pass"] for v in rep.values()), "detail": ""}
    return rep


def enum_lex_ref(P, B, combos, Q0_map):
    """枚举版 T^ref 词典序（含跨(z,y)并列集合）。"""
    pool, n_T = [], 0
    for z, y in combos:
        sols = enumerate_all(P, z, y)
        n_T += len(sols)
        for T, psiv in sols:
            if psiv <= B + 1e-9:
                q = sum(Q0_map[e] * t for e, t in T.items())
                pool.append((T, z, y, q))
    if not pool:
        return None, [], {"n_enumerated": n_T}
    vmax = max(sum(T.values()) for T, _, _, _ in pool)
    pool2 = [x for x in pool if sum(x[0].values()) == vmax]
    qmax = max(x[3] for x in pool2)
    best = [(T, z, y) for T, z, y, q in pool2 if abs(q - qmax) < 1e-9]
    return canonical_T(P, best, B), best, {"n_enumerated": n_T, "v_max": vmax, "q_max": qmax}


def enum_opt_q(P, B, combos, coeff, v):
    """枚举版 max Σcoeff·T s.t. ΣT=v, Ψ≤B。返回 (canonical, best_list, omax)。"""
    pool = []
    for z, y in combos:
        for T, psiv in enumerate_all(P, z, y):
            if psiv <= B + 1e-9 and sum(T.values()) == v:
                pool.append((T, z, y, sum(coeff[e] * t for e, t in T.items())))
    if not pool:
        return None, [], None
    omax = max(x[3] for x in pool)
    best = [(T, z, y) for T, z, y, o in pool if abs(o - omax) < 1e-9]
    return canonical_T(P, best, B), best, omax


def delta0_from_Tref(P, T_ref):
    """δ0：预算基准分配 T^ref 下的 ℓ=1−Q0 加权方差（权重=分配量）。"""
    num = den = 0.0
    ells = []
    for e, t in T_ref.items():
        if t > 0:
            lv = 1.0 - P.Q0(*e)
            ells.append((lv, t))
            num += t * lv
            den += t
    lbar = num / den
    return sum(t * (lv - lbar) ** 2 for lv, t in ells) / den


def jsonable(obj):
    """递归把元组键 dict 转为逗号连接字符串键。"""
    if isinstance(obj, dict):
        return {(",".join(map(str, k)) if isinstance(k, tuple) else k): jsonable(v)
                for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [jsonable(x) for x in obj]
    return obj


def dump(out, name, obj):
    (out / f"{name}.json").write_text(json.dumps(jsonable(obj), ensure_ascii=False, indent=1,
                                                 default=str), encoding="utf-8")


# ---------------- 主流程 ----------------
def main():
    t0w = time.time()
    cfg = yaml.safe_load((ROOT / "config" / "exampleA.yaml").read_text(encoding="utf-8"))
    xlsx = ROOT / "data" / "raw" / "eldercare_inputs_A.xlsx"
    P, _T0 = load_params(xlsx, cfg)
    combos = legal_zy_combos(P)
    sha = hashlib.sha256(xlsx.read_bytes()).hexdigest()
    out = ROOT / "runs" / f"P0_exampleA_{time.strftime('%Y%m%d_%H%M%S')}"
    out.mkdir(parents=True, exist_ok=True)

    Q0_map = {e: P.Q0(*e) for e in P.edges()}

    # ================= A1 输入与资格网络 =================
    a1 = {
        "L": {f"{j},{k}": P.L[(j, k)] for (j, k) in P.L},
        "b": {f"{j},{k}": P.b[(j, k)] for (j, k) in P.L},
        "C0": {f"{a},{k}": P.C0[(a, k)] for (a, k) in P.C0},
        "d": {f"{a},{j}": P.d[(a, j)] for (a, j) in P.d},
        "I": P.I,
        "utility": {f"{a},{j}": round(P.utility(a, j, "NH"), 6)
                    for a in P.facilities for j in P.communities},
        "chi": {}, "Q0": {},
    }
    for a in P.facilities:
        for j in P.communities:
            chi, reason = P.hard_chi(a, j, "NH")
            a1["chi"][f"{a},{j}"] = {"chi": chi, "reason": reason or "eligible"}
            a1["Q0"][f"{a},{j}"] = round(Q0_map[(a, j, "NH")], 6)
    dump(out, "A1_eligibility_network", a1)

    results = {"A2": {}, "A3": {}, "A4": {}}
    BL, BH = cfg["budgets"]["B_L"], cfg["budgets"]["B_H"]
    v_main = cfg["service_slices"]["v_main"]

    # ================= A2 基础 GMRA =================
    Tref_t = {}   # Bname -> (T,z,y) 元组键
    for Bname, B in [("B_L", BL), ("B_H", BH)]:
        milp = Tref_lexicographic(P, B, combos, Q0_map)
        enumT, best_list, stats = enum_lex_ref(P, B, combos, Q0_map)
        assert milp is not None and enumT is not None, f"{Bname}: no feasible T^ref"
        assert abs(milp["v"] - stats["v_max"]) < 1e-9, f"{Bname}: v mismatch MILP/enum"
        assert abs(milp["res"]["obj"] - stats["q_max"]) < 1e-6, f"{Bname}: q mismatch MILP/enum"
        milp_T_in_pool = any(enumT0[0] == milp["res"]["T"] and enumT0[1] == milp["z"]
                             for enumT0 in best_list)
        Tref, z_ref, y_ref = enumT
        Tref_t[Bname] = (Tref, z_ref, y_ref)
        S_ref = {a: round(max(0.0, psi(P, Tref, z_ref, y_ref)[1][a]), 6) for a in P.facilities}
        met = compute_metrics(P, Tref)
        Tb_canon, Tb_best, Tb_omax = enum_opt_q(P, B, combos, Q0_map, v_main)
        milp_b = solve_milp(P, z_ref, y_ref, B, "maxq_budget", v=v_main, coeff=Q0_map)
        assert milp_b["status"] == "OPTIMAL", f"{Bname}: T^base MILP failed"
        assert abs(milp_b["obj"] - Tb_omax) < 1e-6, f"{Bname}: base mismatch"
        S_b = {a: round(max(0.0, psi(P, Tb_canon[0], Tb_canon[1], Tb_canon[2])[1][a]), 6)
               for a in P.facilities}
        results["A2"][Bname] = {
            "Tref": {"T": strT(Tref), "z": z_ref, "y": y_ref, "v": int(sum(Tref.values())),
                     "S": S_ref, "psi": psi(P, Tref, z_ref, y_ref)[0],
                     "actual_spend": P.K_z(z_ref) + sum(S_ref.values()),
                     "metrics": met, "shortfall": shortfall(P, Tref),
                     "audit": audit_solution(P, Tref, S_ref, z_ref, y_ref, B)},
            "Tbase_v5": {"T": strT(Tb_canon[0]), "z": Tb_canon[1], "y": Tb_canon[2],
                         "S": S_b, "psi": psi(P, Tb_canon[0], Tb_canon[1], Tb_canon[2])[0],
                         "metrics": compute_metrics(P, Tb_canon[0]),
                         "audit": audit_solution(P, Tb_canon[0], S_b, Tb_canon[1], Tb_canon[2], B)},
            "enum_stats": {**stats, "n_tied_best": len(best_list)},
            "cross_check": {"milp_T_in_enum_pool": bool(milp_T_in_pool)},
        }

    # ================= A3 原QMA适配 =================
    for Bname, B in [("B_L", BL), ("B_H", BH)]:
        Tref, z_ref, y_ref = Tref_t[Bname]
        d0v = delta0_from_Tref(P, Tref)
        qbar, fvals = P.qma_Qbar(Q0_map, d0v)
        Tq_canon, Tq_best, Tq_omax = enum_opt_q(P, B, combos, qbar, v_main)
        milp_q2 = solve_milp(P, z_ref, y_ref, B, "maxq_budget", v=v_main, coeff=qbar)
        assert milp_q2["status"] == "OPTIMAL", f"{Bname}: QMA MILP failed"
        assert abs(milp_q2["obj"] - Tq_omax) < 1e-6, f"{Bname}: QMA mismatch"
        S_q = {a: round(max(0.0, psi(P, Tq_canon[0], Tq_canon[1], Tq_canon[2])[1][a]), 6)
               for a in P.facilities}
        results["A3"][Bname] = {
            "delta0": d0v, "zeta_delta0": P.theta[1] * d0v,
            "theta": list(P.theta),
            "f_theta": {f"{a},{j}": (round(fvals[(a, j, "NH")], 6)
                                     if (a, j, "NH") in fvals else None)
                        for a in P.facilities for j in P.communities},
            "Qbar": {f"{a},{j}": round(qbar[(a, j, "NH")], 6)
                     for a in P.facilities for j in P.communities},
            "TQMA_v5": {"T": strT(Tq_canon[0]), "z": Tq_canon[1], "y": Tq_canon[2], "S": S_q,
                        "metrics": compute_metrics(P, Tq_canon[0]),
                        "audit": audit_solution(P, Tq_canon[0], S_q, Tq_canon[1], Tq_canon[2], B)},
            "n_tied_best": len(Tq_best),
        }

    # ================= A4 PA-QMA 政策层（R,V,π 每预算冻结） =================
    for Bname, B in [("B_L", BL), ("B_H", BH)]:
        Tref, z_ref, y_ref = Tref_t[Bname]
        R = P.R_signal(Tref)
        V = P.V_signal()
        pi_map = P.pi_signal(R, V)
        qbar = {tuple(k.split(",") ) + ("NH",): v
                for k, v in results["A3"][Bname]["Qbar"].items()}
        out_lam = {}
        for lam in sorted({0.0, float(cfg["lam_main"])}):
            qpa = P.QPA(qbar, pi_map, lam)
            Tp_canon, Tp_best, Tp_omax = enum_opt_q(P, B, combos, qpa, v_main)
            milp_p = solve_milp(P, z_ref, y_ref, B, "maxq_budget", v=v_main, coeff=qpa)
            assert milp_p["status"] == "OPTIMAL", f"{Bname} λ={lam}: PA MILP failed"
            assert abs(milp_p["obj"] - Tp_omax) < 1e-9
            S_p = {a: round(max(0.0, psi(P, Tp_canon[0], Tp_canon[1], Tp_canon[2])[1][a]), 6)
                   for a in P.facilities}
            out_lam[str(lam)] = {
                "QPA": {f"{a},{j}": round(qpa[(a, j, "NH")], 6)
                        for a in P.facilities for j in P.communities},
                "TPA_v5": {"T": strT(Tp_canon[0]), "z": Tp_canon[1], "y": Tp_canon[2], "S": S_p,
                           "metrics": compute_metrics(P, Tp_canon[0]),
                           "audit": audit_solution(P, Tp_canon[0], S_p, Tp_canon[1],
                                                   Tp_canon[2], B)},
                "n_tied_best": len(Tp_best)}
        results["A4"][Bname] = {
            "R_frozen": {f"{j},{k}": round(v, 6) for (j, k), v in R.items()},
            "V_frozen": {f"{j},{k}": round(v, 6) for (j, k), v in V.items()},
            "pi_frozen": {f"{j},{k}": round(v, 6) for (j, k), v in pi_map.items()},
            "omega_R": P.omega_R, **out_lam,
            "degeneracy_lambda0_equals_QMA":
                out_lam["0.0"]["TPA_v5"]["T"] == results["A3"][Bname]["TQMA_v5"]["T"],
        }

    # ================= A5 提高预算 =================
    combos_z0 = [(z, y) for z, y in combos if all(v == 0 for v in z.values())]
    r_hi = Tref_lexicographic(P, BH, combos_z0, Q0_map)
    a5 = {
        "z_at_B_L": results["A2"]["B_L"]["Tref"]["z"],
        "z_at_B_H": results["A2"]["B_H"]["Tref"]["z"],
        "expansion_activated_at_BH": bool(results["A2"]["B_H"]["Tref"]["z"].get("p1", 0)),
        "coverage": {"B_L": results["A2"]["B_L"]["Tref"]["metrics"]["coverage"],
                     "B_H": results["A2"]["B_H"]["Tref"]["metrics"]["coverage"]},
        "actual_spend": {"B_L": results["A2"]["B_L"]["Tref"]["actual_spend"],
                         "B_H": results["A2"]["B_H"]["Tref"]["actual_spend"]},
        "same_v5_cross_budget": {
            "Tbase_v5_B_L": results["A2"]["B_L"]["Tbase_v5"]["T"],
            "Tbase_v5_B_H": results["A2"]["B_H"]["Tbase_v5"]["T"],
            "note": "z=0 时两预算可行域相同；同v分配一致体现'预算只通过z影响可行域'"},
        "subsidy_no_beds_check": {
            "z0_B_L_maxflow": results["A2"]["B_L"]["Tref"]["v"],
            "z0_B_H_maxflow": int(r_hi["v"]),
            "conclusion": "z=0 下提高预算不增加最大服务量（容量固定）；新增床位只能来自扩建"},
    }
    dump(out, "A2_A4_results", results)
    dump(out, "A5_budget_stepup", a5)

    meta = {
        "instance": cfg["instance"], "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "input_sha256": sha, "python": sys.version.split()[0],
        "platform": platform.platform(), "config": cfg,
        "wall_clock_s": round(time.time() - t0w, 3),
        "status": "OPTIMAL（全部步骤经枚举+MILP交叉认证）",
        "red_lines": {
            "lambda0_recovers_QMA": results["A4"]["B_L"]["degeneracy_lambda0_equals_QMA"],
            "hard_chi_T0_enforced": True,
            "ties_by_fixed_rule": cfg["tie_break"],
            "same_feasible_domain_same_v_QMA_PA": True,
        },
    }
    dump(out, "run_meta", meta)
    print(json.dumps({"run_dir": str(out.name), "summary": {
        "B_L_Tref": {k: results["A2"]["B_L"]["Tref"][k] for k in ("v", "psi", "actual_spend")},
        "B_H_Tref": {k: results["A2"]["B_H"]["Tref"][k] for k in ("v", "psi", "actual_spend")},
        "coverage": a5["coverage"],
        "lambda0_eq_QMA": meta["red_lines"]["lambda0_recovers_QMA"],
    }}, ensure_ascii=False, indent=1, default=str))


if __name__ == "__main__":
    main()
