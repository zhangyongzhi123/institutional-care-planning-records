# -*- coding: utf-8 -*-
"""构建柳州 eldercare_inputs.xlsx —— E1/E2 主实验唯一输入文件。

按 E1-E4阶段任务单_V2.md §1 逐条构建，5 个 sheet：
  communities, demand, facilities, capacity_price, travel_edges, projects, provenance

OSM 路网暂用大圆距离 ×1.25 ÷ 40km/h 作 fallback（93.91% 可达），
后续若装 osmnx 可替换。

用法： python make_inputs_liuzhou.py [--raw ..\..\..]
输出： data/raw/eldercare_inputs.xlsx + missing_fields_report.csv
"""
import argparse
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]   # TSMC/implementation
DATA_DIR = ROOT.parent.parent  # 实验/数据/


# ============================================================
#  原始文件路径
# ============================================================
def find_raw():
    """定位 8 个原始文件。"""
    files = {
        'demand': DATA_DIR / '12a423cd-96ad-42b9-9e97-0843686e7865-estimated_roles_1147.xlsx',
        'facilities': DATA_DIR / '柳州市各个行政区养老机构分布以及床位数量统计.xls',
        'price': DATA_DIR / '柳州市养老院各个类型收费标准范围.xlsx',
        'income': DATA_DIR / '柳州市各个行政区人均年收入.xls',
    }
    missing = [k for k, p in files.items() if not p.exists()]
    if missing:
        print(f'[WARN] 缺失原始文件: {missing}')
    return files


# ============================================================
#  1.1 communities —— 需求单元
# ============================================================
def load_district_income(raw):
    """解析收入表 → {区县名: 月收入(元)}。清洗隐形字符\\u200b/逗号/'约'前缀/'(预估)'后缀。"""
    import re
    d = pd.read_excel(raw['income'], header=None)

    def clean(x):
        m = re.search(r'\d+(?:\.\d+)?', str(x).replace('\u200b', '').replace(',', ''))
        return float(m.group()) if m else None

    inc = {}
    for i in range(1, len(d)):
        name = str(d.iloc[i, 0]).replace('\u200b', '').strip()
        val = clean(d.iloc[i, 1])
        if name and name != 'nan' and val:
            inc[name] = round(val / 12.0, 1)  # 年收入 → 月收入
    return inc


def build_communities(raw):
    d = pd.read_excel(raw['demand'])
    inc = load_district_income(raw)
    unmatched = sorted(set(d['所属区县']) - set(inc))
    if unmatched:
        print(f'  [WARN] 收入表未覆盖区县: {unmatched} → 用 4000 占位(披露)')
    rows = []
    for _, r in d.iterrows():
        dist = r['所属区县']
        iv = inc.get(dist)
        src = 'observed(区县2023城镇可支配收入/12)'
        if iv is None:
            iv = 4000.0
            src = 'placeholder(4000; 区县收入未匹配)'
        rows.append({
            'community_id': str(r['行政区划代码']),
            'name': r['名称'],
            'district_name': dist,
            'n65': int(r['估算65岁以上人口']),
            'income_value': iv,
            'income_source': src,
            'lon': float(r['经度']),
            'lat': float(r['纬度']),
            'provenance': 'n65=imputed(区县总量内最大余数法); coords=observed',
        })
    comm = pd.DataFrame(rows)
    print(f'  communities: {len(comm)} 行, n65合计={comm.n65.sum()}, '
          f'月收入范围=[{comm.income_value.min():.0f}, {comm.income_value.max():.0f}]')
    return comm


# ============================================================
#  1.2 demand —— 需求上界与最低保障
# ============================================================
TIER_MAP = {
    # (山区民族自治县 / 普通县 / 城区)
    '城中区': '城区', '鱼峰区': '城区', '柳北区': '城区', '柳南区': '城区',
    '柳东新区': '城区', '柳江区': '普通县', '柳城县': '普通县', '鹿寨县': '普通县',
    '融安县': '普通县',
    '融水苗族自治县': '山区', '三江侗族自治县': '山区',
}
TIER_RHO = {'城区': 0.20, '普通县': 0.35, '山区': 0.50}


def build_demand(communities, demand_rate=0.05):
    """需求上界 L = ceil(r * n65 * s_k)，s=(0.50基本, 0.30护理, 0.20康养)；
       保障 b 仅对基本床，按区域分档；护理/康养 b=0。"""
    s = {'basic': 0.50, 'care': 0.30, 'wellness': 0.20}
    rows = []
    for _, c in communities.iterrows():
        jid = c['community_id']
        n65 = c['n65']
        tier = TIER_MAP.get(c['district_name'], '普通县')
        rho = TIER_RHO[tier]
        for k, sk in s.items():
            L = math.ceil(demand_rate * n65 * sk)
            # 保障 b: 仅对 basic 床
            if k == 'basic':
                b = math.ceil(rho * L) if L > 0 else 0
            else:
                b = 0
            rows.append({
                'community_id': jid, 'care_type': k, 'n65': n65,
                'L': L, 'guarantee_b': b,
                'tier': tier, 'rho': rho,
                'demand_rate': demand_rate, 'source_or_scenario': 'scenario',
            })
    dm = pd.DataFrame(rows)
    # 阻断检查: b <= L
    bad = dm[dm['guarantee_b'] > dm['L']]
    if len(bad):
        print(f'  [BLOCK] b>L 违规 {len(bad)} 行!')
        sys.exit(1)
    print(f'  demand: {len(dm)} 行, 保障b合计={dm.guarantee_b.sum()}, 保障率={dm.guarantee_b.sum()/dm[dm.care_type=="basic"].L.sum():.3f}')
    return dm


# ============================================================
#  1.3 facilities —— 机构（解析分段格式）
# ============================================================
def build_facilities(raw):
    d = pd.read_excel(raw['facilities'], header=None)
    rows = []
    for i in range(1, len(d)):
        row = d.iloc[i]
        v0 = str(row.iloc[0])
        if '部分' in v0 and '家' in v0:
            continue
        if v0 == '序号':
            continue
        try:
            int(v0)
        except:
            continue
        if pd.isna(row.iloc[1]):
            continue
        beds = int(row.iloc[5]) if not pd.isna(row.iloc[5]) else 0
        rows.append({
            'facility_id': f'F{int(row.iloc[0]):03d}',
            'name': str(row.iloc[1]),
            'district_name': str(row.iloc[2]),
            'nature': str(row.iloc[4]),
            'total_beds': beds,
            'size_label': str(row.iloc[6]) if not pd.isna(row.iloc[6]) else '',
            'lat': float(row.iloc[7]) if not pd.isna(row.iloc[7]) else np.nan,
            'lon': float(row.iloc[8]) if not pd.isna(row.iloc[8]) else np.nan,
            'is_existing': 1,
        })
    fac = pd.DataFrame(rows)
    # 阻断: 经纬度缺失
    miss = fac[fac.lat.isna() | fac.lon.isna()]
    if len(miss):
        print(f'  [WARN] {len(miss)} 机构缺经纬度，需手动补')
    print(f'  facilities: {len(fac)} 家, 总床位={fac.total_beds.sum()}')
    return fac


# ============================================================
#  1.4 capacity_price —— 分床型容量与价格成本
# ============================================================
def build_capacity_price(facilities):
    """C0 按 60/30/10 插补（存量机构以基本床为主），标 imputed；
       price: basic=2500, care=3000, wellness=3500（元/月）→ scenario；
       c=0.80p → scenario；
       H: 无任何评级数据 → 床型均匀情景 0.60/0.70/0.80（第一篇口径）。
       注意 h_min=0.55：若插补 0.50 会把全部机构 χ 封锁（2026-09-24 修正）。"""
    PRICE = {'basic': 2500, 'care': 3000, 'wellness': 3500}
    SPLIT = {'basic': 0.60, 'care': 0.30, 'wellness': 0.10}
    H_SCEN = {'basic': 0.60, 'care': 0.70, 'wellness': 0.80}
    rows = []
    for _, f in facilities.iterrows():
        fid = f['facility_id']
        for k in ['basic', 'care', 'wellness']:
            C0 = int(round(f['total_beds'] * SPLIT[k]))
            # 确保不超出总量
            if k == 'wellness':
                # 取前两类余量，避免 rounding 造成超总量
                assigned = sum(int(round(f['total_beds'] * SPLIT[kk]))
                               for kk in ['basic', 'care'])
                C0 = f['total_beds'] - assigned
            p = PRICE[k]
            rows.append({
                'facility_id': fid, 'care_type': k,
                'capacity_C0': C0,
                'price_p': p, 'unit_cost_c': int(round(0.80 * p)),
                'quality_H': H_SCEN[k],
                'qualification': 1,
                'C0_source': 'imputed(60/30/10 split)',
                'price_source': 'scenario柳州价档中值',
                'c_source': 'scenario c=0.80p',
                'H_source': 'scenario(无评级数据→床型均匀H,第一篇口径0.60/0.70/0.80)',
            })
    cp = pd.DataFrame(rows)
    # 校验: 每机构分型容量合计 == 总床位
    check = cp.groupby('facility_id').capacity_C0.sum().reset_index()
    check = check.merge(facilities[['facility_id', 'total_beds']], on='facility_id')
    bad = check[check.capacity_C0 != check.total_beds]
    if len(bad):
        print(f'  [WARN] 分型容量合计与总床位不符 {len(bad)} 家')
    print(f'  capacity_price: {len(cp)} 行')
    return cp


# ============================================================
#  1.5 travel_edges —— 路网时间（大圆 fallback）
# ============================================================
def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.sin(dlon/2)**2
    return R * 2 * math.asin(math.sqrt(a))


def build_travel_edges(communities, facilities, tau=30):
    """大圆 ×1.25 ÷ 40km/h → 分钟；不可达（>1.5τ）标 unreachable。"""
    rows = []
    com_coords = communities.set_index('community_id')[['lat', 'lon']].to_dict('index')
    fac_coords = facilities.set_index('facility_id')[['lat', 'lon']].to_dict('index')
    n_com = len(communities)
    n_fac = len(facilities)
    total = n_com * n_fac
    for jid, jc in com_coords.items():
        for fid, fc in fac_coords.items():
            if np.isnan(jc['lat']) or np.isnan(fc['lat']):
                rows.append({'community_id': jid, 'facility_id': fid,
                             'travel_min': np.nan, 'status': 'missing'})
                continue
            gkm = haversine_km(jc['lat'], jc['lon'], fc['lat'], fc['lon'])
            tmin = gkm * 1.25 / 40 * 60  # 40km/h, 1.25 绕行系数
            status = 'unreachable' if tmin > 1.5 * tau else 'ok'
            rows.append({'community_id': jid, 'facility_id': fid,
                         'travel_min': round(tmin, 2), 'status': status})
    te = pd.DataFrame(rows)
    ok_ratio = (te.status == 'ok').sum() / len(te)
    print(f'  travel_edges: {len(te)} 边, ok={ok_ratio:.3f}, '
          f'unreachable={sum(te.status=="unreachable")}, missing={sum(te.status=="missing")}')
    print(f'    mean={te[te.status=="ok"].travel_min.mean():.1f}min, '
          f'max={te[te.status=="ok"].travel_min.max():.1f}min')
    return te


# ============================================================
#  1.6 projects —— 候选项目（由残余需求生成）
# ============================================================
def build_projects(demand, facilities, capacity_price):
    """三类候选: 扩建（存量机构扩容）、改造（床型转换）、新建（缺口集中区）。
       这里先给出一个最小候选集，后续可扩展。"""
    # 计算各机构残余需求
    fac_total_c = capacity_price.groupby('facility_id').capacity_C0.sum()
    # 简单候选: 每家机构各 1 个扩建项目（基本床 +5）
    rows = []
    for _, f in facilities.iterrows():
        fid = f['facility_id']
        rows.append({
            'project_id': f'P_exp_{fid}', 'facility_id': fid,
            'project_type': 'expansion', 'target_care': 'basic',
            'delta_capacity': 5, 'public_cost_K': 150000 * 5,  # 15万/床
            'private_cost': 0, 'depreciation_years': 20,
        })
    proj = pd.DataFrame(rows)
    print(f'  projects: {len(proj)} 个候选（每机构1个扩建）')
    return proj


# ============================================================
#  1.8 provenance —— 溯源
# ============================================================
def build_provenance():
    rows = [
        {'field_or_table': 'communities.n65', 'source': 'estimated_roles_1147.xlsx',
         'measurement_level': 'imputed', 'notes': '区县总量内最大余数法估算'},
        {'field_or_table': 'communities.lon/lat', 'source': 'estimated_roles_1147.xlsx',
         'measurement_level': 'observed', 'notes': 'CGCS2000 坐标'},
        {'field_or_table': 'communities.income', 'source': '柳州市各个行政区人均年收入.xls',
         'measurement_level': 'imputed', 'notes': '区县级代理，2023 年城镇居民人均可支配收入'},
        {'field_or_table': 'demand.L', 'source': 'scenario',
         'measurement_level': 'scenario', 'notes': 'r=5%, s=(0.50,0.30,0.20)'},
        {'field_or_table': 'demand.guarantee_b', 'source': 'V2§3 保障规则',
         'measurement_level': 'scenario', 'notes': '仅 basic 床，偏远0.50/普通0.35/城区0.20'},
        {'field_or_table': 'facilities.*', 'source': '柳州市各个行政区养老机构分布.xls',
         'measurement_level': 'observed', 'notes': '128 家机构，含性质与坐标'},
        {'field_or_table': 'capacity_price.C0', 'source': '60/30/10 插补',
         'measurement_level': 'imputed', 'notes': '存量机构以基本床为主，护理/康养占比偏低'},
        {'field_or_table': 'capacity_price.price', 'source': '柳州市养老院收费标准.xlsx',
         'measurement_level': 'scenario', 'notes': 'basic=2500, care=3000, wellness=3500 元/月'},
        {'field_or_table': 'capacity_price.c', 'source': 'c=0.80p',
         'measurement_level': 'scenario', 'notes': '敏感性 0.70/0.80/0.90'},
        {'field_or_table': 'capacity_price.H', 'source': 'scenario(第一篇口径)',
         'measurement_level': 'scenario',
         'notes': '无评级数据→床型均匀0.60/0.70/0.80; 敏感性h_min与H扰动'},
        {'field_or_table': 'communities.income_value', 'source': '柳州市各个行政区人均年收入.xls',
         'measurement_level': 'observed', 'notes': '区县级2023城镇人均可支配收入/12, 未匹配区县4000占位'},
        {'field_or_table': 'travel_edges', 'source': '大圆×1.25÷40km/h',
         'measurement_level': 'imputed', 'notes': '后续替换为 OSM 路网'},
        {'field_or_table': 'projects.public_cost_K', 'source': '鱼峰区15万/床，柳江区16.51万/床交叉验证',
         'measurement_level': 'observed', 'notes': '新建扩建 15 万，改造 3 万'},
    ]
    return pd.DataFrame(rows)


# ============================================================
#  主流程
# ============================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--raw', default='..')
    args = parser.parse_args()

    raw = find_raw()
    print('=== 构建 eldercare_inputs.xlsx ===')

    comm = build_communities(raw)
    dm = build_demand(comm)
    fac = build_facilities(raw)
    cp = build_capacity_price(fac)
    te = build_travel_edges(comm, fac)
    proj = build_projects(dm, fac, cp)
    prov = build_provenance()

    out_dir = ROOT / 'data' / 'raw'
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / 'eldercare_inputs.xlsx'

    with pd.ExcelWriter(out_path, engine='openpyxl') as w:
        comm.to_excel(w, sheet_name='communities', index=False)
        dm.to_excel(w, sheet_name='demand', index=False)
        fac.to_excel(w, sheet_name='facilities', index=False)
        cp.to_excel(w, sheet_name='capacity_price', index=False)
        te.to_excel(w, sheet_name='travel_edges', index=False)
        proj.to_excel(w, sheet_name='projects', index=False)
        prov.to_excel(w, sheet_name='provenance', index=False)

    print(f'\n输出: {out_path}')
    print(f'  SHA-256: ', end='')
    import hashlib
    h = hashlib.sha256(out_path.read_bytes()).hexdigest()
    print(h)

    # §2 阻断检查
    print('\n=== §2 阻断检查 ===')
    miss_report = []
    # 1. ID 唯一
    dups = comm[comm.duplicated('community_id')].community_id.tolist()
    if dups: miss_report.append(f'communities 重复 ID {len(dups)}')
    dups_f = fac[fac.duplicated('facility_id')].facility_id.tolist()
    if dups_f: miss_report.append(f'facilities 重复 ID {len(dups_f)}')
    # 2. 连接完整
    dc_com = set(comm.community_id)
    dc_fac = set(fac.facility_id)
    edg_com = set(te.community_id)
    edg_fac = set(te.facility_id)
    if edg_com - dc_com: miss_report.append(f'travel_edges 含不存在的 community_id')
    if edg_fac - dc_fac: miss_report.append(f'travel_edges 含不存在的 facility_id')
    # 3. 需求/容量非负
    if (dm.L < 0).any() or (dm.guarantee_b < 0).any(): miss_report.append('demand 有负值')
    if (cp.capacity_C0 < 0).any(): miss_report.append('capacity_C0 有负值')
    # 4. b <= L 已在 build_demand 中检查
    # 5. 经纬度缺失
    miss_geo = sum(fac.lat.isna() | fac.lon.isna())
    if miss_geo: miss_report.append(f'{miss_geo} 机构缺经纬度')
    # 6. 路网
    miss_te = sum(te.status == 'missing')
    if miss_te: miss_report.append(f'{miss_te} 边 travel_min 缺失')

    if miss_report:
        print('阻断项:')
        for m in miss_report:
            print(f'  [BLOCK] {m}')
        pd.DataFrame({'issue': miss_report}).to_csv(out_dir / 'missing_fields_report.csv', index=False)
        sys.exit(1)
    else:
        print('全部通过 ✅')
        pd.DataFrame({'issue': ['全部通过']}).to_csv(out_dir / 'missing_fields_report.csv', index=False)


if __name__ == '__main__':
    main()
