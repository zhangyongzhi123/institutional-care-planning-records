# -*- coding: utf-8 -*-
"""Policy15 G4: 新建联合分配（有限授权阶段，不含 G5 完整机制实验）。

12 配置矩阵（论文AI确认指令 §6）:
  项目集 P_EXP_LEGACY  (仅工作簿原地扩建项目; 成本情景不适用)
        P_EXP_NEW      (原地扩建 + 各自需求集贪心 M=40 新建点; BASE_15W_PER_BED 450万/点)
        P_EXP_NEW_LOW  (同上; LOW_COST_750K 75万/点)
  需求   upround(ΣL=28,202) / total_preserving(ΣL=26,490)
  口径   formal b(正式保障) / diagnostic b=0(诊断) —— 严格分表, 不合并曲线

新点固定容量包（G3，SCENARIO）: C_new=(NH18,BK9,WELLNESS3), p=(2500,3000,3500),
  c=0.8p, H=(.60,.70,.80), F_new=6000元/月(激活时), private=0;
  Pi0_new_annual=0.05·K (BASE:225,000/年; LOW:37,500/年);
  C0=0 且 y≡z（未建设零分配, 激活容量恰 30 床）。

G4 选择规则（预注册, 与 G1 的关系在 config 中说明）:
  Stage1 max ΣT;
  Stage2 min C=K(z)+12·ΣS_a s.t. ΣT=v*  （覆盖最优中的最低可实施财政成本，防止
        无预算约束时无关项目被任意激活——z≤y 不惩罚空激活，必须显式最小化）;
  Stage3 max ΣQ0·T s.t. ΣT=v*, C≤C*+1元;
  Stage4 min Σidx·T 固定索引破同解。
  G4 回答"项目集/成本/物理瓶颈"差异，SDM 作为结果指标报告（非选择准则）；
  G1 的 T0 重建规则（含 SDM 阶段）仅适用于 G1 基准，不混用。

formal b 不可行: Lemma1 最大流证书（z=0 与 z=z1 各一次）→ 优雅返回，
  报告最大可保障服务量/最小割/starved 社区，不崩溃，不跑伪分配。

用法:
  python src/P15_G4_joint_allocation.py --sets LEGACY      # 不依赖新路由, 可先验证
  python src/P15_G4_joint_allocation.py --sets ALL         # 需真实路由矩阵先落盘
  python src/P15_G4_joint_allocation.py --sets NEW --gap 1e-4 --time-limit 600
"""
import argparse
import dataclasses
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pulp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from run_E1_full import load_liuzhou, CONFIG, K_MAP  # noqa: E402
from solvers import lemma1_maxflow  # noqa: E402
import model_io  # noqa: E402
model_io.CARE_TYPES = ('NH', 'BK', 'WELLNESS')

DATA_P15 = ROOT / 'data' / 'P15'
G2 = ROOT / 'runs' / 'P15_G2'
REAL_CSV = DATA_P15 / 'travel_edges_newpoints_amap.csv'
CT = ('NH', 'BK', 'WELLNESS')
TAU = CONFIG['tau']

NEW_PACK = {  # G3 固定容量包（月度口径）
    'C': {'NH': 18, 'BK': 9, 'WELLNESS': 3},
    'p': {'NH': 2500.0, 'BK': 3000.0, 'WELLNESS': 3500.0},
    'H': {'NH': 0.60, 'BK': 0.70, 'WELLNESS': 0.80},
    'F_monthly': 6000.0, 'private': 0.0,
}
SCEN_K = {'BASE_15W_PER_BED': 4_500_000.0, 'LOW_COST_750K': 750_000.0}

G4_FROZEN = {
    'rule': ('lex Stage1 maxΣT → Stage2 min C=K(z)+12ΣS s.t.ΣT=v* → '
             'Stage3 maxΣQ0·T(C≤C*+1) → Stage4 minΣidx·T'),
    'rule_note': ('Stage2 成本最小为必需：无预算上限时 z≤y 不惩罚空激活，缺它会虚激活全部项目;'
                  ' G4 比较项目集/成本/物理瓶颈, SDM 报告为结果指标; G1 含SDM四阶段规则仅属 G1 基准'),
    'solver': f'PuLP {pulp.__version__} + HiGHS threads=1',
    'tau_Q': 0.02, 'tau_Q_sensitivity': [0.01, 0.02, 0.05],
    'new_package': NEW_PACK,
    'cost_scenarios': SCEN_K,
    'b_modes': {'formal': '工作簿 guarantee_b 正式保障', 'diagnostic': 'b:=0 诊断（非正式保障解）'},
    'accounting': '口径A 首年: spend = K(z) + 12·Σ[D_a]+; 建设一次性、补贴年化，分账不混',
    'g4_prohibitions': ['不回填摘要', '不宣称新建一定改善', '不宣称 PA-QMA 优势（G4 无 QMA 层）',
                        '规划代理点≠批准地块', '诊断 b=0 不得写成正式保障方案'],
}


def sha256(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


# ---------------- 参数扩展：注入新建机构/项目 ----------------
def extend_params(P_base, demand_file, site_ids, K_new, routing):
    dem = pd.read_csv(DATA_P15 / demand_file, dtype={'community_id': str})
    L = {(r.community_id, K_MAP[r.care_type]): int(r.L) for r in dem.itertuples()}
    b = {(r.community_id, K_MAP[r.care_type]): int(r.guarantee_b) for r in dem.itertuples()}

    C0, p, cst, H, F0, Pi0 = (dict(P_base.C0), dict(P_base.p), dict(P_base.cst),
                              dict(P_base.H), dict(P_base.F0), dict(P_base.Pi0))
    d = dict(P_base.d)
    projects, deltaC, proj_of_fac = dict(P_base.projects), dict(P_base.deltaC), \
        {a: list(v) for a, v in P_base.proj_of_fac.items()}
    facilities = list(P_base.facilities)
    new_facs, proj_fixed_f = [], {}
    pi0_new_monthly = 0.05 * K_new / 12.0

    for sid in site_ids:
        a = f'NEW_{sid}'
        pid = f'PNEW_{sid}'
        facilities.append(a)
        new_facs.append(a)
        for k in CT:
            C0[(a, k)] = 0
            p[(a, k)] = NEW_PACK['p'][k]
            cst[(a, k)] = 0.8 * NEW_PACK['p'][k]
            H[(a, k)] = NEW_PACK['H'][k]
            deltaC[(pid, k)] = NEW_PACK['C'][k]
        F0[a] = 0.0                       # 未激活固定成本 0
        Pi0[a] = pi0_new_monthly          # 月度保留收益 = 0.05K/12
        projects[pid] = {'facility': a, 'K': float(K_new), 'private': 0.0}
        proj_of_fac[a] = [pid]
        proj_fixed_f[pid] = NEW_PACK['F_monthly']   # 激活后运营固定成本 6000/月
        # 真实路由（仅 ok 边入 d；unreachable/failed 不产生边）
        sub = routing[routing.site_id == sid]
        for r in sub[sub.status == 'ok'].itertuples():
            d[(a, r.community_id)] = float(r.travel_min)

    P = dataclasses.replace(
        P_base, facilities=facilities, L=L, b=b, C0=C0, p=p, cst=cst, H=H,
        F0=F0, Pi0=Pi0, d=d, projects=projects, deltaC=deltaC, proj_of_fac=proj_of_fac)
    meta_ext = {'new_facilities': new_facs, 'new_projects': [f'PNEW_{s}' for s in site_ids],
                'proj_fixed_f': proj_fixed_f, 'pi0_new_monthly': pi0_new_monthly,
                'n_new_ok_edges': sum(1 for a in new_facs for j in P_base.communities
                                      if (a, j) in d)}
    return P, meta_ext


def F_active(P, a, z, y, proj_fixed_f):
    if not y.get(a, 0):
        return 0.0
    f = P.F0[a]
    for pid in P.proj_of_fac.get(a, []):
        f += P.projects[pid]['private'] * z.get(pid, 0) + proj_fixed_f.get(pid, 0.0) * z.get(pid, 0)
    return f


def psi_g4(P, T, z, y, proj_fixed_f):
    """月度 Ψ = K(z) + Σ[D_a]+；D_a=Π0·y+F_active−Σ(p−c)T。返回(月度总额, 明细, K)。"""
    Kz = sum(P.projects[pid]['K'] * z.get(pid, 0) for pid in P.projects)
    det = {}
    for a in P.facilities:
        rev = sum((P.p[(a, k)] - P.cst[(a, k)]) * T.get((a, j, k), 0)
                  for j in P.communities for k in CT)
        det[a] = P.Pi0[a] * y.get(a, 0) + F_active(P, a, z, y, proj_fixed_f) - rev
    return Kz + sum(max(0.0, v) for v in det.values()), det, Kz


def native_info(prob):
    try:
        h = prob.solverModel
        info = h.getInfo()
        out = {'model_status': str(h.getModelStatus())}
        for ks, kd in [('objective_function_value', 'objective'),
                       ('mip_dual_bound', 'bound'), ('mip_gap', 'gap')]:
            try:
                v = getattr(info, ks)
                out[kd] = float(v) if v is not None and abs(v) < 1e30 else None
            except Exception:
                out[kd] = None
        return out
    except Exception as e:
        return {'error': repr(e)}


def build_keys(P):
    keys = []
    for (a, j) in P.d:
        if P.d[(a, j)] > P.tau:
            continue
        for k in CT:
            if P.L.get((j, k), 0) <= 0:
                continue
            if P.C0.get((a, k), 0) > 0 or any(
                    P.deltaC.get((pid, k), 0) > 0 for pid in P.proj_of_fac.get(a, [])):
                if P.hard_chi(a, j, k)[0]:
                    keys.append((a, j, k))
    return sorted(keys)


def g4_solve(P, proj_fixed_f, new_facs, b_mode, time_limit, gap):
    """Stage1 maxΣT → Stage2 maxΣQ0·T → Stage3 min idx。formal b 直接进约束。"""
    keys = build_keys(P)
    by_ak, by_jk = {}, {}
    for e in keys:
        by_ak.setdefault((e[0], e[2]), []).append(e)
        by_jk.setdefault((e[1], e[2]), []).append(e)
    idx = {e: i for i, e in enumerate(keys)}
    Q0 = {e: P.Q0(*e) for e in keys}
    b_use = P.b if b_mode == 'formal' else {kk: 0 for kk in P.b}

    def base_cons():
        T = {e: pulp.LpVariable(f'T_{i}', lowBound=0, cat='Integer') for i, e in enumerate(keys)}
        yv = {a: pulp.LpVariable(f'y_{a}', cat='Binary') for a in P.facilities}
        zv = {pid: pulp.LpVariable(f'z_{pid}', cat='Binary') for pid in P.projects}
        S = {a: pulp.LpVariable(f'S_{a}', lowBound=0) for a in P.facilities}
        cons = []
        for pid, info in P.projects.items():
            cons.append(zv[pid] <= yv[info['facility']])
        for a in new_facs:                       # 新点 y≡z（未建设不运营）
            cons.append(yv[a] == zv[P.proj_of_fac[a][0]])
        for a in P.facilities:
            for k in CT:
                add = pulp.lpSum(P.deltaC.get((pid, k), 0) * zv[pid]
                                 for pid in P.proj_of_fac.get(a, []))
                if (a, k) in by_ak or P.C0.get((a, k), 0) > 0:
                    cons.append(pulp.lpSum(T[e] for e in by_ak.get((a, k), []))
                                <= P.C0.get((a, k), 0) + add)
        for (j, k), es in by_jk.items():
            cons.append(pulp.lpSum(T[e] for e in es) >= b_use[(j, k)])
            cons.append(pulp.lpSum(T[e] for e in es) <= P.L[(j, k)])
        for e in keys:
            cons.append(T[e] <= P.L[(e[1], e[2])] * yv[e[0]])
        for a in P.facilities:                    # IR + 补贴（无预算上限, 求可实施满配）
            rev = pulp.lpSum((P.p[(a, k)] - P.cst[(a, k)]) * T[e]
                             for k in CT for e in by_ak.get((a, k), []))
            fix = (P.F0[a] * yv[a]
                   + pulp.lpSum((P.projects[pid]['private'] + proj_fixed_f.get(pid, 0.0))
                                * zv[pid] for pid in P.proj_of_fac.get(a, [])))
            cons.append(S[a] >= P.Pi0[a] * yv[a] + fix - rev)
        return T, yv, zv, S, cons

    def run(name, sense, obj, cons, tl):
        pr = pulp.LpProblem(f'G4_{name}', sense)
        for c in cons:
            pr += c
        pr += obj
        t = time.time()
        pr.solve(pulp.HiGHS(msg=0, timeLimit=tl, gapRel=gap, threads=1))
        st = {'Optimal': 'OPTIMAL', 'Not Solved': 'FEASIBLE_TIMEOUT',
              'Infeasible': 'PROVEN_INFEASIBLE', 'Unbounded': 'UNKNOWN'}.get(
            pulp.LpStatus[pr.status], 'UNKNOWN')
        return st, native_info(pr), round(time.time() - t, 1), pr

    # Stage1
    T, yv, zv, S, cons = base_cons()
    tot = pulp.lpSum(T.values())
    st1, ni1, dt1, _ = run('s1', pulp.LpMaximize, tot, cons, time_limit)
    if st1 == 'PROVEN_INFEASIBLE':
        return {'status': 'PROVEN_INFEASIBLE', 'stage1': {'status': st1, 'native': ni1, 'time_s': dt1}}
    vstar = int(round(sum(T[e].value() for e in keys)))

    def cost_expr(zv_, S_):
        return (pulp.lpSum(P.projects[pid]['K'] * zv_[pid] for pid in P.projects)
                + 12.0 * pulp.lpSum(S_.values()))

    # Stage2: min 财政成本（年化口径A）s.t. ΣT=v*
    T, yv, zv, S, cons = base_cons()
    C2 = cost_expr(zv, S)
    st2, ni2c, dt2, _ = run('s2cost', pulp.LpMinimize, C2,
                            cons + [pulp.lpSum(T.values()) == vstar], time_limit)
    Cstar = float(pulp.value(C2))
    T2 = {e: int(round(T[e].value())) for e in keys}          # Stage2 解留档
    y2 = {a: int(round(yv[a].value())) for a in P.facilities}
    z2 = {pid: int(round(zv[pid].value())) for pid in P.projects}

    # Stage3: max ΣQ0·T s.t. ΣT=v*, 成本≤C*+1
    T, yv, zv, S, cons = base_cons()
    C3 = cost_expr(zv, S)
    st3, ni3, dt3, _ = run(
        's3q', pulp.LpMaximize, pulp.lpSum(Q0[e] * T[e] for e in keys),
        cons + [pulp.lpSum(T.values()) == vstar, C3 <= Cstar + 1.0], time_limit)
    qsum = float(sum(Q0[e] * T[e].value() for e in keys))
    T3 = {e: int(round(T[e].value())) for e in keys}
    y3 = {a: int(round(yv[a].value())) for a in P.facilities}
    z3 = {pid: int(round(zv[pid].value())) for pid in P.projects}

    # Stage4: 固定索引（带上界割，限时 300s）
    idx_cut = float(sum(idx[e] * T3[e] for e in keys))
    T, yv, zv, S, cons = base_cons()
    C4 = cost_expr(zv, S)
    st4, ni4, dt4, _ = run(
        's4idx', pulp.LpMinimize, pulp.lpSum(idx[e] * T[e] for e in keys),
        cons + [pulp.lpSum(T.values()) == vstar, C4 <= Cstar + 1.0,
                pulp.lpSum(Q0[e] * T[e] for e in keys) >= qsum - 1e-6,
                pulp.lpSum(idx[e] * T[e] for e in keys) <= idx_cut + 1e-6],
        min(time_limit, 300))
    Tv = {e: int(round(T[e].value())) for e in keys}
    if st4 == 'OPTIMAL' and sum(Tv.values()) == vstar:
        yv_, zv_, t_source = ({a: int(round(yv[a].value())) for a in P.facilities},
                              {pid: int(round(zv[pid].value())) for pid in P.projects},
                              'stage4_index')
    else:
        # 回退 Stage3（ΣT/成本已认证, Q 已认证；仅索引性质未认证）
        Tv, yv_, zv_, t_source = dict(T3), dict(y3), dict(z3), 'stage3_fallback_no_index_cert'
    return {'status': 'OPTIMAL' if st1 == 'OPTIMAL' and st2 == 'OPTIMAL' and st3 == 'OPTIMAL'
            else f's1={st1},s2={st2},s3={st3}',
            'stage1': {'status': st1, 'native': ni1, 'time_s': dt1, 'v': vstar},
            'stage2_cost': {'status': st2, 'native': ni2c, 'time_s': dt2, 'Cstar_annual': Cstar,
                            'n_projects_stage2': sum(z2.values())},
            'stage3_q': {'status': st3, 'native': ni3, 'time_s': dt3, 'Qsum': qsum},
            'stage4_index': {'status': st4, 'native': ni4, 'time_s': dt4, 't_source': t_source},
            'T': Tv, 'y': yv_, 'z': zv_, 'keys_n': len(keys)}


def evaluate(P, res, proj_fixed_f, new_facs, K_tag, geo):
    T, z, y = res['T'], res['z'], res['y']
    N = sum(T.values())
    D = sum(P.L.values())
    Nj = {j: sum(T.get((a, j, k), 0) for a in P.facilities for k in CT) for j in P.communities}
    # N=0 时 SDM 无定义，按规范记 N/A（None），不得除零崩溃
    sdm = (0.5 * sum(abs(Nj[j] / N - sum(P.L[(j, k)] for k in CT) / D)
                     for j in P.communities) if N > 0 else None)
    tt, bb = [], []
    for (a, j, k), t in T.items():
        if t > 0:
            tt += [P.d[(a, j)]] * t
            bb += [P.p[(a, k)] / P.I[j]] * t
    psi_m, det, Kz = psi_g4(P, T, z, y, proj_fixed_f)
    subsidy_m = psi_m - Kz
    priv = sum(P.projects[pid]['private'] * z[pid] for pid in P.projects)
    op_cost_annual = 12.0 * sum(P.cst[(a, k)] * t for (a, j, k), t in T.items())
    # 参与裕度（补贴前净收益 − 年保留收益）
    margin = {}
    for a in P.facilities:
        if y[a]:
            rev_m = sum((P.p[(a, k)] - P.cst[(a, k)]) * T.get((a, j, k), 0)
                        for j in P.communities for k in CT)
            pi0_ann = 12.0 * P.Pi0[a]
            margin[a] = round(12.0 * (rev_m - F_active(P, a, z, y, proj_fixed_f)) - pi0_ann, 1)
    active_proj = [{'project_id': pid, 'facility_id': P.projects[pid]['facility'],
                    'is_new': pid.startswith('PNEW_'),
                    'geo': geo.get(P.projects[pid]['facility'], {}), 'K': P.projects[pid]['K'],
                    'delta': {k: P.deltaC.get((pid, k), 0) for k in CT}}
                   for pid in P.projects if z[pid]]
    return {
        'v': N, 'D': D, 'coverage': N / D, 'SDM': sdm,
        'travel_p90': float(np.percentile(tt, 90)) if tt else None,
        'burden_mean': float(np.mean(bb)) if bb else None,
        'buildK_one_time': Kz, 'private_cost': priv,
        'subsidy_annual': 12.0 * subsidy_m,
        'spend_annual_accountingA': Kz + 12.0 * subsidy_m,
        'operating_cost_annual': op_cost_annual,
        'n_active_facilities': sum(y.values()), 'n_active_projects': len(active_proj),
        'n_new_activated': sum(1 for p in active_proj if p['is_new']),
        'active_projects': active_proj,
        'participation_margin': {'n_positive_without_subsidy': sum(1 for v in margin.values() if v > 0),
                                 'n_negative_filled_by_S': sum(1 for v in margin.values() if v <= 0),
                                 'min': min(margin.values()) if margin else None,
                                 'median': float(np.median(list(margin.values()))) if margin else None},
    }


def cert(P, new_facs):
    """Lemma1 证书 z=0 / z=1（项目集内全部激活）, y=1。"""
    z0 = {pid: 0 for pid in P.projects}
    z1 = {pid: 1 for pid in P.projects}
    y1 = {a: 1 for a in P.facilities}
    out = {}
    for k in CT:
        req = sum(P.b[(j, k)] for j in P.communities)
        if req <= 0:
            out[k] = {'required': 0, 'note': '无保障需求'}
            continue
        f0, mf0, S0 = lemma1_maxflow(P, k, z0, y1)
        f1, mf1, S1 = lemma1_maxflow(P, k, z1, y1)
        out[k] = {'required': int(req),
                  'maxflow_z0': int(mf0), 'feasible_z0': bool(f0),
                  'maxflow_z1_allprojects': int(mf1), 'feasible_z1': bool(f1),
                  'starved_communities_z1': int(len([j for j in S1 if P.b.get((j, k), 0) > 0])),
                  'verdict_z1': 'FEASIBLE' if f1 else 'PROVEN_INFEASIBLE_PHYSICAL'}
    return out


def run_config(tag, P, proj_fixed_f, new_facs, b_mode, time_limit, gap, geo):
    print(f'--- {tag} (b={b_mode}) ---')
    t0 = time.time()
    c = cert(P, new_facs) if b_mode == 'formal' else None
    if b_mode == 'formal' and not all(v.get('feasible_z1', True) for v in c.values()):
        res = {'config': tag, 'b_mode': b_mode,
               'verdict': 'PROVEN_INFEASIBLE_PHYSICAL',
               'certificate': c,
               'max_guarantee_flow_z1': {k: v.get('maxflow_z1_allprojects') for k, v in c.items()},
               'time_s': round(time.time() - t0, 1),
               'note': '正式保障在全项目激活下仍物理不可行；不跑伪分配；诊断口径见对应 diagnostic 行'}
        print('    物理不可行（证书）')
        return res
    r = g4_solve(P, proj_fixed_f, new_facs, b_mode, time_limit, gap)
    if r['status'] == 'PROVEN_INFEASIBLE':
        return {'config': tag, 'b_mode': b_mode, 'verdict': 'PROVEN_INFEASIBLE',
                'stage1': r['stage1'], 'certificate': c, 'time_s': round(time.time() - t0, 1)}
    m = evaluate(P, r, proj_fixed_f, new_facs, tag, geo)
    print(f"    {r['status']} v={m['v']}/{m['D']} cov={m['coverage']:.4f} "
          f"proj={m['n_active_projects']}(new {m['n_new_activated']}) "
          f"spend={m['spend_annual_accountingA']:,.0f}")
    return {'config': tag, 'b_mode': b_mode, 'verdict': 'SOLVED',
            'solver_stages': {k: r[k] for k in ('stage1', 'stage2_cost', 'stage3_q', 'stage4_index')},
            'certificate_z0z1': c, 'metrics': m, 'time_s': round(time.time() - t0, 1)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sets', choices=['LEGACY', 'NEW', 'ALL'], default='ALL')
    ap.add_argument('--time-limit', type=int, default=600)
    ap.add_argument('--gap', type=float, default=1e-4)
    args = ap.parse_args()

    P_base, coords, fcoords, districts, meta = load_liuzhou(use_osm=True)
    # 机构/新点地理位置字典（facility_id -> lon/lat/district）
    geo = {a: {'lon': fcoords[a][0], 'lat': fcoords[a][1]} for a in fcoords}
    sites_df = pd.read_excel(G2 / 'candidate_sites.xlsx', sheet_name='candidate_sites',
                             dtype={'township_code': str})
    for r in sites_df.itertuples():
        geo[f'NEW_{r.site_id}'] = {'lon': float(r.lon), 'lat': float(r.lat),
                                   'district': r.district_name, 'site_type': 'PLANNING_PROXY'}
    routing = None
    if args.sets in ('NEW', 'ALL'):
        if not REAL_CSV.exists():
            sys.exit(f'缺真实路由矩阵 {REAL_CSV}；先跑 P15_G4_routing.py --full（或先跑 --sets LEGACY）')
        routing = pd.read_csv(REAL_CSV, dtype={'site_id': str, 'community_id': str})
        manifest = json.loads((DATA_P15 / 'newpoint_routing_manifest.json').read_text(encoding='utf-8'))
        if manifest.get('failure_rate', 1) > 0.01:
            print(f"[WARN] 路由失败率 {manifest['failure_rate']:.2%} >1%，失败对按无边处理（保守）")
        print(f"路由矩阵: ok={manifest['status_counts'].get('ok', 0)} "
              f"unreachable={manifest['status_counts'].get('amap_unreachable', 0)} "
              f"failed={manifest['status_counts'].get('failed_network', 0)}")

    # 各需求集的 M=40 列表（两套不同！）
    m40 = {}
    for s, f in [('upround', 'greedy_trajectory_upround.csv'),
                 ('total_preserving', 'greedy_trajectory_total_preserving.csv')]:
        m40[s] = pd.read_csv(G2 / f).head(40).site_id.tolist()
    dem_file = {'upround': 'demand_upround.csv',
                'total_preserving': 'demand_total_preserving.csv'}

    jobs = []
    if args.sets in ('LEGACY', 'ALL'):
        for s in ('upround', 'total_preserving'):
            jobs.append((f'P_EXP_LEGACY__{s}', s, [], None))
    if args.sets in ('NEW', 'ALL'):
        for s in ('upround', 'total_preserving'):
            jobs.append((f'P_EXP_NEW__{s}', s, m40[s], 'BASE_15W_PER_BED'))
            jobs.append((f'P_EXP_NEW_LOW__{s}', s, m40[s], 'LOW_COST_750K'))

    out_dir = ROOT / 'runs' / f'P15_G4_{time.strftime("%Y%m%d_%H%M%S")}'
    out_dir.mkdir(parents=True)
    results = []
    for tag, s, sites, ktag in jobs:
        K_new = SCEN_K[ktag] if ktag else None
        P, ext = extend_params(P_base, dem_file[s], sites, K_new if K_new else 0.0,
                               routing if sites else pd.DataFrame(columns=['site_id']))
        for b_mode in ('formal', 'diagnostic'):
            r = run_config(f'{tag}__{b_mode}', P, ext['proj_fixed_f'], ext['new_facilities'],
                           b_mode, args.time_limit, args.gap, geo)
            r.update({'project_set': tag.split('__')[0], 'demand_set': s,
                      'cost_scenario': ktag or 'N/A_LEGACY',
                      'n_new_sites_offered': len(sites),
                      'n_new_ok_edges': ext['n_new_ok_edges']})
            results.append(r)
            (out_dir / f'{tag}__{b_mode}.json').write_text(
                json.dumps(r, ensure_ascii=False, indent=2, default=str), encoding='utf-8')

    # 宽表（formal 与 diagnostic 分行，不合并）
    rows = []
    for r in results:
        row = {k: r.get(k) for k in ('project_set', 'demand_set', 'cost_scenario',
                                     'b_mode', 'verdict', 'time_s')}
        m = r.get('metrics')
        if m:
            row.update({k: m[k] for k in ('v', 'coverage', 'SDM', 'travel_p90', 'burden_mean',
                                          'buildK_one_time', 'subsidy_annual',
                                          'spend_annual_accountingA', 'operating_cost_annual',
                                          'n_active_projects', 'n_new_activated',
                                          'n_active_facilities')})
        rows.append(row)
    pd.DataFrame(rows).to_csv(out_dir / 'P15_G4_summary.csv', index=False, encoding='utf-8-sig')
    frozen = dict(G4_FROZEN)
    frozen.update({'run_at': pd.Timestamp.now().isoformat(),
                   'input_sha256': meta['sha256_inputs'],
                   'routing_sha256': sha256(REAL_CSV) if REAL_CSV.exists() else None,
                   'time_limit_per_stage_s': args.time_limit, 'gapRel': args.gap,
                   'n_configs': len(results)})
    (out_dir / 'G4_config_frozen.json').write_text(
        json.dumps(frozen, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(f'\n=== G4 完成 -> {out_dir}（{len(results)} 配置行）===')


if __name__ == '__main__':
    main()
