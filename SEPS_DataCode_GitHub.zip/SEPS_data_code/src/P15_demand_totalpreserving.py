# -*- coding: utf-8 -*-
"""Policy15 §1.3: 两套需求文件（UPROUND 主口径 + TOTAL_PRESERVING 敏感性）。

输出（data/P15/）:
  demand_upround.csv            复刻工作簿 demand（原值不修改），附中性标签
  demand_total_preserving.csv   最大余数法保持总量 26,490（13,245/7,947/5,298）
  demand_meta.json              两文件 SHA-256 + 生成规则 + 差异统计

冻结规则：
  UPROROUND           L = ceil(n65 × 0.05 × share)，share=(0.50,0.30,0.20)（现有口径）
  TOTAL_PRESERVING    raw = n65 × 0.05 × share，按床型分别在社区间做最大余数法，
                      使 ΣL 精确等于 raw 总量（同分按 community_id 升序）
  guarantee_b         两套文件均按同一预注册规则 b = ceil(L_basic × rho_tier)
                      重算（规则属政策参数，随需求口径一致性应用；rho=(0.20,0.35,0.50)）
"""
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw' / 'eldercare_inputs.xlsx'
OUT = ROOT / 'data' / 'P15'

NEUTRAL = {'basic': 'TYPE1', 'care': 'TYPE2', 'wellness': 'TYPE3'}
LEGACY = {'basic': 'NH', 'care': 'BK', 'wellness': 'WELLNESS'}
SHARE = {'basic': 0.50, 'care': 0.30, 'wellness': 0.20}
RHO = {'城区': 0.20, '普通县': 0.35, '山区': 0.50}
TARGETS = {'basic': 13245, 'care': 7947, 'wellness': 5298}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def largest_remainder(raw: pd.Series, target: int, ids: pd.Series) -> pd.Series:
    """床型内最大余数法：floor + 余数最大的 (target - Σfloor) 个社区 +1，同分按 id 升序。"""
    base = np.floor(raw + 1e-9).astype(int)
    deficit = target - int(base.sum())
    assert deficit >= 0, f'target < Σfloor ({target} < {base.sum()})'
    frac = raw - base
    order = pd.DataFrame({'id': ids, 'frac': frac.values, 'pos': np.arange(len(raw))})
    order = order.sort_values(['frac', 'id'], ascending=[False, True])
    plus = np.zeros(len(raw), dtype=int)
    plus[order.pos.values[:deficit]] = 1
    return pd.Series(base + plus, index=raw.index)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    dm = pd.ExcelFile(RAW).parse('demand', dtype={'community_id': str})
    dm = dm.sort_values(['community_id', 'care_type']).reset_index(drop=True)

    # ---- 口径 1：UPROUND（复刻，不修改原值） ----
    up = dm.copy()
    up['care_type_neutral'] = up.care_type.map(NEUTRAL)
    up['care_type_legacy'] = up.care_type.map(LEGACY)
    cols = ['community_id', 'care_type', 'care_type_neutral', 'care_type_legacy',
            'n65', 'tier', 'rho', 'demand_rate', 'L', 'guarantee_b', 'source_or_scenario']
    up = up[cols]
    up_path = OUT / 'demand_upround.csv'
    up.to_csv(up_path, index=False, encoding='utf-8-sig')

    # ---- 口径 2：TOTAL_PRESERVING（最大余数法） ----
    tp = dm.copy()
    raw = tp.n65 * 0.05 * tp.care_type.map(SHARE)
    newL = pd.Series(0, index=tp.index, dtype=int)
    for k, target in TARGETS.items():
        m = tp.care_type == k
        assert abs(raw[m].sum() - target) < 0.5, (k, raw[m].sum(), target)
        newL[m] = largest_remainder(raw[m], target, tp.loc[m, 'community_id'])
    tp['L'] = newL
    mb = tp.care_type == 'basic'
    tp.loc[mb, 'guarantee_b'] = np.ceil(tp.loc[mb, 'L'] * tp.loc[mb, 'tier'].map(RHO) - 1e-9).astype(int)
    tp.loc[~mb, 'guarantee_b'] = 0
    tp['care_type_neutral'] = tp.care_type.map(NEUTRAL)
    tp['care_type_legacy'] = tp.care_type.map(LEGACY)
    tp['rounding'] = 'total_preserving(largest_remainder)'
    tp = tp[cols + ['rounding']]
    tp_path = OUT / 'demand_total_preserving.csv'
    tp.to_csv(tp_path, index=False, encoding='utf-8-sig')

    # ---- 校验与元数据 ----
    chk = {}
    for name, df in [('upround', up), ('total_preserving', tp)]:
        g = df.groupby('care_type', observed=True).agg(L=('L', 'sum'), b=('guarantee_b', 'sum'),
                                                       pos_rows=('L', lambda s: int((s > 0).sum())))
        chk[name] = {'per_type': {k: {kk: int(vv) for kk, vv in r.items()}
                                  for k, r in g.iterrows()},
                     'L_grand': int(df.L.sum()), 'b_grand': int(df.guarantee_b.sum())}
    # 复核：UPROUND 与工作簿逐值一致
    wb = dm.set_index(['community_id', 'care_type'])
    upi = up.set_index(['community_id', 'care_type'])
    ident = bool((wb.L == upi.L).all() and (wb.guarantee_b == upi.guarantee_b).all())
    # TOTAL ≤ UP 逐行
    dom = bool((tp.set_index(['community_id', 'care_type']).L
                <= upi.L).all())
    meta = {
        'script': Path(__file__).name,
        'run_at': pd.Timestamp.now().isoformat(),
        'source_workbook': RAW.name,
        'source_workbook_sha256': sha256(RAW),
        'files': {
            'demand_upround.csv': {'sha256': sha256(up_path), 'rows': int(len(up))},
            'demand_total_preserving.csv': {'sha256': sha256(tp_path), 'rows': int(len(tp))},
        },
        'rules': {
            'UPROUND': 'L = ceil(n65*0.05*share), share=(0.50,0.30,0.20)（现有工作簿口径原样复刻）',
            'TOTAL_PRESERVING': 'raw = n65*0.05*share，按床型最大余数法取整，ΣL 精确 = (13245,7947,5298)；'
                                '同分按 community_id 升序（冻结）',
            'guarantee_b': 'b = ceil(L_basic × rho_tier)，rho=(城区0.20,普通县0.35,山区0.50)；'
                           '两套文件均按同一规则重算（政策规则一致性），basic 以外床型 b=0',
        },
        'checks': {
            'upround_identical_to_workbook': ident,
            'total_preserving_le_upround_per_row': dom,
            'targets_met': {k: int(tp[tp.care_type == k].L.sum()) == v
                            for k, v in TARGETS.items()},
        },
        'summary': chk,
        'note': '原始工作簿未做任何修改；两套需求为两个独立文件、两个 hash',
    }
    (OUT / 'demand_meta.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2),
                                          encoding='utf-8')
    print('UPROUND   L:', chk['upround']['L_grand'], 'b:', chk['upround']['b_grand'],
          'identical:', ident)
    print('TOTAL_PRE L:', chk['total_preserving']['L_grand'], 'b:', chk['total_preserving']['b_grand'],
          'dominated:', dom, 'targets:', meta['checks']['targets_met'])
    print('->', OUT)


if __name__ == '__main__':
    main()
