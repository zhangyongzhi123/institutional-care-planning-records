# -*- coding: utf-8 -*-
"""求解器：全枚举认证器、MILP（PuLP+HiGHS）、最大流引理1核验。

状态语义（交接说明§1.8）：OPTIMAL / FEASIBLE_TIMEOUT / PROVEN_INFEASIBLE / UNKNOWN。
"""
import itertools

import networkx as nx
import pulp

from model_io import Params

# 求解器调用统计（run_summary.inner_calls 用）
CALLS = {"milp": 0, "maxflow": 0}


def reset_stats():
    CALLS["milp"] = CALLS["maxflow"] = 0


def get_stats():
    return dict(CALLS)


# ---------------- 公共结构 ----------------
def u_bound(P: Params, a, j, k, z, y):
    """边分配上界 u_ajk = χ·min{L, C(z)}·y_a（式(6)口径）。"""
    chi, _ = P.hard_chi(a, j, k)
    if not chi or not y.get(a, 0):
        return 0
    return int(min(P.L[(j, k)], P.capacity(a, k, z)))


def phys_feasible_T(P: Params, T, z, y):
    """核验式(4)(5)(6)：b≤Σ_a T≤L、Σ_j T≤C(z)、0≤T≤u。"""
    for (j, k) in P.L:
        s = sum(T.get((a, j, k), 0) for a in P.facilities)
        if s < P.b[(j, k)] or s > P.L[(j, k)]:
            return False
    for a in P.facilities:
        for k in P.care_types:
            if sum(T.get((a, j, k), 0) for j in P.communities) > P.capacity(a, k, z):
                return False
    for e, t in T.items():
        if t < 0 or t > u_bound(P, e[0], e[1], e[2], z, y):
            return False
    return True


def psi(P: Params, T, z, y):
    """命题1：Ψ(z,y,T) = K(z) + Σ_a [D_a]₊，D_a = Π⁰y + F_a(z)y − Σ(p−c)T（式(19)(20)）。"""
    tot = P.K_z(z)
    details = {}
    for a in P.facilities:
        rev = sum((P.p[(a, k)] - P.cst[(a, k)]) * T.get((a, j, k), 0)
                  for j in P.communities for k in P.care_types)
        D = P.Pi0[a] * y.get(a, 0) + P.F_active(a, z, y) - rev
        details[a] = D
        tot += max(0.0, D)
    return tot, details


def enumerate_all(P: Params, z, y):
    """全枚举所有物理可行整数T（含空T仅当b=0）。返回 [(T, Ψ)]。"""
    keys = [(a, j, k) for a in P.facilities for j in P.communities for k in P.care_types]
    ranges = [range(u_bound(P, a, j, k, z, y) + 1) for (a, j, k) in keys]
    out = []
    for combo in itertools.product(*ranges):
        T = dict(zip(keys, combo))
        if phys_feasible_T(P, T, z, y):
            out.append((T, psi(P, T, z, y)[0]))
    return out


# ---------------- MILP（PuLP + HiGHS） ----------------
def solve_milp(P: Params, z, y, B, mode, v=None, coeff=None, Q0_map=None,
               time_limit=60, tie=False, T_floor=None, drop_ir=False,
               drop_chi=False):
    """统一MILP。

    mode: 'maxflow'(max ΣT) | 'maxq'(max Σcoeff·T, 需ΣT=v 或 v=None不固定) |
          'bcrit'(min K+ΣS) | 'maxq_budget'(max Σcoeff·T s.t. ΣT=v, 财政≤B)
    coeff: 目标系数映射（Q0 / Q̄ / Q^PA）
    tie:  第三准则激活（固定主目标值后 min ΣT 作为稳定性准则，T⁰=0）
    T_floor: 逐边下界 {e: t0}（Sequential 机制 T=T⁰+U 用）
    drop_ir: 消融开关——去掉补贴/IR/财政约束（仅用于明确标注的模型约束消融实验）
    drop_chi: 消融开关——上界不再过滤硬资格χ（同上）
    返回 dict(status, T, S, obj, v, psi, meta)
    """
    if mode == "bcrit" and drop_ir:
        raise ValueError("bcrit 需要 S 变量，与 drop_ir 冲突")
    keys = [(a, j, k) for a in P.facilities for j in P.communities for k in P.care_types]
    prob = pulp.LpProblem("GMRA", pulp.LpMaximize if mode != "bcrit" else pulp.LpMinimize)
    T = {e: pulp.LpVariable(f"T_{e[0]}_{e[1]}_{e[2]}", lowBound=0, cat="Integer") for e in keys}
    yy = {a: pulp.LpVariable(f"y_{a}", cat="Binary") for a in P.facilities}
    zz = {pid: pulp.LpVariable(f"z_{pid}", cat="Binary") for pid in P.projects}
    S = None if drop_ir else {a: pulp.LpVariable(f"S_{a}", lowBound=0) for a in P.facilities}

    # 项目-参与联动 z_p ≤ y_a(p)
    for pid, info in P.projects.items():
        prob += zz[pid] <= yy[info["facility"]]
    # 固定传入的 z, y（示例A外层枚举(z,y)，内层线性求解）
    for a in P.facilities:
        prob += yy[a] == y.get(a, 0)
    for pid in P.projects:
        prob += zz[pid] == z.get(pid, 0)

    # 容量与上界（式(5)(6)）
    for a in P.facilities:
        for k in P.care_types:
            prob += pulp.lpSum(T[(a, j, k)] for j in P.communities) <= P.capacity(a, k, z)
    for e in keys:
        a, j, k = e
        if drop_chi:
            ub = int(min(P.L[(j, k)], P.capacity(a, k, z))) if y.get(a, 0) else 0
        else:
            ub = u_bound(P, a, j, k, z, y)
        prob += T[e] <= ub
        if T_floor is not None:
            prob += T[e] >= int(T_floor.get(e, 0))

    # 保障与需求（式(4)）
    for (j, k) in P.L:
        s = pulp.lpSum(T[(a, j, k)] for a in P.facilities)
        prob += s >= P.b[(j, k)]
        prob += s <= P.L[(j, k)]

    # 补贴与IR（式(10)-(12)）：S_a ≥ D_a(T) 线性化；财政 K+ΣS ≤ B
    if not drop_ir:
        for a in P.facilities:
            rev = pulp.lpSum((P.p[(a, k)] - P.cst[(a, k)]) * T[(a, j, k)]
                             for j in P.communities for k in P.care_types)
            rhs = P.Pi0[a] * y.get(a, 0) + P.F_active(a, z, y) - rev
            prob += S[a] >= rhs
        prob += P.K_z(z) + pulp.lpSum(S.values()) <= B

    # 目标
    if mode == "maxflow":
        prob += pulp.lpSum(T.values())
    elif mode == "bcrit":
        prob += P.K_z(z) + pulp.lpSum(S.values())
    elif mode in ("maxq", "maxq_budget"):
        prob += pulp.lpSum(coeff[e] * T[e] for e in keys)
        if mode == "maxq_budget":
            prob += pulp.lpSum(T.values()) == v
    else:
        raise ValueError(mode)

    prob.solve(pulp.HiGHS(msg=0, timeLimit=time_limit, gapRel=0.0, threads=1))
    CALLS["milp"] += 1
    status = pulp.LpStatus[prob.status]
    st = {"Optimal": "OPTIMAL", "Not Solved": "FEASIBLE_TIMEOUT",
          "Infeasible": "PROVEN_INFEASIBLE", "Unbounded": "UNKNOWN"}.get(status, "UNKNOWN")
    Tv = {e: int(round(T[e].value())) for e in keys} if st == "OPTIMAL" else None
    Sv = ({a: float(S[a].value()) for a in P.facilities}
          if st == "OPTIMAL" and not drop_ir else None)
    objv = float(pulp.value(prob.objective)) if st == "OPTIMAL" else None
    return {"status": st, "T": Tv, "S": Sv, "obj": objv,
            "psi": psi(P, Tv, z, y)[0] if Tv else None,
            "solver": f"PuLP {pulp.__version__} + HiGHS"}


def Tref_lexicographic(P: Params, B, combos, Q0_map):
    """T^ref 词典序（最大服务量 → 最大基础资格 → 固定并列规则）。

    combos: 合法 (z,y) 组合列表（满足 z_p≤y_a(p)）。跨组合并列时取固定字典序最小。
    """
    best = None
    for z, y in combos:
        r1 = solve_milp(P, z, y, B, "maxflow")
        if r1["status"] != "OPTIMAL":
            continue
        v1 = int(r1["obj"])
        r2 = solve_milp(P, z, y, B, "maxq_budget", v=v1, coeff=Q0_map)
        q1 = r2["obj"]
        cand = {"z": z, "y": y, "v": v1, "q": q1, "res": r2}
        key = (-v1, -q1, tuple(sorted(z.items())), tuple(sorted(y.items())))
        if best is None or key < best["key"]:
            best = {**cand, "key": key}
    if best is None:
        return None
    return best


# ---------------- 最大流引理1 ----------------
def lemma1_maxflow(P: Params, k, z, y, need=None):
    """按床型k独立建网：s→j(容量b或need)、j→a(u_ajk)、a→t(C_ak(z))。

    返回 (feasible, maxflow_value, mincut_set)。need 给定时核验该保障向量而非 b。
    """
    G = nx.DiGraph()
    src, snk = "SRC", "SNK"
    req = need if need is not None else {j: P.b[(j, k)] for j in P.communities}
    for j in P.communities:
        if req[j] > 0:
            G.add_edge(src, j, capacity=int(req[j]))
    for a in P.facilities:
        for j in P.communities:
            u = u_bound(P, a, j, k, z, y)
            if u > 0:
                G.add_edge(j, a, capacity=int(u))
        cap = P.capacity(a, k, z) if y.get(a, 0) else 0
        if cap > 0:
            G.add_edge(a, snk, capacity=int(cap))
    if 'SRC' not in G or 'SNK' not in G or not nx.has_path(G, src, snk):
        # b 全为 0（如 BK/WELLNESS）时无 s→j 边：保障判据空真
        return (sum(req.values()) == 0), (0 if sum(req.values()) else None), set()
    val, _fd = nx.maximum_flow(G, src, snk, flow_func=nx.algorithms.flow.shortest_augmenting_path)
    CALLS["maxflow"] += 1
    _cutv, (Sset, _) = nx.minimum_cut(G, src, snk, flow_func=nx.algorithms.flow.shortest_augmenting_path)
    return val >= sum(req.values()), val, Sset
