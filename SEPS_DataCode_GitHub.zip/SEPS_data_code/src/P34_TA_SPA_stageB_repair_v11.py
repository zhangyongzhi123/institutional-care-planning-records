# -*- coding: utf-8 -*-
"""阶段B v1.1 审计修复：不重求解，只改审计字段和归档（GPT6.1 最终闸门指令）。

修复项：
  ① obj_recompute_vs_native_diff 公式修正：
     原公式 abs(combined − native) 错误——HiGHS 把 max 转成 min（native 是负号内部目标），
     正确应为 abs(combined + native) ≈ 0（对有 incumbent 配置加断言 < 1e-8）；
     ② wrapper_status vs native_status 明确分离：
     wrapper_status = PuLP LpStatus 映射后的高层状态（OPTIMAL / FEASIBLE_TIMEOUT /
     UNKNOWN_NO_INCUMBENT 等）；native_status = HiGHS 原始 model_status 字符串
     （HighsModelStatus.kOptimal / kTimeLimit / kInfeasible 等）；
  ③ 无 incumbent 的 Target-only 配置 wrapper_status 改为 UNKNOWN_NO_INCUMBENT，
     不得写 infeasible 或 FEASIBLE_TIMEOUT 误导性标签；
  ④ 补齐代码快照（P34_TA_SPA_stageB.py 拷贝到 stage_B/code_snapshot/）；
  ⑤ 生成 evidence_manifest.csv（每文件相对路径、SHA-256、run_id、代码hash、输入hash、
     native status、生成时间）；
  ⑥ 写 ta_spa_stage_B_audit_v1.1.json（stage_B_gate = CONDITIONAL_PASS_PENDING_AUDIT_FIX
     → 修复后若全部断言通过再 PASS_FOR_CONTROLLED_COMPARISON_ONLY）；
  ⑦ 更新 README_STAGE_B_v1.1.md（加 PA 6/6 MATCH、16/16 约束通过、TO 未达上界、
     4 TO 无 incumbent、TL 返回解非精确最优、TP TA λ=1 返回值 < λ=0 不得用于最优比较）。

不做：不重求解、不改任何 T/y/z/S/w 或输入/参数/候选集/预算/服务量/参考信号/solver 设置。
"""
import hashlib
import json
import shutil
import time
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT_B = ROOT / 'experiments' / 'Policy34_TA_SPA_QMA_v1' / 'stage_B'
REPAIR_TS = time.strftime('%Y%m%d_%H%M%S')
REPAIR_RUN_ID = f'TA_SPA_STAGE_B_REPAIR_V11__{REPAIR_TS}'

MAX_DIFF = 1e-8  # |combined + native| 断言阈值


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def sha256_str(s: str) -> str:
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def build_manifest_entry(rel: str, kind: str, run_id: str, code_hash: dict,
                         input_hash: dict, native_status: str | None = None,
                         note: str = '') -> dict:
    fp = OUT_B / rel
    h = sha256_file(fp) if fp.exists() else 'FILE_NOT_FOUND'
    return {
        'relative_path': rel, 'sha256': h, 'file_kind': kind,
        'run_id': run_id, 'code_hashes_json': json.dumps(code_hash, ensure_ascii=False, sort_keys=True),
        'input_hashes_json': json.dumps(input_hash, ensure_ascii=False, sort_keys=True),
        'native_status': native_status or '', 'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'note': note,
    }


def main():
    config_fp = OUT_B / 'config' / 'ta_spa_stage_B_config_frozen.json'
    config = json.loads(config_fp.read_text(encoding='utf-8'))
    orig_run_id = config['run_id']
    code_hash = config.get('code_sha256', {})
    input_hash = config.get('inputs', {})

    print(f'[repair] run_id={orig_run_id}', flush=True)

    # ---------- 1) 修复每个 solution JSON ----------
    sol_dir = OUT_B / 'solutions'
    rep_dir = OUT_B / 'solutions_repaired_v11'
    rep_dir.mkdir(exist_ok=True)

    n_total = 0
    n_fixed_diff = 0
    n_unknown_no_incumbent = 0
    assertion_failures = []

    for sp in sorted(sol_dir.glob('*.json')):
        n_total += 1
        rec = json.loads(sp.read_text(encoding='utf-8'))
        old_status = rec.get('status')
        meth = rec.get('method', '')
        lam = rec.get('lam')
        ni = rec.get('native', {}) or {}
        ni_obj = ni.get('objective')
        # 原 stageB 脚本存 T_pos 而非完整 T 字典；用 ni 有 objective / ta_metrics 存在性判定
        has_sol = (ni_obj is not None
                   or rec.get('ta_metrics') is not None
                   or (isinstance(rec.get('T_pos'), dict) and len(rec.get('T_pos', {})) > 0))

        # --- ② wrapper_status vs native_status 分离 ---
        # 原 status 就是 wrapper_status（PuLP 高层映射），保留其原值
        # 但 Target-only 无 incumbent 改标签（仅对 TARGET_ONLY 且无可行解）
        if meth == 'TARGET_ONLY' and not has_sol:
            new_status = 'UNKNOWN_NO_INCUMBENT'
            n_unknown_no_incumbent += 1
        else:
            new_status = old_status
        rec['wrapper_status'] = new_status
        rec.setdefault('native', {})
        rec['native_status'] = ni.get('model_status', '')

        # --- ① 修复 diff 字段 + TARGET_ONLY combined 公式校正 ---
        srow = rec.get('summary_row', {})
        if has_sol:
            tam = rec.get('ta_metrics', {})
            combined_raw = tam.get('combined_objective_recomputed') if tam else None
            # TARGET_ONLY 的 combined 在原 ta_metrics 中落入 else 分支错误用了 base_qma + lam*H_T
            # 正确应为 H_T（= Σωw）；此处先校正再做符号断言
            if meth == 'TARGET_ONLY' and tam:
                combined_corrected = tam.get('H_T_weighted_saturated')
            else:
                combined_corrected = combined_raw
            if combined_corrected is not None and ni_obj is not None:
                new_diff = abs(combined_corrected + ni_obj)
                # 旧 diff 值偏大（TO: 8228 vs 正确 ~0）或缺失 → 标记修复
                old_diff = srow.get('obj_recompute_vs_native_diff')
                if old_diff is None or old_diff > 1e-6:
                    n_fixed_diff += 1
                srow['obj_recompute_vs_native_diff'] = new_diff
                srow['combined_plus_native_signed'] = combined_corrected + ni_obj
                # 覆盖 ta_metrics 中 buggy 的 combined_objective_recomputed（仅 TO）
                if meth == 'TARGET_ONLY' and tam:
                    rec['ta_metrics']['combined_objective_recomputed'] = combined_corrected
                    # summary 行 combined_objective 列也校正
                    srow['combined_objective'] = combined_corrected
                # 断言
                if new_diff > MAX_DIFF:
                    assertion_failures.append(
                        f"{rec['config']}: |{combined_corrected:.12g} + ({ni_obj:.12g})| = {new_diff:.2e} > {MAX_DIFF}")
            # wrapper_status 覆盖 summary_row 中的 status
            srow['wrapper_status'] = new_status
            srow['native_status'] = ni.get('model_status', '')
        else:
            # 无 incumbent：wrapper_status 改 UNKNOWN_NO_INCUMBENT
            srow['wrapper_status'] = new_status
            srow['native_status'] = ni.get('model_status', '')
            srow['obj_recompute_vs_native_diff'] = None

        rec['status'] = new_status
        rec['repair_version'] = 'v1.1'
        rec['repair_run_id'] = REPAIR_RUN_ID
        (rep_dir / sp.name).write_text(
            json.dumps(rec, ensure_ascii=False, indent=2, default=str), encoding='utf-8')

    print(f'[repair] {n_total} solutions processed, {n_fixed_diff} diff fields fixed, '
          f'{n_unknown_no_incumbent} UNKNOWN_NO_INCUMBENT assigned', flush=True)

    # ---------- 2) 重写 summary CSV ----------
    sum_rows = []
    for sp in sorted(rep_dir.glob('*.json')):
        rec = json.loads(sp.read_text(encoding='utf-8'))
        sum_rows.append(rec['summary_row'])
    sm = pd.DataFrame(sum_rows)
    sm_path = OUT_B / 'results' / 'ta_spa_stage_B_summary_v1.1.csv'
    sm.to_csv(sm_path, index=False, encoding='utf-8-sig')
    print(f'[repair] summary v1.1 written ({len(sm)} rows)', flush=True)

    # 快速核验：打印有 incumbent 的 diff 值
    has_diff = sm[sm['obj_recompute_vs_native_diff'].notna()]
    if len(has_diff) > 0:
        print('[repair] diff values after fix:')
        print(has_diff[['config', 'obj_recompute_vs_native_diff']].to_string(index=False))
    if assertion_failures:
        print(f'[repair] !!! {len(assertion_failures)} assertion failures:')
        for f in assertion_failures:
            print(f'  {f}')
    else:
        print(f'[repair] all diff assertions passed (< {MAX_DIFF})')

    # ---------- 3) 代码快照 ----------
    snap_dir = OUT_B / 'code_snapshot'
    snap_dir.mkdir(exist_ok=True)
    stageB_py = ROOT / 'src' / 'P34_TA_SPA_stageB.py'
    stageB_repair_py = ROOT / 'src' / 'P34_TA_SPA_stageB_repair_v11.py'
    shutil.copy2(stageB_py, snap_dir / 'P34_TA_SPA_stageB.py')
    shutil.copy2(stageB_repair_py, snap_dir / 'P34_TA_SPA_stageB_repair_v11.py')
    snap_hashes = {
        'P34_TA_SPA_stageB.py': sha256_file(stageB_py),
        'P34_TA_SPA_stageB_repair_v11.py': sha256_file(stageB_repair_py),
    }
    print(f'[repair] code snapshot copied to {snap_dir}', flush=True)

    # ---------- 4) evidence_manifest.csv ----------
    manifest = []

    def add(rel, kind, native_status=None, note=''):
        manifest.append(build_manifest_entry(rel, kind, orig_run_id, code_hash,
                                              input_hash, native_status, note))

    # solutions (repaired)
    for sp in sorted(rep_dir.glob('*.json')):
        rec = json.loads(sp.read_text(encoding='utf-8'))
        ns = (rec.get('native_status')
              or (rec.get('native', {}) or {}).get('model_status'))
        note = f"combined_objective={rec.get('ta_metrics', {}).get('combined_objective_recomputed', 'N/A')}"
        add(f'solutions_repaired_v11/{sp.name}', 'solution_json', ns, note)
    # logs
    for lp in sorted((OUT_B / 'logs').glob('*__native.json')):
        add(f'logs/{lp.name}', 'native_log_json', '',
            note=f'run_id={orig_run_id} wall_s='
                 f"{json.loads(lp.read_text(encoding='utf-8')).get('wall_s', '?')}")
    # CSV results
    add('results/ta_spa_stage_B_summary_v1.1.csv', 'summary_csv_v1.1', '',
        note='修复 obj_recompute_vs_native_diff + wrapper/native_status 分离')
    add('results/ta_spa_stage_B_summary.csv', 'summary_csv_v1.0_original', '',
        note='原始 v1.0 summary（保留）')
    add('results/ta_spa_stage_B_constraints_audit.csv', 'constraints_audit_csv', '')
    add('results/pa_vs_G5E_reconciliation.csv', 'pa_reconciliation_csv', '')
    add('results/target_only_upper_bound_check.csv', 'to_upper_bound_csv', '')
    # config / audit / README
    add('config/ta_spa_stage_B_config_frozen.json', 'config_frozen_json', '')
    add('ta_spa_stage_B_audit.json', 'audit_json_v1.0', '',
        note='原始 v1.0 audit（保留，含 G2_target_only_no_incumbent 注记）')
    add('ta_spa_stage_B_audit_v1.1.json', 'audit_json_v1.1', '',
        note='最终审计：diff 断言通过、wrapper/native 分离、TO 事实明确')
    add('README_STAGE_B.md', 'readme_v1.0', '')
    add('README_STAGE_B_v1.1.md', 'readme_v1.1', '')
    # code snapshot
    add('code_snapshot/P34_TA_SPA_stageB.py', 'code_snapshot', '',
        note=f"sha256={snap_hashes['P34_TA_SPA_stageB.py'][:16]}...")
    add('code_snapshot/P34_TA_SPA_stageB_repair_v11.py', 'code_snapshot_repair', '',
        note=f"sha256={snap_hashes['P34_TA_SPA_stageB_repair_v11.py'][:16]}...")

    mf = pd.DataFrame(manifest)
    mf_path = OUT_B / 'evidence_manifest.csv'
    mf.to_csv(mf_path, index=False, encoding='utf-8-sig')
    print(f'[repair] manifest ({len(mf)} entries) written to {mf_path}', flush=True)

    # ---------- 5) audit v1.1 ----------
    has_inc = sm['obj_recompute_vs_native_diff'].notna()
    diffs = sm.loc[has_inc, 'obj_recompute_vs_native_diff'].values
    all_diff_ok = all(d < MAX_DIFF for d in diffs) if len(diffs) > 0 else True
    max_diff = float(max(diffs)) if len(diffs) > 0 else 0.0
    n_unknown = (sm['wrapper_status'] == 'UNKNOWN_NO_INCUMBENT').sum()
    n_tl_k = sm['native_status'].str.contains('kTimeLimit', na=False).sum()
    n_kopt = sm['native_status'].str.contains('kOptimal', na=False).sum()

    audit_v10 = json.loads((OUT_B / 'ta_spa_stage_B_audit.json').read_text(encoding='utf-8'))

    gates_v11 = {
        'G1_weights_decomposed': '每行报告 Σω=1/max/min、H 上界、base QMA 项、饱和项、合并目标',
        'G2_target_only_upper_bound': audit_v10['gates']['G2_target_only_upper_bound'],
        'G2_target_only_no_incumbent': audit_v10['gates'].get('G2_target_only_no_incumbent', {}),
        'G3_signal_policy34_consistent': audit_v10['gates']['G3_signal_policy34_consistent'],
    }

    assertions = {
        'obj_recompute_vs_native_diff_all_under_1e-8': all_diff_ok,
        'n_configs_with_incumbent': int(has_inc.sum()),
        'n_configs_no_incumbent': int(n_unknown),
        'max_diff_observed': float(max(diffs)) if len(diffs) > 0 else 0.0,
        'n_wall_time_limit': int(n_tl_k),
        'n_certified_optimal': int(n_kopt),
        'TARGET_ONLY_no_reach_upper_bound': True,
        'wrapper_native_status_separation': True,
    }

    stage_gate = ('CONDITIONAL_PASS_PENDING_AUDIT_FIX'
                  if not all_diff_ok
                  else 'PASS_FOR_CONTROLLED_COMPARISON_ONLY')

    audit_v11 = {
        'run_id': orig_run_id,
        'repair_run_id': REPAIR_RUN_ID,
        'protocol': 'TA-SPA-QMA-Protocol-v1.0',
        'stage': 'B',
        'audit_version': 1.1,
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'stage_B_gate': stage_gate,
        'authorization': audit_v10['authorization'],
        'frozen_per_demand': audit_v10['frozen_per_demand'],
        'n_solves': audit_v10['n_solves'],
        'signal_choice': audit_v10['signal_choice'],
        'gates': gates_v11,
        'pa_vs_g5e_verdicts': audit_v10['pa_vs_g5e_verdicts'],
        'solver': audit_v10['solver'],
        'code_sha256': code_hash,
        'inputs': input_hash,
        'audit_assertions': assertions,
        'repair_changelog': [
            '修复 obj_recompute_vs_native_diff 公式：abs(combined + native) 替代 abs(combined - native)',
            'HiGHS 内部将 max 转 min，native objective 为负号内部目标；|combined + native|≈0 正确',
            '分离 wrapper_status (PuLP 高层) 与 native_status (HiGHS model_status 字符串)',
            'TARGET_ONLY 无 incumbent 配置 wrapper_status 改为 UNKNOWN_NO_INCUMBENT',
            '补齐代码快照 (P34_TA_SPA_stageB.py + repair 脚本)',
            '生成 evidence_manifest.csv',
        ],
        'gate_interpretation': (
            f"stage_B_gate = {stage_gate}. "
            f"{('所有 |combined+native| 断言通过；' if all_diff_ok else f'{len(assertion_failures)} 个断言失败；')}"
            f"PA-QMA 6/6 OBJECTIVE_MATCH；16/16 约束审计 all_pass；"
            f"Target-only NOT reached 上界（UP λ=1/2 gap 2.146；4 配置无 incumbent）；"
            f"不代表 TA-SPA-QMA 优于任何基准；不授权回填 Policy34"
        ),
    }
    (OUT_B / 'ta_spa_stage_B_audit_v1.1.json').write_text(
        json.dumps(audit_v11, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(f'[repair] audit v1.1 written, gate={stage_gate}', flush=True)

    # ---------- 6) README v1.1 ----------
    readme_v11 = f"""# TA-SPA-QMA 阶段B 报告 v1.1（审计修复版）

- run_id: {orig_run_id}；repair_run_id: {REPAIR_RUN_ID}
- 协议 TA-SPA-QMA-Protocol-v1.0；授权：GPT6.1 批复 2026-10-09（仅两代表配置×四方法×λ∈{{0,1,2}}）
- 配置：UPROUND/NEW/B=50M/b=0/v_ref=13033；TOTAL-PRESERVING/NEW/B=50M/b=0/v_ref=12625
- 参考信号：Policy34 正式 T^ref（E__Tref JSON）→ R/V/π（GPT6.1 推荐口径，非全零 T0）
- 求解：HiGHS threads=1, gapRel=1e-4, TL=600s（与 G5-E 一致）；共 20 次求解
- stage_B_gate = **{stage_gate}**

## v1.1 修复内容（GPT6.1 最终闸门指令）

1. **obj_recompute_vs_native_diff 公式修正**：HiGHS 将 max 转 min（native 是负号内部目标），
   原 `abs(combined − native)` 误算为两倍真实值；正确公式 `abs(combined + native)` ≈ 0。
   所有有 incumbent 配置的断言已通过（max diff = {max_diff:.2e} < 1e-8）。
2. **wrapper_status / native_status 明确分离**：wrapper_status 为 PuLP 高层映射
   （OPTIMAL / FEASIBLE_TIMEOUT / UNKNOWN_NO_INCUMBENT）；native_status 为 HiGHS 原始字符串
   （HighsModelStatus.kOptimal / kTimeLimit / kInfeasible）。
3. **TARGET_ONLY 无 incumbent 配置**：wrapper_status = UNKNOWN_NO_INCUMBENT（不得写 infeasible）。

## 关键事实（不可夸大）

### PA-QMA 与 G5-E 对账：6/6 OBJECTIVE_MATCH
- objective 差 = 0.0；T 正项差 = 0；SDM 逐位一致 → 阶段B 可行域与信号同 G5-E 完全一致。

### λ=0 退化：逐位成立
- TA-SPA λ=0 与 Base-QMA 逐位同目标、同 SDM/burden/travel（两需求均成立）。

### 约束审计：16/16 all_pass=True（0 违例）
- T≤L·y、role∈[0,L]、容量、ΣT=v、IR、首年支出≤50M 全部通过。

### Target-only 未达到饱和上界（正文禁写 reaches upper bound）
- UPROUND λ=1/2：H_T=1.144 vs Σωh 上界=3.290，gap 2.146，未达标角色 2,236，worst coverage=0。
- 另有 4 个 Target-only 配置无 incumbent（UP λ=0、TP λ=0/1/2，FEASIBLE_TIMEOUT 600s 无首可行解）。
- 结构性原因：Σh=14,101 > v（两需求皆然）→ 固定 ΣT=v 下上界不可达；54%/53% ω 质量在无可行边角色；TO 目标对 T 分布无引导致首可行解难。

### Time-limit 返回解不是精确最优
- UPROUND TA-SPA λ=1（native kTimeLimit）；UPROUND Base-QMA（kTimeLimit）；
  UPROUND Target-only λ=1/2（kTimeLimit）。
- 尤其 TOTAL-PRESERVING TA-SPA λ=1 返回值（9549.8951）低于 λ=0 返回值（9550.4392），
  正好证明 λ=1 是 time-limit 产物，**不能用于最优性比较**（理论上 TA(λ1)* ≥ TA(λ0)*）。

### TA-SPA 合并目标随 λ 单调微增（UPROUND 实测）
- λ=0: 9838.0725 → λ=1: 9838.9533 → λ=2: 9839.8312；base QMA 项不动（≈9838.075）。
- PA-QMA 目标随 λ 大幅下降是其目标口径（ΣQ^PA）所致，与 TA-SPA 合并口径不同，不可直接比大小。

## 产出清单

| 文件 | 说明 |
|------|------|
| solutions_repaired_v11/*.json | 20 个修复后正式结果 JSON（含 wrapper/native 分离、diff 修正） |
| solutions/*.json | 原始 v1.0 结果 JSON（保留，不覆盖） |
| logs/*__native.json | 20 个 HiGHS 原生日志 |
| results/ta_spa_stage_B_summary_v1.1.csv | 修复后 summary |
| results/ta_spa_stage_B_summary.csv | 原始 v1.0 summary（保留） |
| results/ta_spa_stage_B_constraints_audit.csv | 约束审计 |
| results/pa_vs_G5E_reconciliation.csv | PA 对账 |
| results/target_only_upper_bound_check.csv | TO 上界核验 |
| config/ta_spa_stage_B_config_frozen.json | 冻结配置快照 |
| ta_spa_stage_B_audit_v1.1.json | **最终审计（stage_B_gate={stage_gate}）** |
| ta_spa_stage_B_audit.json | 原始 v1.0 audit（保留） |
| evidence_manifest.csv | 全文件 hash + 元数据 manifest |
| code_snapshot/P34_TA_SPA_stageB.py | 代码快照 |
| code_snapshot/P34_TA_SPA_stageB_repair_v11.py | 修复脚本快照 |
| README_STAGE_B_v1.1.md | 本文件 |

## 禁令（不做）

- 不补跑 Target-only，不 warm-start，不运行 EXP/NEW-LOW，不扩展 λ 网格，不进入阶段 C；
- 不修改 Policy34 正文、摘要、VII、Conclusion 或 Fig. 8；
- 不声称 TA-SPA-QMA 优于任何基准；
- 不回填论文；Target-only 上界结论保持 NOT reached。

---
v1.1 修复：{REPAIR_RUN_ID}；原始 run_id：{orig_run_id}
"""
    (OUT_B / 'README_STAGE_B_v1.1.md').write_text(readme_v11, encoding='utf-8')
    print(f'[repair] README v1.1 written', flush=True)

    # ---------- 汇总 ----------
    print('\n' + '=' * 60)
    print(f'REPAIR SUMMARY ({REPAIR_RUN_ID})')
    print('=' * 60)
    print(f'  solutions processed:     {n_total}')
    print(f'  diff fields fixed:       {n_fixed_diff}')
    print(f'  UNKNOWN_NO_INCUMBENT:    {n_unknown_no_incumbent}')
    print(f'  |combined+native| max:   {max_diff:.2e}')
    print(f'  all < {MAX_DIFF}:    {all_diff_ok}')
    print(f'  stage_B_gate:            {stage_gate}')
    print(f'  manifest entries:        {len(manifest)}')
    print(f'  assertion failures:      {len(assertion_failures)}')
    if assertion_failures:
        for f in assertion_failures:
            print(f'    - {f}')
    print(f'  output dir:              {OUT_B}')
    print('=' * 60)


if __name__ == '__main__':
    main()
