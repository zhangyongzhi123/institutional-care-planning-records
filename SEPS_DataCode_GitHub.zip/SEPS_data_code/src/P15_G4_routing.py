# -*- coding: utf-8 -*-
"""Policy15 G4 前置: M=40 并集新建候选点的高德真实路由（v3/distance 驾车）。

安全与诚实规则（Policy15 论文AI确认指令 §2）:
  - key 只从环境变量 AMAP_WEB_KEY 或本地 .secrets/amap_web.key 读取；
    绝不写入代码、日志、JSON/CSV/Excel/README/交付包（日志只打印 key 指纹）。
  - --smoke 先跑 1 候选点 × 5 社区，人工确认配额/返回格式/坐标转换/时间单位后再全量。
  - 每条边记录: source/请求时间/起终点坐标版本/返回状态/travel time/失败原因。
  - 路由失败不得默认为 0，不得用代理时间静默替换:
      * 高德 code 1/2/3(无路/离路/境外) -> status=amap_unreachable, travel_min 留空
      * HTTP/网络重试仍失败             -> status=failed_network, fail_reason 填明文
  - 真实矩阵另存 travel_edges_newpoints_amap.csv + manifest(sha256)；
    代理矩阵另存 proxy_travel_newpoints.csv（旧版本保留，不覆盖、不混用）。
  - 候选集 = 两套需求各自贪心 M=40 的并集去重（因 R0>0 对集合不同，两套列表不完全一致）。

用法:
  python src/P15_G4_routing.py --smoke
  python src/P15_G4_routing.py --full
"""
import argparse
import csv
import hashlib
import json
import math
import os
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from fetch_travel_amap import wgs84_to_gcj02, haversine_km  # noqa: E402 复用标准转换

RAW = ROOT / 'data' / 'raw' / 'eldercare_inputs.xlsx'
G2 = ROOT / 'runs' / 'P15_G2'
OUTD = ROOT / 'data' / 'P15'
REAL_CSV = OUTD / 'travel_edges_newpoints_amap.csv'
PROXY_CSV = OUTD / 'proxy_travel_newpoints.csv'
MANIFEST = OUTD / 'newpoint_routing_manifest.json'
KEY_FILE = ROOT / '.secrets' / 'amap_web.key'
API = 'https://restapi.amap.com/v3/distance'
QPS_SLEEP = 0.35
RETRY_MAX = 5
BATCH = 100
DETOUR, SPEED_KMH = 1.25, 40.0

# 账号级 infocode（非边级失败，必须立即中止，不得伪装成边结果）
FATAL_INFOCODES = {'10001', '10002', '10003', '10009', '10014', '10020', '10021',
                   '10044', '20000', '20001', '20002', '20003'}


def load_key() -> str:
    k = os.getenv('AMAP_WEB_KEY', '').strip()
    if not k and KEY_FILE.exists():
        k = KEY_FILE.read_text(encoding='utf-8').strip().splitlines()[0].strip()
    if not k:
        sys.exit('未找到 key: 请设环境变量 AMAP_WEB_KEY 或写 .secrets/amap_web.key')
    return k


def key_fp(k: str) -> str:
    """只回显指纹（前4+后4），不回显完整 key。"""
    return f'{k[:4]}...{k[-4:]} (len={len(k)})'


def call_api(key, origins_gcj, dest_gcj):
    params = urllib.parse.urlencode({
        'origins': '|'.join(f'{lo:.6f},{la:.6f}' for lo, la in origins_gcj),
        'destination': f'{dest_gcj[0]:.6f},{dest_gcj[1]:.6f}',
        'type': 1, 'key': key})
    last = None
    for i in range(RETRY_MAX):
        try:
            req = urllib.request.Request(f'{API}?{params}',
                                         headers={'User-Agent': 'liuzhou-p15/1.0'})
            with urllib.request.urlopen(req, timeout=25) as resp:
                return json.loads(resp.read())
        except Exception as e:  # noqa: BLE001
            last = repr(e)
            time.sleep(1.5 * (2 ** i))
    return {'_network_error': last}


def union_sites(wide=False):
    """wide=False: 两套贪心 M=40 的并集（49点）；wide=True: 全部 117 候选点（G5-D 宽池）。"""
    if wide:
        return pd.read_excel(G2 / 'candidate_sites.xlsx', sheet_name='candidate_sites',
                             dtype={'township_code': str})
    order = []
    for f in ('greedy_trajectory_upround.csv', 'greedy_trajectory_total_preserving.csv'):
        tr = pd.read_csv(G2 / f)
        for sid in tr.head(40).site_id:
            if sid not in order:
                order.append(sid)
    sites = pd.read_excel(G2 / 'candidate_sites.xlsx', sheet_name='candidate_sites',
                          dtype={'township_code': str})
    sites = sites.set_index('site_id').loc[order].reset_index()
    return sites


def main():
    global REAL_CSV, PROXY_CSV, MANIFEST
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--smoke', action='store_true')
    g.add_argument('--full', action='store_true')
    ap.add_argument('--pool', choices=['union40', 'wide'], default='union40',
                    help='union40=两套贪心M=40并集49点(G4正式); wide=全部117候选点(G5-D宽池)')
    args = ap.parse_args()
    if args.pool == 'wide':
        REAL_CSV = OUTD / 'travel_edges_newpoints_amap_wide117.csv'
        PROXY_CSV = OUTD / 'proxy_travel_newpoints_wide117.csv'
        MANIFEST = OUTD / 'newpoint_routing_manifest_wide117.json'
    OUTD.mkdir(parents=True, exist_ok=True)

    key = load_key()
    print(f'key 指纹: {key_fp(key)}（完整 key 不入日志/交付物）')

    comm = pd.read_excel(RAW, sheet_name='communities', dtype={'community_id': str})
    c_pts = {r.community_id: (float(r.lon), float(r.lat)) for r in comm.itertuples()}
    c_gcj = {cid: wgs84_to_gcj02(*p) for cid, p in c_pts.items()}
    sites = union_sites(args.pool == 'wide')
    s_pts = {r.site_id: (float(r.lon), float(r.lat)) for r in sites.itertuples()}
    s_gcj = {sid: wgs84_to_gcj02(*p) for sid, p in s_pts.items()}
    print(f'候选点并集 {len(sites)} 个 × 社区 {len(c_pts)} = '
          f'{len(sites)*len(c_pts):,} OD 对, '
          f'{math.ceil(len(c_pts)/BATCH)*len(sites)} 请求')

    cids = list(c_pts)
    batches = [cids[i:i+BATCH] for i in range(0, len(cids), BATCH)]

    if args.smoke:
        sid = sites.site_id.iloc[0]
        c5 = cids[:5]
        for tag, cd, sd in [('raw_cgcs2000', c_pts, s_pts), ('gcj02', c_gcj, s_gcj)]:
            r = call_api(key, [cd[c] for c in c5], sd[sid])
            if '_network_error' in r:
                print(f'  [{tag}] NETWORK ERROR: {r["_network_error"]}')
                continue
            print(f'  [{tag}] status={r.get("status")} info={r.get("info")} '
                  f'infocode={r.get("infocode")}')
            res = {int(it['origin_id']): it for it in (r.get('results') or [])}
            for i, cid in enumerate(c5, 1):
                it = res.get(i, {})
                dm = it.get('duration')
                if dm is not None:
                    print(f'    {cid} -> {sid}: {float(dm)/60:.1f} min / '
                          f'{float(it.get("distance", 0))/1000:.2f} km / code={it.get("code")}')
                else:
                    print(f'    {cid} -> {sid}: 无路 code={it.get("code")}')
        print('[smoke] 完成——确认配额/坐标/单位后执行 --full')
        return

    # ---------- 代理矩阵快照（旧版本，供对照，不参与正式 G4 筛选） ----------
    prow = []
    for r in sites.itertuples():
        slo, sla = float(r.lon), float(r.lat)
        for cid in cids:
            clo, cla = c_pts[cid]
            pmin = haversine_km(slo, sla, clo, cla) * DETOUR / SPEED_KMH * 60.0
            prow.append((r.site_id, cid, round(pmin, 2), int(pmin <= 30.0)))
    pd.DataFrame(prow, columns=['site_id', 'community_id', 'proxy_travel_min',
                                'proxy_within_tau30']
                 ).to_csv(PROXY_CSV, index=False, encoding='utf-8-sig')
    print(f'代理矩阵快照 -> {PROXY_CSV.name}（旧版本保留）')

    # ---------- 全量真实路由（断点续传） ----------
    done = set()
    if REAL_CSV.exists():
        old = pd.read_csv(REAL_CSV, dtype={'site_id': str, 'community_id': str})
        done = set(zip(old.site_id, old.batch_idx))
        print(f'断点续跑: 已完成 {len(done)}/{len(sites)*len(batches)} 批')
    else:
        with open(REAL_CSV, 'w', newline='', encoding='utf-8') as fh:
            csv.writer(fh).writerow([
                'site_id', 'community_id',
                'origin_lon_cgcs2000', 'origin_lat_cgcs2000',
                'origin_lon_gcj02', 'origin_lat_gcj02',
                'dest_lon_gcj02', 'dest_lat_gcj02',
                'distance_m', 'duration_s', 'travel_min',
                'amap_code', 'status', 'request_ts', 'batch_idx',
                'fail_reason', 'source'])

    n_req = n_ok = n_unreach = n_fail = 0
    consec_fail = 0
    t0 = time.time()
    for r in sites.itertuples():
        sid = r.site_id
        slo, sla = s_pts[sid]
        glo, gla = s_gcj[sid]
        for bi, batch in enumerate(batches):
            if (sid, bi) in done:
                continue
            n_req += 1
            ts = datetime.now().isoformat(timespec='seconds')
            resp = call_api(key, [c_gcj[c] for c in batch], (glo, gla))
            if '_network_error' in resp:
                rows = [[sid, c, slo, sla, glo, gla, '', '', '', '', '',
                         'failed_network', ts, bi, resp['_network_error'], 'amap_v3_distance']
                        for c in batch]
                n_fail += len(rows)
                consec_fail += 1
            else:
                if str(resp.get('status')) != '1':
                    sys.exit(f"账号级错误，立即中止: info={resp.get('info')} "
                             f"infocode={resp.get('infocode')}（已完成批次已落盘，可续跑）")
                consec_fail = 0
                res = {int(it['origin_id']): it for it in (resp.get('results') or [])}
                rows = []
                for i, cid in enumerate(batch, 1):
                    clo, cla = c_pts[cid]
                    gclo, gcla = c_gcj[cid]
                    it = res.get(i, {})
                    dm = it.get('duration')
                    if dm is not None:
                        rows.append([sid, cid, slo, sla, glo, gla, gclo, gcla,
                                     int(it.get('distance', -1)), int(dm),
                                     round(float(dm) / 60.0, 1), it.get('code'),
                                     'ok', ts, bi, '', 'amap_v3_distance'])
                        n_ok += 1
                    else:
                        # 高德 code 1/2/3: 无路/离路过远/境外 —— 记录但不填时间
                        rows.append([sid, cid, slo, sla, glo, gla, gclo, gcla,
                                     '', '', '', it.get('code'),
                                     'amap_unreachable', ts, bi,
                                     f"amap code={it.get('code')}（无驾车路径，不填代理值）",
                                     'amap_v3_distance'])
                        n_unreach += 1
            with open(REAL_CSV, 'a', newline='', encoding='utf-8') as fh:
                csv.writer(fh).writerows(rows)
            if n_req % 60 == 0:
                el = time.time() - t0
                print(f'  {n_req}/{len(sites)*len(batches)} 批, '
                      f'ok={n_ok} unreachable={n_unreach} failed={n_fail}, '
                      f'{el/60:.1f}min')
            if consec_fail >= 3:
                sys.exit('连续 3 批网络失败，中止（已落盘可续跑；不得把失败当可达/不可达）')
            time.sleep(QPS_SLEEP)

    # ---------- manifest（hash + 质量统计） ----------
    df = pd.read_csv(REAL_CSV, dtype={'site_id': str, 'community_id': str})
    expected = len(sites) * len(cids)
    counts = df.status.value_counts().to_dict()
    manifest = {
        'generated_at': datetime.now().isoformat(timespec='seconds'),
        'source': 'amap_v3_distance (driving, type=1)',
        'key_source': 'env AMAP_WEB_KEY or .secrets/amap_web.key; key NOT recorded',
        'key_fingerprint': key_fp(key),
        'coord_system_origin': 'CGCS2000(workbook) ≈ WGS84',
        'coord_system_request': 'GCJ-02 (wgs84_to_gcj02 标准算法, 确定性可复算)',
        'time_unit': 'duration 秒 -> travel_min 分钟(1位小数); distance 米',
        'pool': args.pool,
        'n_sites_union_M40': len(sites),
        'site_ids': list(sites.site_id),
        'n_communities': len(cids),
        'expected_pairs': expected,
        'rows_written': len(df),
        'complete': len(df) == expected,
        'status_counts': counts,
        'failure_rate': round(float((df.status == 'failed_network').sum()) / len(df), 6),
        'unreachable_rate': round(float((df.status == 'amap_unreachable').sum()) / len(df), 6),
        'ok_rate': round(float((df.status == 'ok').sum()) / len(df), 6),
        'real_csv_sha256': hashlib.sha256(REAL_CSV.read_bytes()).hexdigest(),
        'proxy_csv_sha256': hashlib.sha256(PROXY_CSV.read_bytes()).hexdigest(),
        'proxy_policy': 'PROXY 仅作旧版本对照（great-circle×1.25÷40km/h），不参与 G4 正式筛选',
        'no_fill_rule': 'amap_unreachable/failed_network 的 travel_min 留空，下游按无边处理',
        'elapsed_s': round(time.time() - t0, 1),
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'=== 完成: {len(df)}/{expected} 行 -> {REAL_CSV.name} ===')
    print(f"  ok={counts.get('ok', 0)} unreachable={counts.get('amap_unreachable', 0)} "
          f"failed={counts.get('failed_network', 0)}; manifest -> {MANIFEST.name}")


if __name__ == '__main__':
    main()
