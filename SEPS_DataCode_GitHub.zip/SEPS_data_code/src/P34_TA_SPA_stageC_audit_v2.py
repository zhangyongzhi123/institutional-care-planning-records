# -*- coding: utf-8 -*-
"""阶段C 审计修订 v2（GPT6.1 2026-10-11 批准；不重解、不 warm-start、不改任何 T/y/z/S/w）。

六项指令：
  ① M4 认证措辞修正：UP 两端 kTimeLimit；TP 两端容差内 kOptimal（非零 gap），外部指标
     改善一律称"已审计返回分配之间的描述性比较"。M3 TP λ=1 缺口增加报告为返回解事实，
     并记录已知更好可行目标值（M1 解代入 M3 目标 9551.2695 ∈ [inc, bound]）。
  ② M4 尺度等价：reachable=edge（本实例严格成立）、不可达角色 N≡0 ⇒
     H_reach(T)=H_global(T)/α，α=Σ_R π/Σπ；M4≡M3 有效 λ_eff=λ/α。定位为权重尺度敏感性。
  ③ M5 Stage1/Stage2 独立记录：留存字段照录；未写盘字段标 NOT_RETAINED（不反推不重跑）；
     同批次 M6 同模型独立日志仅作旁证（CORROBORATION_ONLY）；两配置保留 BOUND_AWARE，
     TP Stage2 kOptimal 不认证 Stage1 H 精确最优。
  ④ M5 Stage2 三条件审计：w≤min(N,h)（允许 w<min，不要求逐项饱和）、Σωw≥H_inc、
     真实 H(T)≥H_inc。
  ⑤ claim 表 v2：M5 vs M1 百分比（缺口 −11.27%/−10.97%，QMA −1.86%/−1.82%，
     支出 −40,200/+600），全部标描述性权衡，不称 outperforms。
  ⑥ manifest 排除自身；定稿后生成；独立逐行验证；区分 24 配置 / 26 solver 调用。
"""
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from P34_common import RUN_G5, get_P_variant  # noqa: E402
from P15_G4_joint_allocation import build_keys, CT  # noqa: E402

OUT_C = ROOT / 'experiments' / 'Policy34_TA_SPA_QMA_v1' / 'stage_C'
FIX_ID = f'STAGE_C_AUDIT_V2__{time.strftime("%Y%m%d_%H%M%S")}'
M1, M2, M3, M4, M5, M6 = ('M1_BASE_QMA', 'M2_PA_QMA', 'M3_TA_SPA_GLOBAL',
                          'M4_TA_SPA_REACHABLE', 'M5_TARGET_CONSTRAINED',
                          'M6_TARGET_ONLY')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load_sol(method, dem, lam=None):
    name = f'TA_C__{method}' + (f'__lam{lam:g}' if lam is not None else '') \
        + f'__{dem}__B50M.json'
    return json.loads((OUT_C / 'solutions' / name).read_text(encoding='utf-8'))


def main():
    # ========== 0. 重建冻结信号（确定性复算，不求解），用于 w 审计与恒等验证 ==========
    omega_g, omega_r, h_map, alpha, roles = {}, {}, {}, {}, {}
    for dem in ('upround', 'total_preserving'):
        P, _ext = get_P_variant('NEW', dem)
        tref = json.loads((RUN_G5 / f'E__Tref__{dem}__B50M.json').read_text(encoding='utf-8'))
        keys = build_keys(P)
        keyset = set(keys)
        T_ref = {tuple(k.split('|')): int(v) for k, v in tref['T_ref'].items()}
        T_ref = {e: v for e, v in T_ref.items() if e in keyset}
        R_sig = P.R_signal(T_ref)
        V_sig = P.V_signal()
        pi_sig = P.pi_signal(R_sig, V_sig)
        rl = [r for r in P.L if P.L[r] > 0]
        pi_sum = sum(pi_sig.get(r, 0.0) for r in rl)
        og = {r: pi_sig.get(r, 0.0) / pi_sum for r in rl}
        reach = {(j, k) for a in P.facilities for j in P.communities for k in CT
                 if P.hard_chi(a, j, k)[0] and P.L.get((j, k), 0) > 0}
        pi_r = sum(pi_sig.get(r, 0.0) for r in reach)
        orr = {r: (pi_sig.get(r, 0.0) / pi_r if r in reach else 0.0) for r in rl}
        hm = {r: 0.5 * P.L[r] for r in rl}
        omega_g[dem], omega_r[dem], h_map[dem] = og, orr, hm
        alpha[dem] = pi_r / pi_sum
        roles[dem] = rl

    # ========== ③④ M5 stage 留存审计 + Stage2 三条件 w 审计 ==========
    m5_audit = {}
    for dem in ('upround', 'total_preserving'):
        s5 = load_sol(M5, dem)
        s6 = load_sol(M6, dem)
        T_pos = {tuple(k.split('|')): int(v) for k, v in s5['T_pos'].items()}
        N = {}
        for (a, j, k), t in T_pos.items():
            N[(j, k)] = N.get((j, k), 0) + t
        w_rec = {tuple(k.split('|')): float(v) for k, v in (s5.get('w_rec') or {}).items()}
        hm, og = h_map[dem], omega_g[dem]
        # 三条件
        viol_upper, max_diff = [], 0.0
        for r, w in w_rec.items():
            n_r = N.get(r, 0)
            h_r = hm[r]
            if w > n_r + 1e-7 or w > h_r + 1e-7:
                viol_upper.append({'role': f'{r[0]}|{r[1]}', 'w': w, 'N': n_r, 'h': h_r})
            max_diff = max(max_diff, abs(w - min(n_r, h_r)))
        sum_omega_w = sum(og.get(r, 0.0) * w for r, w in w_rec.items())
        H_true = sum(og.get(r, 0.0) * min(N.get(r, 0), hm[r]) for r in hm)
        H_inc = s5['H1_incumbent']
        # 与 JSON 已存字段交叉核对
        tam = s5['ta_metrics']
        check = {
            'H_true_recomputed_vs_json': abs(H_true - tam['H_T_global']),
            'sumomega_w_vs_json': abs(sum_omega_w - tam['target_reward_from_w_vars']),
        }
        audit5 = {
            'config': s5['config'],
            'certification_retained': s5.get('certification'),
            'stage1_native_status': 'NOT_RETAINED',
            'stage1_native_objective': 'NOT_RETAINED',
            'stage1_dual_bound': 'NOT_RETAINED',
            'stage1_gap': 'NOT_RETAINED',
            'stage1_wall_s': 'NOT_RETAINED',
            'stage1_full_allocation': 'NOT_RETAINED',
            'stage1_retained_only': {
                'H1_incumbent_used_as_stage2_lower_bound': H_inc,
                'source_note': '主脚本 solve_m5 运行时持有 Stage1 native 对象，但正式 JSON/log '
                               '仅写盘 H1_incumbent 与 certification；不反推、不重跑'},
            'stage2_retained': {
                'native_status': s5.get('native_status'),
                'native_objective': s5.get('native_objective'),
                'dual_bound': s5.get('native_bound'),
                'gap': s5.get('native_gap'),
                'wrapper_status': s5.get('wrapper_status'),
                'wall_s_total_stage1_plus_stage2': s5.get('wall_s'),
                'stage2_individual_wall_s': 'NOT_RETAINED',
                'H_lower_bound_imposed': H_inc,
            },
            'm6_corroboration_not_certification': {
                'M6_config': s6['config'],
                'M6_native_status': s6.get('native_status'),
                'M6_incumbent_H': s6.get('ta_metrics')['H_T_global'],
                'M6_dual_bound_H': None,  # M6 bound 是 H 上界，取 native_bound 反号
                'M6_gap': s6.get('native_gap'),
                'abs_H1inc_minus_M6_incumbent': abs(H_inc - s6['ta_metrics']['H_T_global']),
                'note': ('M5 Stage1 与 M6 为同约束同模型 max H；两者 incumbent 差 <1e-12，'
                         '但 M6 gap 非零(容差终止)，仅旁证，不认证 Stage1 精确最优')},
            'stage2_w_three_condition_audit': {
                'w_need_not_equal_minNh': True,
                'reason': ('Stage2 最大化基础QMA、w 仅经 Σωw≥H_inc 约束保底，'
                           'w 不再被最大化，故允许 w<min(N,h)'),
                'max_abs_w_minus_minNh': max_diff,
                'n_w_upper_bound_violations': len(viol_upper),
                'violations_head': viol_upper[:5],
                'condition_a_w_le_minNh': not viol_upper,
                'sum_omega_w_from_w_vars': sum_omega_w,
                'H1_lower_bound': H_inc,
                'condition_b_sumomega_w_ge_Hinc': bool(sum_omega_w >= H_inc - 1e-7),
                'H_true_min_N_h': H_true,
                'condition_c_true_H_ge_Hinc': bool(H_true >= H_inc - 1e-7),
            },
            'cross_checks_vs_json': check,
            'certification_note': ('BOUND_AWARE_LEXICOGRAPHIC 保持；'
                                   'TP Stage2 kOptimal(gap 1.57e-6) 仅认证 Stage2 基础QMA目标，'
                                   '不认证 Stage1 H 精确最优；UP Stage2 kTimeLimit。'),
        }
        # M6 bound（H 尺度 = 反号 native_bound）
        b6 = s6.get('native_bound')
        audit5['m6_corroboration_not_certification']['M6_dual_bound_H'] = (
            -b6 if b6 is not None else None)
        m5_audit[dem] = audit5
        # 写回 solution JSON（仅追加审计字段，不改任何解向量）
        s5['stage_record_retention_v2'] = audit5
        s5['audit_v2_id'] = FIX_ID
        (OUT_C / 'solutions' / f'{s5["config"]}.json').write_text(
            json.dumps(s5, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
        lg = json.loads((OUT_C / 'logs' / f'{s5["config"]}__native.json').read_text(
            encoding='utf-8'))
        lg['stage_record_retention_v2'] = {
            'stage1_native': 'NOT_RETAINED',
            'stage2_native_status': s5.get('native_status'),
            'stage2_gap': s5.get('native_gap'),
            'H1_lower_bound': H_inc,
            'm6_corroboration_abs_diff': abs(H_inc - s6['ta_metrics']['H_T_global'])}
        (OUT_C / 'logs' / f'{s5["config"]}__native.json').write_text(
            json.dumps(lg, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
        pd.DataFrame([{
            'demand_set': dem, **audit5['stage2_w_three_condition_audit'],
            'certification': s5.get('certification'),
            'H1_incumbent': H_inc,
            'crosscheck_H_true_diff': check['H_true_recomputed_vs_json'],
            'crosscheck_sumomega_diff': check['sumomega_w_vs_json'],
        }]).to_csv(OUT_C / 'results' / f'm5_stage2_w_audit_{dem}.csv', index=False,
                   encoding='utf-8-sig')

    # ========== ② M4 尺度等价恒等验证（对全部已保存解） ==========
    equiv_rows = []
    for dem in ('upround', 'total_preserving'):
        for lam in (0.0, 1.0, 2.0):
            s = load_sol(M4, dem, lam)
            t = s['ta_metrics']
            hg, hr = t['H_T_global'], t['H_T_reachable']
            equiv_rows.append({
                'demand_set': dem, 'lam': lam,
                'alpha': alpha[dem],
                'H_global': hg, 'H_reachable': hr,
                'H_reach_times_alpha': hr * alpha[dem],
                'identity_abs_diff': abs(hr * alpha[dem] - hg),
                'identity_holds': abs(hr * alpha[dem] - hg) < 1e-9,
                'effective_lambda_lam_over_alpha': (lam / alpha[dem]) if lam > 0 else 0.0,
            })
    eq = pd.DataFrame(equiv_rows)
    eq.to_csv(OUT_C / 'results' / 'm4_rescaling_equivalence.csv', index=False,
              encoding='utf-8-sig')

    # ========== ① M3 TP λ=1 已知更好可行目标值证据 ==========
    m1_tp = load_sol(M1, 'total_preserving')
    m3_tp1 = load_sol(M3, 'total_preserving', 1.0)
    m1_base = m1_tp['ta_metrics']['base_qma_score']
    m1_Hg = m1_tp['ta_metrics']['H_T_global']
    m1_in_m3_obj = m1_base + 1.0 * m1_Hg
    m3_inc = m3_tp1['obj_pulp']
    m3_bound = -m3_tp1['native_bound']   # 最大化正向 bound
    m3_known_better = {
        'config': m3_tp1['config'],
        'M1_returned_allocation_objective_under_M3_lam1': m1_in_m3_obj,
        'M3_lam1_returned_incumbent': m3_inc,
        'M3_lam1_native_dual_bound_max_sense': m3_bound,
        'M1_alloc_known_better_by': m1_in_m3_obj - m3_inc,
        'within_reported_bound': bool(m1_in_m3_obj <= m3_bound + 1e-7),
        'M1_alloc_hard_constraints_audited': m1_tp['constraints_audit']['all_pass'],
        'interpretation': ('M3 TP λ=1 以容差 gapRel=1e-4 终止为 kOptimal，但 M1 的已审计可行'
                           '返回解在 M3 λ=1 目标下已知更高且落在所报 bound 内 ⇒ 缺口增加只能'
                           '报告为返回解之间的描述性事实，不称精确优化机制必然失败；'
                           'gap 认证的是各自优化目标，不认证外部政策覆盖指标'),
    }

    # ========== ⑤ claim 表 v2 ==========
    sm = pd.read_csv(OUT_C / 'results' / 'stage_C_summary_full.csv')
    rows = []
    m1g = sm[sm['method'] == M1].set_index('demand_set')
    m3g = sm[sm['method'] == M3].set_index(['demand_set', 'lambda'])
    m2g = sm[sm['method'] == M2].set_index(['demand_set', 'lambda'])
    m6g = sm[sm['method'] == M6].set_index('demand_set')

    for dem in ('upround', 'total_preserving'):
        b = m1g.loc[dem]
        for meth, lam in [(M3, 1.0), (M3, 2.0), (M4, 1.0), (M4, 2.0), (M5, None), (M6, None)]:
            q = (sm['method'] == meth) & (sm['demand_set'] == dem)
            q &= (sm['lambda'] == lam) if lam is not None else sm['lambda'].isna()
            r = sm[q].iloc[0]
            dH = r['H_T_global'] - b['H_T_global']
            dG = r['G_h_global'] - b['G_h_global']
            dQ = r['base_qma_score'] - b['base_qma_score']
            dSp = r['spend_first_year'] - b['spend_first_year']
            row = {
                'claim_version': 'v2',
                'demand_set': dem, 'method': meth, 'lambda': lam,
                'comparison_nature': ('DESCRIPTIVE_BETWEEN_AUDITED_RETURNED_ALLOCATIONS — '
                                      '非精确最优解间优势证明；gap 仅约束各自优化目标，'
                                      '不认证外部政策覆盖指标'),
                'native_status_method': r['native_status'],
                'native_status_M1': b['native_status'],
                'gap_method': r['gap'], 'gap_M1': b['gap'],
                'H_T_global': r['H_T_global'], 'G_h_global': r['G_h_global'],
                'dH_T_vs_M1': dH, 'dG_h_vs_M1': dG,
                'H_increase_pct_vs_M1': 100.0 * dH / b['H_T_global'],
                'gap_reduction_pct_vs_M1': -100.0 * dG / b['G_h_global'],
                'n_met_vs_M1': r['n_targets_met'] - b['n_targets_met'],
                'base_qma_vs_M1': dQ,
                'base_qma_loss_pct_vs_M1': -100.0 * dQ / b['base_qma_score'],
                'spend_inc_vs_M1': dSp,
                'spend_inc_within_100k': abs(dSp) <= 100_000.0,
                'SDM_vs_M1': r['SDM'] - b['SDM'],
                'travel_p90_vs_M1': r['travel_p90'] - b['travel_p90'],
                'burden_vs_M1': r['burden_mean'] - b['burden_mean'],
                'constraints_both_pass': bool(r['constraints_all_pass']
                                              and b['constraints_all_pass']),
                'musthave_H_T_not_decreased_descriptive': r['H_T_global']
                >= b['H_T_global'] - 1e-9,
                'musthave_G_h_not_increased_descriptive': r['G_h_global']
                <= b['G_h_global'] + 1e-9,
            }
            if meth == M4:
                s40 = sm[(sm['method'] == M4) & (sm['lambda'] == 0)
                         & (sm['demand_set'] == dem)].iloc[0]
                row['G_h_reach_self_scale_vs_M4lam0'] = (
                    r['G_h_reachable'] - s40['G_h_reachable'])
                row['alpha'] = alpha[dem]
                row['effective_lambda'] = (lam / alpha[dem]) if lam else 0.0
                m3r = m3g.loc[(dem, lam)]
                row['dG_h_global_vs_M3_same_lam'] = r['G_h_global'] - m3r['G_h_global']
                m2r = m2g.loc[(dem, lam)]
                row['dG_h_vs_M2_same_lam'] = r['G_h_global'] - m2r['G_h_global']
                row['dQ_vs_M2_same_lam'] = r['base_qma_score'] - m2r['base_qma_score']
                m4_tl = 'kTimeLimit' in str(r['native_status'])
                m1_tl = 'kTimeLimit' in str(b['native_status'])
                if m4_tl and m1_tl:
                    wside = 'M1 与 M4 均 kTimeLimit'
                elif m4_tl:
                    wside = 'M4 kTimeLimit / M1 kOptimal'
                elif m1_tl:
                    wside = 'M4 kOptimal(非零 gap) / M1 kTimeLimit'
                else:
                    wside = '两端容差内 kOptimal(非零 gap)'
                row['M4_certification_wording'] = (
                    f'{wside}——返回解比较，gap 不认证外部指标，无精确最优认证')
            if meth == M3:
                m2r = m2g.loc[(dem, lam)]
                row['dG_h_vs_M2_same_lam'] = r['G_h_global'] - m2r['G_h_global']
            if meth == M5:
                m6 = m6g.loc[dem]
                row['H_T_vs_M6'] = r['H_T_global'] - m6['H_T_global']
                row['base_qma_vs_M6'] = r['base_qma_score'] - m6['base_qma_score']
                row['lex_mechanism_demonstrated'] = bool(
                    abs(r['H_T_global'] - m6['H_T_global']) < 0.01
                    and r['base_qma_score'] > m6['base_qma_score'])
                row['M5_certification'] = 'BOUND_AWARE_LEXICOGRAPHIC（两口径均未精确认证Stage1）'
            rows.append(row)
    cv2 = pd.DataFrame(rows)
    cv2.to_csv(OUT_C / 'stage_C_claim_table.csv', index=False, encoding='utf-8-sig')

    # ========== audit addendum v2 ==========
    ap = OUT_C / 'stage_C_audit.json'
    audit = json.loads(ap.read_text(encoding='utf-8'))
    audit['audit_v2'] = {
        'fix_id': FIX_ID, 'fixed_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'no_resolve': True,
        'instruction_source': 'GPT6.1 2026-10-11 六项不重求解审计修复指令',
        'run_count_clarification': {
            'n_method_configs': 24,
            'n_solver_calls': 26,
            'note': ('24 个方法配置；M5 每配置调用 Stage1+Stage2 两次求解器 ⇒ 26 次 '
                     'HiGHS 调用（M5×2 配置各 2 次，其余 22 配置各 1 次）')},
        'm4_rescaling_equivalence': {
            'alpha_UPROUND': alpha['upround'], 'alpha_TOTAL_PRESERVING': alpha['total_preserving'],
            'effective_lambda': {
                'UPROUND': {'lam1': 1.0 / alpha['upround'], 'lam2': 2.0 / alpha['upround']},
                'TOTAL_PRESERVING': {'lam1': 1.0 / alpha['total_preserving'],
                                     'lam2': 2.0 / alpha['total_preserving']}},
            'reachable_equals_edge_roles': True,
            'identity': ('不可达角色 N≡0 且可达角色相对权重不变 ⇒ '
                         'H_reach(T)=H_global(T)/α；M4≡M3 使用有效 λ_eff=λ/α'),
            'identity_verified_all_saved_solutions': bool(eq['identity_holds'].all()),
            'identity_max_abs_diff': float(eq['identity_abs_diff'].max()),
            'positioning': ('M4 定位为归一化/权重尺度敏感性分析，不构成新的优先级结构；'
                            '不单独宣称 M4 创造新机制'),
            'evidence_csv': 'results/m4_rescaling_equivalence.csv'},
        'm5_stage_retention_and_w_audit': m5_audit,
        'm3_tp_lam1_known_better_feasible': m3_known_better,
        'm5_vs_m1_descriptive_tradeoff': {
            'UPROUND': {'gap_reduction_pct': -100.0 * (
                m1g.loc['upround', 'G_h_global']
                - sm[(sm['method'] == M5) & (sm['demand_set'] == 'upround')].iloc[0]['G_h_global'])
                / m1g.loc['upround', 'G_h_global'],
                'qma_loss_pct': 100.0 * (
                    sm[(sm['method'] == M5) & (sm['demand_set'] == 'upround')].iloc[0]['base_qma_score']
                    - m1g.loc['upround', 'base_qma_score'])
                / m1g.loc['upround', 'base_qma_score']},
            'wording': ('已审计返回分配之间的描述性权衡；~1.8% 基础QMA损失换 ~11% 加权目标'
                        '缺口下降；不宣称 outperforms，不称精确最优解间优势')},
        'wording_corrections': [
            '① 删除"M4 λ=1 两口径双端 kOptimal 认证"表述；外部指标改善均为返回解比较',
            '③ 两 M5 均保留 BOUND_AWARE；TP Stage2 kOptimal 不认证 Stage1',
            '④ M5 Stage2 w 允许不逐项饱和；三条件审计通过（a w≤min(N,h)；b Σωw≥Hinc；'
            'c 真实H(T)≥Hinc）',
            '⑤ M3 TP λ=1 缺口增加为返回解事实（存在已知更好可行目标值）'],
    }
    ap.write_text(json.dumps(audit, ensure_ascii=False, indent=2, default=str),
                  encoding='utf-8')

    # ========== README 重写结果摘要节 ==========
    rp = OUT_C / 'README_STAGE_C.md'
    readme = rp.read_text(encoding='utf-8')
    head = readme.split('## C2 结果摘要')[0].rstrip() + '\n'
    rp.write_text(head + f"""
## C2 结果摘要（audit v2，{FIX_ID}；不重解）

审计状态：24 个方法配置（26 次 HiGHS 调用：M5 每配置 Stage1+Stage2 两次）、全部有
incumbent、24/24 硬约束审计通过、M2 与 Policy34 G5-E 6/6 OBJECTIVE_MATCH。

**全部跨方法指标差异均为"已审计返回分配之间的描述性比较"，不是精确最优解间的优势
证明；gap 仅约束各方法自己的优化目标，不认证外部政策覆盖指标。禁止 outperforms。**

### M5 Target-constrained vs M1 Base-QMA（本轮主要发现）
| 指标 | UPROUND | TOTAL-PRESERVING |
|---|---|---|
| 目标内加权服务量 H_T 提高 | +31.18% | +29.39% |
| 加权目标缺口 G_h 下降 | −11.27% | −10.97% |
| 达标角色数增加 | +126 | +160 |
| 基础 QMA 得分变化 | −1.86%（−183.2） | −1.82%（−174.2） |
| 首年公共支出 | −40,200 元 | +600 元 |
| P90 旅行时间 | 29.8 min 不变 | 29.8 min 不变 |
| 平均负担 | 下降 | 下降 |
| SDM | 0.46432→0.43035 | 0.45633→0.42308 |

解释：目标优先规则以约 1.8% 基础资格得分换取约 11% 加权目标缺口下降，公共支出变化小。
M5 是**目标优先、基础资格第二的 bound-aware 两阶段模式**，与 M3 加性 TA-SPA 是
目标感知政策分配层的两种独立决策模式，M5 结果不得写成原 M3 已实现的性能。

### 求解器认证边界（audit v2 修正）
- **两配置 M5 均为 BOUND_AWARE_LEXICOGRAPHIC**：Stage1 独立原生状态/边界/gap 在正式
  JSON 中 NOT_RETAINED（运行时未写盘，不反推不重跑）；仅 H1_incumbent（Stage2 实际
  采用下界）留存。同批次 M6 同模型独立日志 incumbent 与 H1 差 <1e-12，仅作旁证
  （M6 gap 非零，不认证）。TP Stage2 kOptimal gap=1.57e-6 只认证 Stage2 基础QMA目标，
  **不认证 Stage1 H 精确最优**；UP Stage2 kTimeLimit。
- **M5 Stage2 的 w 不要求逐项饱和**（w 不再被最大化）：三条件审计通过——
  (a) w≤min(N,h) 无上界违例；(b) Σωw≥H1_inc；(c) 真实 H(T)≥H1_inc。
  max|w−min(N,h)|：UP 0.0891、TP 0.00374（非错误）。
- M4 λ=1：UP 两端（M1/M4）均 kTimeLimit；TP 两端为容差内 kOptimal（非零 gap）——
  均只能称返回解比较，无"双端认证"。
- M3 TP λ=1 的缺口增加（+0.0033）：M1 返回解代入 M3 λ=1 目标 = 9551.2695，
  高于 M3 返回 incumbent 9550.6855 且 ≤ 所报 bound 9551.6239 ⇒ 属容差终止下的
  返回解事实，不能称精确优化机制必然失败。

### M4 = M3 有效 λ 重标定（权重尺度敏感性）
本实例 reachable 角色 = edge 角色（恒等严格成立，不可达角色 N≡0），故
H_reach(T)=H_global(T)/α，α=0.4600(UP)/0.4730(TP)；M4 目标等价于 M3 使用
λ_eff=λ/α：λ=1→2.174(UP)/2.114(TP)，λ=2→4.347/4.229。
全部 6 个已保存 M4 解恒等差 <1e-9（results/m4_rescaling_equivalence.csv）。
M4 定位为归一化/权重尺度敏感性，不包装为新优先级结构。

### 方法贡献组织（第三层）
目标感知政策分配层在原实施可行域内提供两种政策—资格权衡模式：
M3 加性饱和奖励 / M4 权重尺度敏感性 / M5 目标优先两阶段（bound-aware）；
M2 原乘法 PA-QMA 对照（同 λ 下政策拉动更强：M4 G_h 比 M2 高 0.034–0.040，
但 M4 base_qma 高 26–34）；M6 纯目标诊断对照。实质贡献：显式区分 b/h/L、
达标后奖励饱和、可解释的政策—资格决策模式、两代表配置的实际幅度权衡、硬约束全保持。

### v2 新增/修订证据文件
- stage_C_claim_table.csv（v2：百分比 + 描述性标签 + 措辞修正）
- results/m4_rescaling_equivalence.csv（α 恒等验证）
- results/m5_stage2_w_audit_{{upround,total_preserving}}.csv（w 三条件）
- solutions/ 两个 M5 JSON 追加 stage_record_retention_v2（NOT_RETAINED 明示）
- stage_C_audit.json → audit_v2
- stage_C_manifest.csv 排除自身；results/stage_C_manifest_verification_v2.json 逐行验证
""", encoding='utf-8')

    # ========== ⑥ manifest（排除自身）+ 独立逐行验证 ==========
    shutil.copy2(Path(__file__), OUT_C / 'code_snapshot' / Path(__file__).name)
    # 先删旧 manifest 与旧验证，定稿后统一生成
    old_man = OUT_C / 'stage_C_manifest.csv'
    if old_man.exists():
        old_man.unlink()
    old_ver = list((OUT_C / 'results').glob('stage_C_manifest_verification*'))
    for v in old_ver:
        v.unlink()

    files = sorted(fp for fp in OUT_C.rglob('*')
                   if fp.is_file() and fp.name != 'stage_C_manifest.csv')
    mrows = [{
        'relative_path': fp.relative_to(OUT_C).as_posix(),
        'sha256': sha(fp), 'size_bytes': fp.stat().st_size,
        'run_id': audit['run_id'], 'audit_v2_id': FIX_ID,
    } for fp in files]
    pd.DataFrame(mrows).to_csv(old_man, index=False, encoding='utf-8-sig')

    # 独立验证：重新遍历磁盘，不使用生成时的内存值
    ver_rows = []
    n_exist = n_match = 0
    man = pd.read_csv(old_man)
    for r in man.itertuples():
        fp = OUT_C / r.relative_path
        exists = fp.exists()
        h_now = sha(fp) if exists else None
        ok = exists and (h_now == r.sha256)
        n_exist += int(exists)
        n_match += int(ok)
        ver_rows.append({'relative_path': r.relative_path, 'exists': exists,
                         'sha256_match': ok})
    extra_on_disk = sorted(
        fp.relative_to(OUT_C).as_posix() for fp in OUT_C.rglob('*')
        if fp.is_file() and fp.name != 'stage_C_manifest.csv'
        and fp.relative_to(OUT_C).as_posix() not in set(man['relative_path']))
    verification = {
        'verification_id': FIX_ID,
        'verified_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'manifest_file': 'stage_C_manifest.csv (excluded from itself)',
        'manifest_sha256': sha(old_man),
        'n_manifest_rows': len(man),
        'n_files_exist': n_exist, 'n_sha256_match': n_match,
        'all_rows_verified': bool(n_exist == n_match == len(man) and not extra_on_disk),
        'files_on_disk_not_in_manifest': extra_on_disk,
        'per_row': ver_rows,
    }
    (OUT_C / 'results' / 'stage_C_manifest_verification_v2.json').write_text(
        json.dumps(verification, ensure_ascii=False, indent=2), encoding='utf-8')

    print('=== audit v2 完成（未重解、未改任何解向量）===')
    corr_diffs = []
    for dem in ('upround', 'total_preserving'):
        h1 = m5_audit[dem]['stage1_retained_only'][
            'H1_incumbent_used_as_stage2_lower_bound']
        h6 = load_sol(M6, dem)['ta_metrics']['H_T_global']
        corr_diffs.append(abs(h1 - h6))
    print('③ M5 Stage1 NOT_RETAINED 已明示；两配置保持 BOUND_AWARE；'
          f'M6 旁证 |H1-H6| = {corr_diffs}')
    for dem in ('upround', 'total_preserving'):
        a5 = m5_audit[dem]['stage2_w_three_condition_audit']
        print(f'④ M5 {dem}: 条件a={a5["condition_a_w_le_minNh"]} '
              f'b={a5["condition_b_sumomega_w_ge_Hinc"]} '
              f'c={a5["condition_c_true_H_ge_Hinc"]} '
              f'maxdiff={a5["max_abs_w_minus_minNh"]:.6f}')
    print(f'② α: UP={alpha["upround"]:.6f}(λeff1={1/alpha["upround"]:.3f}), '
          f'TP={alpha["total_preserving"]:.6f}(λeff1={1/alpha["total_preserving"]:.3f}); '
          f'恒等全成立={bool(eq["identity_holds"].all())}')
    print(f'① M3 TPλ1 已知更好可行目标差={m3_known_better["M1_alloc_known_better_by"]:.6f}, '
          f'within bound={m3_known_better["within_reported_bound"]}')
    print(f'⑥ manifest {len(man)} 行；存在 {n_exist}；哈希匹配 {n_match}；'
          f'all_verified={verification["all_rows_verified"]}；manifest 自身 sha256 已记录')


if __name__ == '__main__':
    main()
