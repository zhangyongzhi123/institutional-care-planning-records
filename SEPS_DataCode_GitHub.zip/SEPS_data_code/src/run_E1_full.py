# -*- coding: utf-8 -*-
"""E1 全流程（柳州）：Lemma 1 判据 → 物理瓶颈 → B_0 → 7档预算扫描 → 代表点 → 政策菜单 → 图。

按 E1-E4阶段任务单_V2.md §6：
  预算 7 档 B_t = B_0 + α_t·B_scale, α∈{-0.10,0,0.10,0.25,0.50,0.75,1.00}，
  负预算移除并补非负档；B_0 = 固定 b,g 下全候选模型最低可实施支出（未证最优给界，
  不得称"准确门槛"）；B_0=0 时不作除数；物理无解先报瓶颈（最小割+瓶颈社区，
  不得静默调低 b —— Section V "B_crit=∞=物理瓶颈"）。
  代表点规则（提前固定）：同一支付负担上限 → 最大可达覆盖 98% 范围内最小化 SDM
  → 以实际支出打破平局。

⚠ 大圆 fallback 路网的运行仅用于验证代码逻辑（选项c），结果不进论文；
  OSM 就绪后 --use-osm true 重跑。

用法:
  python run_E1_full.py                # fallback 全流程（不可行时止于瓶颈+诊断模式演练）
  python run_E1_full.py --mode lemma   # 只跑 Lemma 1 + 瓶颈报告
"""
import argparse
import dataclasses
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pulp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import model_io  # noqa: E402
model_io.CARE_TYPES = ('NH', 'BK', 'WELLNESS')
from model_io import Params  # noqa: E402
from solvers import lemma1_maxflow  # noqa: E402

K_MAP = {'basic': 'NH', 'care': 'BK', 'wellness': 'WELLNESS'}
BIG_B = 1e12
ALPHAS = [-0.10, 0.0, 0.10, 0.25, 0.50, 0.75, 1.00]

# 预注册参数（与 P2 试跑一致 + 任务单§4；2026-09-26 返工修订：Π⁰/h_min/p_max 按V2口径）
CONFIG = {
    'Q0_weights': (0.4, 0.3, 0.3), 'd0': 30.0, 'gamma_p': 0.5,
    'theta': (0.5, 0.1, 1.0), 'lam_grid': (0.0, 0.5, 1.0, 1.5, 2.0),
    'omega_R': 0.5, 'v_norm_income_bounds': (3000.0, 5000.0),
    'pref': {'NH': 1.0, 'BK': 1.2, 'WELLNESS': 1.5},
    'tau': 30.0, 'h_min': 0.60, 'afford_cap': 1.0,
    'fixed_cost_per_bed_f': 200.0, 'demand_rate': 0.05,
    # V2 §1.3：Π⁰ = μ·Σ_k(p−c)C⁰ − F⁰（先减 F⁰ 取净额），μ=0.60（敏感性0.50/0.70）
    'mu_pi0': 0.60,
    # V2 §1.9：p^max 按床型给定；基准非约束（工作簿价格≤3500），保留分床型结构供政策实验
    'p_max_per_type': {'NH': 4000.0, 'BK': 4000.0, 'WELLNESS': 4000.0},
}


# ---------------- 输入加载 ----------------
def load_liuzhou(use_osm):
    xl = pd.ExcelFile(ROOT / 'data' / 'raw' / 'eldercare_inputs.xlsx')
    comm = xl.parse('communities', dtype={'community_id': str})
    dm = xl.parse('demand', dtype={'community_id': str})
    fac = xl.parse('facilities', dtype={'facility_id': str})
    cp = xl.parse('capacity_price', dtype={'facility_id': str})
    prj = xl.parse('projects', dtype={'project_id': str, 'facility_id': str})

    osm_path = ROOT / 'data' / 'raw' / 'travel_edges_osm.csv'
    if use_osm and osm_path.exists():
        ed = pd.read_csv(osm_path, dtype={'community_id': str, 'facility_id': str})
        ed = ed[ed.status == 'ok']
        net = 'amap'  # 高德 v3/distance 真实驾车路网（文件名沿用历史 travel_edges_osm）
    else:
        ed = xl.parse('travel_edges', dtype={'community_id': str, 'facility_id': str})
        net = 'gc_fallback'

    communities = comm.community_id.tolist()
    facilities = fac.facility_id.tolist()
    L = {(r.community_id, K_MAP[r.care_type]): int(r.L) for r in dm.itertuples()}
    b = {(r.community_id, K_MAP[r.care_type]): int(r.guarantee_b) for r in dm.itertuples()}
    I = {}
    for r in comm.itertuples():
        iv = float(r.income_value)
        if np.isnan(iv):
            iv = 4000.0
        I[r.community_id] = iv
    C0, p, cst, H = {}, {}, {}, {}
    for r in cp.itertuples():
        k = K_MAP[r.care_type]
        C0[(r.facility_id, k)] = int(r.capacity_C0)
        p[(r.facility_id, k)] = float(r.price_p)
        cst[(r.facility_id, k)] = float(r.unit_cost_c)
        H[(r.facility_id, k)] = float(r.quality_H)
    f_bed = CONFIG['fixed_cost_per_bed_f']
    F0 = {r.facility_id: f_bed * sum(C0[(r.facility_id, k)] for k in K_MAP.values())
          for r in fac.itertuples()}
    mu = CONFIG['mu_pi0']
    Pi0 = {a: mu * sum((p[(a, k)] - cst[(a, k)]) * C0.get((a, k), 0)
                       for k in K_MAP.values()) - F0[a] for a in F0}
    d = {(r.facility_id, r.community_id): float(r.travel_min) for r in ed.itertuples()}
    projects, deltaC, proj_of_fac = {}, {}, {}
    for r in prj.itertuples():
        projects[r.project_id] = {'facility': r.facility_id,
                                  'K': float(r.public_cost_K),
                                  'private': float(r.private_cost)}
        deltaC[(r.project_id, K_MAP[r.target_care])] = int(r.delta_capacity)
        proj_of_fac.setdefault(r.facility_id, []).append(r.project_id)

    P = Params(
        communities=communities, facilities=facilities,
        care_types=list(K_MAP.values()), L=L, b=b, I=I, C0=C0, p=p, cst=cst, H=H,
        F0=F0, Pi0=Pi0, d=d,
        U0={j: 0.0 for j in communities}, alpha={j: 0.0 for j in communities},
        beta_h={j: 0.0 for j in communities},
        tau=CONFIG['tau'], p_cap=dict(CONFIG['p_max_per_type']), h_min=CONFIG['h_min'],
        afford_cap=CONFIG['afford_cap'],
        projects=projects, deltaC=deltaC, proj_of_fac=proj_of_fac,
        W=CONFIG['Q0_weights'], d0=CONFIG['d0'], gamma_p=CONFIG['gamma_p'],
        theta=CONFIG['theta'], lam_grid=CONFIG['lam_grid'],
        omega_R=CONFIG['omega_R'], v_norm_bounds=CONFIG['v_norm_income_bounds'],
        pref=CONFIG['pref'], config=CONFIG,
    )
    coords = {r.community_id: (float(r.lon), float(r.lat)) for r in comm.itertuples()}
    fcoords = {r.facility_id: (float(r.lon), float(r.lat)) for r in fac.itertuples()}
    districts = {r.community_id: r.district_name for r in comm.itertuples()}
    sha = hashlib.sha256((ROOT / 'data' / 'raw' / 'eldercare_inputs.xlsx').read_bytes()).hexdigest()
    meta = {'net': net, 'sha256_inputs': sha, 'n_comm': len(communities),
            'n_fac': len(facilities), 'n_edges_loaded': len(d),
            'assumptions': {'c': '0.80p', 'F0': 'f=200元/床/期×总床',
                            'Pi0': 'mu=0.60×Σ(p−c)C0−F0 (V2§1.3, 2026-09-26返工修订)',
                            'h_min': 0.60, 'tau_min': 30.0,
                            'p_max': '按床型4000（V2§1.9结构；基准非约束，价格≤3500）',
                            'afford_cap': 1.0,
                            'H': '床型均匀0.60/0.70/0.80(工作簿scenario列)',
                            'net_source': 'amap v3/distance 2026-09-26, GCJ-02转换, ok=100%'}}
    return P, coords, fcoords, districts, meta


# ---------------- 联合 MILP（z,y 为决策变量） ----------------
def solve_joint(P, mode, B=BIG_B, coeff=None, v=None, sdm_v=None,
                time_limit=180, gap=0.01, fix_z=None, fix_y=None,
                T_floor=None, drop_ir=False, drop_chi=False):
    """mode: coverage | bcrit | maxq(需coeff,可选v) | sdm(需sdm_v)。
    T_floor: 逐边下界 {edge: n}（Sequential 机制 T ≥ T⁰）。
    drop_ir: 移除 S/IR/补贴（模型约束消融，财政仅 K(z) ≤ B；spend 仍按命题1事后重算作实施缺口）。
    drop_chi: 移除家庭接受门槛（H/价格帽/可负担比；τ 服务范围边宇宙保留——模型约束消融）。"""
    keys = []
    for (a, j) in P.d:
        if P.d[(a, j)] > P.tau:
            continue
        for k in P.care_types:
            if P.L[(j, k)] <= 0:
                continue
            if not drop_chi and not P.hard_chi(a, j, k)[0]:
                continue
            if P.C0.get((a, k), 0) > 0 or any(
                    P.deltaC.get((pid, k), 0) > 0 for pid in P.proj_of_fac.get(a, [])):
                keys.append((a, j, k))
    sense = pulp.LpMinimize if mode in ('bcrit', 'sdm') else pulp.LpMaximize
    prob = pulp.LpProblem('E1joint', sense)
    T = {e: pulp.LpVariable(f'T_{e[0]}_{e[1]}_{e[2]}', lowBound=0, cat='Integer') for e in keys}
    yv = {a: pulp.LpVariable(f'y_{a}', cat='Binary') for a in P.facilities}
    zv = {pid: pulp.LpVariable(f'z_{pid}', cat='Binary') for pid in P.projects}
    S = {a: pulp.LpVariable(f'S_{a}', lowBound=0) for a in P.facilities}

    for pid, info in P.projects.items():
        prob += zv[pid] <= yv[info['facility']]
    if fix_z:
        for pid, zp in fix_z.items():
            prob += zv[pid] == int(zp)
    if fix_y:
        for a, yy in fix_y.items():
            prob += yv[a] == int(yy)

    for a in P.facilities:
        for k in P.care_types:
            add = pulp.lpSum(P.deltaC.get((pid, k), 0) * zv[pid]
                             for pid in P.proj_of_fac.get(a, []))
            prob += pulp.lpSum(T[(a, j, k)] for j in P.communities
                               if (a, j, k) in T) <= P.C0.get((a, k), 0) + add
    for j in P.communities:
        for k in P.care_types:
            if P.L[(j, k)] <= 0:
                continue
            s = pulp.lpSum(T[(a, j, k)] for a in P.facilities if (a, j, k) in T)
            prob += s >= P.b[(j, k)]
            prob += s <= P.L[(j, k)]
    for e in keys:
        prob += T[e] <= P.L[(e[1], e[2])] * yv[e[0]]
    if T_floor:
        for e, f in T_floor.items():
            if f > 0 and e in T:
                prob += T[e] >= int(f)
    Kz = pulp.lpSum(P.projects[pid]['K'] * zv[pid] for pid in P.projects)
    if drop_ir:
        prob += Kz <= B
    else:
        for a in P.facilities:
            rev = pulp.lpSum((P.p[(a, k)] - P.cst[(a, k)]) * T[(a, j, k)]
                             for j in P.communities for k in P.care_types if (a, j, k) in T)
            priv = pulp.lpSum(P.projects[pid]['private'] * zv[pid]
                              for pid in P.proj_of_fac.get(a, []))
            prob += S[a] >= P.Pi0[a] * yv[a] + P.F0[a] * yv[a] + priv - rev
        prob += Kz + pulp.lpSum(S.values()) <= B

    if mode == 'coverage':
        prob += pulp.lpSum(T.values())
    elif mode == 'bcrit':
        prob += Kz + pulp.lpSum(S.values())
    elif mode == 'maxq':
        prob += pulp.lpSum(coeff[e] * T[e] for e in keys)
        if v is not None:
            prob += pulp.lpSum(T.values()) == v
    elif mode == 'sdm':
        D = sum(P.L.values())
        ej = {}
        for j in P.communities:
            ej[j] = pulp.LpVariable(f'e_{j}', lowBound=0)
            Nj = pulp.lpSum(T[(a, j, k)] for a in P.facilities
                            for k in P.care_types if (a, j, k) in T)
            Dj = sum(P.L[(j, k)] for k in P.care_types)
            dev = Nj / sdm_v - Dj / D
            prob += ej[j] >= dev
            prob += ej[j] >= -dev
        prob += pulp.lpSum(T.values()) == sdm_v
        prob += pulp.lpSum(ej.values())
    else:
        raise ValueError(mode)

    prob.solve(pulp.HiGHS(msg=0, timeLimit=time_limit, gapRel=gap, threads=1))
    st = {'Optimal': 'OPTIMAL', 'Not Solved': 'FEASIBLE_TIMEOUT',
          'Infeasible': 'PROVEN_INFEASIBLE', 'Unbounded': 'UNKNOWN'}.get(
        pulp.LpStatus[prob.status], 'UNKNOWN')
    out = {'status': st, 'n_T': len(keys), 'time_limit': time_limit}
    if st == 'OPTIMAL':
        out['T'] = {e: int(round(T[e].value())) for e in keys}
        out['y'] = {a: int(round(yv[a].value())) for a in P.facilities}
        out['z'] = {pid: int(round(zv[pid].value())) for pid in P.projects}
        # coverage/maxq 模式下 S 变量无目标压力、取值任意，读数须按命题1口径
        # 事后重算：spend = K(z) + Σ[D_a]₊（Ψ 最低补贴口径，P0 已验证）
        from solvers import psi
        Psi, _det = psi(P, out['T'], out['z'], out['y'])
        out['S'] = _det
        out['buildK'] = sum(P.projects[pid]['K'] * out['z'][pid] for pid in P.projects)
        out['subsidy'] = max(0.0, Psi - out['buildK'])
        out['spend'] = float(Psi)
        out['v'] = sum(out['T'].values())
    return out


# ---------------- 指标 ----------------
def metrics_from_T(P, T):
    N_j = {j: sum(T.get((a, j, k), 0) for a in P.facilities for k in P.care_types)
           for j in P.communities}
    N = sum(N_j.values())
    D = sum(P.L.values())
    m = {'v': N, 'D': D, 'coverage': N / D if D else None}
    if N > 0:
        m['SDM'] = 0.5 * sum(abs(N_j[j] / N - sum(P.L[(j, k)] for k in P.care_types) / D)
                             for j in P.communities)
        tt, ww = [], []
        for (a, j, k), t in T.items():
            if t > 0:
                tt += [P.d[(a, j)]] * t
                ww += [P.p[(a, k)] / P.I[j]] * t
        m['travel_p90'] = float(np.percentile(tt, 90)) if tt else None
        m['burden_mean'] = float(np.mean(ww)) if ww else None
    else:
        m['SDM'] = None
        m['travel_p90'] = None
        m['burden_mean'] = None
    # 弱势（收入下 1/3 分位社区）与护理覆盖
    ival = sorted(P.I[j] for j in P.communities)
    thr = ival[len(ival) // 3]
    weak = {j for j in P.communities if P.I[j] <= thr}
    Dw = sum(P.L[(j, k)] for j in weak for k in P.care_types)
    Nw = sum(T.get((a, j, k), 0) for j in weak for a in P.facilities for k in P.care_types)
    m['weak_coverage'] = Nw / Dw if Dw else None
    Db = sum(P.L[(j, 'BK')] for j in P.communities)
    Nb = sum(T.get((a, j, 'BK'), 0) for a in P.facilities for j in P.communities)
    m['care_coverage'] = Nb / Db if Db else None
    return m


# ---------------- 瓶颈报告 ----------------
def bottleneck_report(P, k, lemma_res, z_all):
    feas1, val1 = lemma_res['feasible'], lemma_res['maxflow']
    req = sum(P.b[(j, k)] for j in P.communities)
    rep = {'k': k, 'required': req, 'maxflow_z0': val1, 'feasible_z0': feas1}
    feas2, val2, Sset2 = lemma1_maxflow(P, k, z_all, {a: 1 for a in P.facilities})
    rep['maxflow_z1_all_projects'] = val2
    rep['feasible_z1'] = feas2
    if feas2:
        rep['verdict'] = 'FEASIBLE_WITH_PROJECTS'
        return rep, None
    starved = sorted(j for j in Sset2 if P.b.get((j, k), 0) > 0)
    rep['verdict'] = 'B_crit_INF_PHYSICAL'
    rep['unserved_b'] = req - val2
    rep['n_starved'] = len(starved)
    byd = {}
    for j in starved:
        dist = DIST[j]
        byd.setdefault(dist, {'n': 0, 'b': 0})
        byd[dist]['n'] += 1
        byd[dist]['b'] += P.b[(j, k)]
    rep['starved_by_district'] = byd
    # 封锁原因分解（对饥饿社区）
    reason = {'no_facility_within_tau': 0, 'quality_or_price_blocked': 0, 'has_chi_edge': 0}
    for j in starved:
        n_chi = sum(1 for a in P.facilities
                    if P.d.get((a, j), 999) <= P.tau and P.hard_chi(a, j, k)[0])
        n_dist = sum(1 for a in P.facilities if P.d.get((a, j), 999) <= P.tau)
        if n_chi > 0:
            reason['has_chi_edge'] += 1
        elif n_dist > 0:
            reason['quality_or_price_blocked'] += 1
        else:
            reason['no_facility_within_tau'] += 1
    rep['starved_reason'] = reason
    rep['starved_ids'] = starved
    return rep, starved


# ---------------- 主流程 ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--use-osm', type=str, default='false', choices=['true', 'false'])
    ap.add_argument('--mode', type=str, default='full', choices=['lemma', 'full'])
    ap.add_argument('--time-limit', type=int, default=300)
    ap.add_argument('--gap', type=float, default=1e-4,
                    help='2026-09-26返工：全部求解 gap=1e-4（审计返工2）')
    args = ap.parse_args()
    use_osm = args.use_osm == 'true'

    global DIST
    t0 = time.time()
    P, coords, fcoords, districts, meta = load_liuzhou(use_osm)
    DIST = districts
    print(f"=== E1 全流程 ({meta['net']}) ===")
    print(f"  {meta['n_comm']} 社区 × {meta['n_fac']} 机构, 边={meta['n_edges_loaded']}")
    print(f"  输入SHA-256={meta['sha256_inputs'][:16]}...")

    out_dir = ROOT / 'runs' / f"E1_liuzhou_{time.strftime('%Y%m%d_%H%M%S')}"
    out_dir.mkdir(parents=True, exist_ok=True)

    # ---- S1: Lemma 1 (z=0) ----
    z0 = {pid: 0 for pid in P.projects}
    lemma = {}
    for k in P.care_types:
        t1 = time.time()
        feas, val, Sset = lemma1_maxflow(P, k, z0, {a: 1 for a in P.facilities})
        lemma[k] = {'feasible': bool(feas), 'maxflow': val,
                    'required': sum(P.b[(j, k)] for j in P.communities),
                    'n_starved_side': len([j for j in Sset if P.b.get((j, k), 0) > 0]),
                    'time_s': round(time.time() - t1, 2)}
        print(f"  Lemma1 {k}: maxflow={val}, Σb={lemma[k]['required']}, "
              f"feasible={feas} ({lemma[k]['time_s']}s)")

    # ---- S2: NH 不可行 → z=1 复检 + 瓶颈报告 ----
    bottleneck = None
    if not lemma['NH']['feasible']:
        print('  NH 不可行 → 全项目激活 (z=1) 复检...')
        z_all = {pid: 1 for pid in P.projects}
        bottleneck, starved = bottleneck_report(P, 'NH', lemma['NH'], z_all)
        print(f"  z=1 maxflow={bottleneck['maxflow_z1_all_projects']} "
              f"(need={bottleneck['required']}), verdict={bottleneck['verdict']}")
        if bottleneck['verdict'] == 'B_crit_INF_PHYSICAL':
            print(f"  瓶颈: {bottleneck['n_starved']} 社区缺口 {bottleneck['unserved_b']} 床")
            print(f"  原因: {bottleneck['starved_reason']}")
            print('  >> B_crit = ∞（物理瓶颈），按规格不得调低 b，预算扫描转诊断模式演练')
    (out_dir / 'e1_lemma.json').write_text(
        json.dumps({'lemma': lemma, 'bottleneck': bottleneck}, ensure_ascii=False, indent=2),
        encoding='utf-8')

    if args.mode == 'lemma' or (bottleneck and bottleneck['verdict'] == 'B_crit_INF_PHYSICAL'
                                and args.mode != 'diagonly'):
        if args.mode == 'lemma':
            meta.update({'elapsed_s': round(time.time() - t0, 1)})
            (out_dir / 'e1_run_meta.json').write_text(
                json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
            print(f'  -> {out_dir}')
            return

    # ---- S3: 诊断模式（b:=0，仅验证代码逻辑，不进论文） ----
    print('\n=== S3 诊断模式 (b:=0, DIAGNOSTIC — 不进论文) ===')
    Pd = dataclasses.replace(P, b={kk: 0 for kk in P.b})
    diag = {'note': 'DIAGNOSTIC b=0: 仅验证预算扫描/代表点/政策菜单代码逻辑; '
                    '真实路网=高德amap v3/distance (2026-09-26, ok率100%)'}

    # S3.0 存量基准 (z=0) — 同时作 PA 参照 T_ref
    r_stock = solve_joint(Pd, 'coverage', B=BIG_B, fix_z={pid: 0 for pid in Pd.projects},
                          time_limit=args.time_limit, gap=args.gap)
    print(f"  存量基准(z=0): {r_stock['status']}, v={r_stock.get('v')}, "
          f"耗时{time.time()-t0:.0f}s累计")
    diag['stock_baseline'] = {'status': r_stock['status'], 'v': r_stock.get('v'),
                              'spend': r_stock.get('spend')}

    # S3.1 全候选满预算 → B_scale
    r_full = solve_joint(Pd, 'coverage', B=BIG_B, time_limit=args.time_limit, gap=args.gap)
    print(f"  满预算全候选: {r_full['status']}, v={r_full.get('v')}, "
          f"spend={r_full.get('spend')}")
    diag['full_build'] = {'status': r_full['status'], 'v': r_full.get('v'),
                          'spend': r_full.get('spend'),
                          'buildK': r_full.get('buildK'), 'subsidy': r_full.get('subsidy')}
    spend_full = r_full.get('spend') or 0
    B_scale = max(1.0, spend_full - 0.0)  # 诊断 B_0=0
    diag['B_scale'] = B_scale

    # S3.2 7 档预算扫描（任务单：负预算档移除，由 α=0 非负档承担）
    levels = []
    seen_B = set()
    for al in ALPHAS:
        Bt_raw = 0.0 + al * B_scale
        if Bt_raw < 0:
            levels.append({'alpha': al, 'B': None, 'removed': 'negative_budget'})
            continue
        Bt = round(Bt_raw)
        if Bt in seen_B:
            continue
        seen_B.add(Bt)
        levels.append({'alpha': al, 'B': Bt})
    print(f"  预算档: {[(lv['alpha'], lv['B']) for lv in levels]}")

    menu = []
    for lv in levels:
        if lv.get('removed'):
            # 任务单：负预算档移除，不求解、仅留痕
            menu.append({'alpha': lv['alpha'], 'B': None,
                         'status': 'REMOVED_NEGATIVE_BUDGET'})
            print(f"    α={lv['alpha']:+.2f} 负预算档 → 移除（不求解）")
            continue
        t1 = time.time()
        r = solve_joint(Pd, 'coverage', B=lv['B'], time_limit=args.time_limit, gap=args.gap)
        row = {'alpha': lv['alpha'], 'B': lv['B'], 'status': r['status'],
               'buildK': r.get('buildK'), 'subsidy': r.get('subsidy'),
               'spend': r.get('spend'), 'time_s': round(time.time() - t1, 1)}
        if r['status'] == 'OPTIMAL':
            row.update({kk: vv for kk, vv in metrics_from_T(Pd, r['T']).items()})
            row['n_fac'] = sum(r['y'].values())
            row['n_proj'] = sum(r['z'].values())
            row['projects'] = ';'.join(pid for pid, zz in r['z'].items() if zz)
            row['facilities'] = ';'.join(a for a, yy in r['y'].items() if yy)
        menu.append(row)
        print(f"    α={lv['alpha']:+.2f} B={lv['B']:.0f}: {r['status']} "
              f"v={row.get('v')}, SDM={row.get('SDM')}, spend={row.get('spend')}")
    menu_df = pd.DataFrame(menu)
    menu_df.to_csv(out_dir / 'e1_policy_menu.csv', index=False, encoding='utf-8-sig')

    # S3.3 代表点规则（提前固定）：负担上限(χ已逐边强制,记录) → 98%覆盖内min SDM → 实际支出
    pos = [r for r in menu if r['status'] == 'OPTIMAL' and (r.get('v') or 0) > 0]
    rep_point = None
    if pos:
        vmax = max(r['v'] for r in pos)
        elig = [r for r in pos if r['v'] >= 0.98 * vmax]
        rep_point = min(elig, key=lambda r: (r['SDM'], r['spend']))
        print(f"  代表点: α={rep_point['alpha']}, v={rep_point['v']} "
              f"(vmax={vmax}, 98%门槛={0.98*vmax:.1f}), SDM={rep_point['SDM']:.4f}")
        # SDM 精修 MILP（ΣT 固定 = rep v）
        r_sdm = solve_joint(Pd, 'sdm', B=BIG_B, sdm_v=rep_point['v'],
                            time_limit=args.time_limit, gap=args.gap)
        if r_sdm['status'] == 'OPTIMAL':
            m_sdm = metrics_from_T(Pd, r_sdm['T'])
            print(f"  SDM 精修: {rep_point['SDM']:.4f} → {m_sdm['SDM']:.4f}")
            diag['sdm_refine'] = {'before': rep_point['SDM'], 'after': m_sdm['SDM']}
        else:
            diag['sdm_refine'] = {'status': r_sdm['status']}
    diag['representative'] = ({'alpha': rep_point['alpha'], 'B': rep_point['B']}
                              if rep_point else None)

    # S3.4 QMA vs PA-QMA（同预算同 z,y 同截面）
    qma_pa = None
    if r_full['status'] == 'OPTIMAL' and r_full['v'] > 0:
        keys = [e for e in r_full['T']]
        Q0_map = {e: Pd.Q0(*e) for e in keys}
        delta0 = max(0.01, float(np.std(list(Q0_map.values()))))
        Qbar, _ = Pd.qma_Qbar(Q0_map, delta0)
        R_sig = Pd.R_signal(r_stock['T'])
        V_sig = Pd.V_signal()
        pi_sig = Pd.pi_signal(R_sig, V_sig)
        fz, fy = r_full['z'], r_full['y']
        r_qma = solve_joint(Pd, 'maxq', B=r_full['spend'], coeff=Qbar, v=r_full['v'],
                            fix_z=fz, fix_y=fy, time_limit=args.time_limit, gap=args.gap)
        QPA2 = Pd.QPA(Qbar, pi_sig, 2.0)
        r_pa = solve_joint(Pd, 'maxq', B=r_full['spend'], coeff=QPA2, v=r_full['v'],
                           fix_z=fz, fix_y=fy, time_limit=args.time_limit, gap=args.gap)
        if r_qma['status'] == 'OPTIMAL' and r_pa['status'] == 'OPTIMAL':
            rows = []
            for j in Pd.communities:
                nq = sum(r_qma['T'].get((a, j, k), 0) for a in Pd.facilities for k in Pd.care_types)
                np_ = sum(r_pa['T'].get((a, j, k), 0) for a in Pd.facilities for k in Pd.care_types)
                rows.append({'community_id': j, 'district': DIST[j],
                             'N_QMA': nq, 'N_PA': np_, 'diff': np_ - nq,
                             'D': sum(Pd.L[(j, k)] for k in Pd.care_types)})
            qma_df = pd.DataFrame(rows)
            qma_df.to_csv(out_dir / 'e1_qma_pa_diff.csv', index=False, encoding='utf-8-sig')
            qma_pa = {'status': 'ok', 'delta0': round(delta0, 4),
                      'sum_diff': int(qma_df['diff'].sum())}
            print(f"  QMA vs PA(λ=2): Σdiff={qma_df['diff'].sum()} "
                  f"(受影响社区 {(qma_df['diff'] != 0).sum()})")
        else:
            qma_pa = {'status': r_qma['status'] + '/' + r_pa['status']}
    diag['qma_pa'] = qma_pa

    # ---- S4: 图（诊断版） ----
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman'],
                             'font.size': 8})
        fig_dir = out_dir / 'figures'
        fig_dir.mkdir(exist_ok=True)

        # Fig.8 前沿
        ok = menu_df[menu_df.status == 'OPTIMAL'].copy()
        if len(ok):
            fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.9))
            ax = axes[0]
            ax.plot(ok['B'] / 1e4, ok['coverage'] * 100, 'o-', color='#1a1a1a', ms=4)
            for _, r in ok.iterrows():
                ax.annotate(f"{r['spend']/1e4:.0f}", (r['B'] / 1e4, r['coverage'] * 100),
                            textcoords='offset points', xytext=(0, 4), fontsize=6)
            ax.set_xlabel('Budget cap $B$ (10k CNY, labels = actual spend)')
            ax.set_ylabel('Coverage (%)')
            ax.set_title('(a) Budget response', fontsize=9)
            ax = axes[1]
            ax.plot(ok['spend'] / 1e4, ok['SDM'], 's', color='#1a1a1a', ms=4)
            ax.set_xlabel('Actual spend (10k CNY)')
            ax.set_ylabel('SDM')
            ax.set_title('(b) Equity vs spend (discrete)', fontsize=9)
            fig.tight_layout()
            fig.savefig(fig_dir / 'Fig8_diagnostic_frontier.pdf')
            fig.savefig(fig_dir / 'Fig8_diagnostic_frontier.png', dpi=600)
            plt.close(fig)

        # Fig.7 三面板地图（点云，无边界 — 不伪造区域）
        if r_stock['status'] == 'OPTIMAL' and qma_pa and qma_pa.get('status') == 'ok':
            N_stock = {j: sum(r_stock['T'].get((a, j, k), 0) for a in Pd.facilities
                              for k in Pd.care_types) for j in Pd.communities}
            qdf = qma_df.set_index('community_id')
            fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.4))
            for ax in axes:
                ax.set_aspect('equal')
                ax.set_xticks([]), ax.set_yticks([])
            for a, (lo, la) in fcoords.items():
                for ax in axes:
                    ax.scatter(lo, la, marker='^', s=6, c='#555555', zorder=2)
            sc = axes[0].scatter([coords[j][0] for j in Pd.communities],
                                 [coords[j][1] for j in Pd.communities],
                                 c=[max(0, sum(Pd.L[(j, k)] for k in Pd.care_types) - N_stock[j])
                                    for j in Pd.communities],
                                 s=5, cmap='Reds', zorder=3)
            axes[0].set_title('(a) Stock-only unmet demand', fontsize=9)
            plt.colorbar(sc, ax=axes[0], shrink=0.85)
            sc = axes[1].scatter([coords[j][0] for j in Pd.communities],
                                 [coords[j][1] for j in Pd.communities],
                                 c=[qdf.loc[j, 'diff'] for j in Pd.communities],
                                 s=5, cmap='RdBu', vmin=-15, vmax=15, zorder=3)
            axes[1].set_title('(b) PA-QMA $-$ QMA (same budget)', fontsize=9)
            plt.colorbar(sc, ax=axes[1], shrink=0.85)
            for pid, zz in r_full['z'].items():
                if zz:
                    fa = Pd.projects[pid]['facility']
                    lo, la = fcoords[fa]
                    axes[2].scatter(lo, la, marker='*', s=42, c='#c0392b', zorder=4)
            axes[2].set_title(f"(c) Activated projects (n={sum(r_full['z'].values())})",
                              fontsize=9)
            fig.suptitle('DIAGNOSTIC (b:=0; amap driving network 2026-09-26)',
                         fontsize=7, y=0.02)
            fig.tight_layout()
            fig.savefig(fig_dir / 'Fig7_diagnostic_map.pdf')
            fig.savefig(fig_dir / 'Fig7_diagnostic_map.png', dpi=600)
            plt.close(fig)
    except Exception as e:
        print(f'  [WARN] 出图失败: {e}')

    # ---- 汇总写出 ----
    meta.update({'diag': diag, 'elapsed_s': round(time.time() - t0, 1),
                 'solver': f'PuLP {pulp.__version__} + HiGHS, threads=1, gap={args.gap}',
                 'lemma': lemma, 'bottleneck': bottleneck})
    (out_dir / 'e1_budget_scan.json').write_text(
        json.dumps({'menu': menu, 'diag': diag}, ensure_ascii=False, indent=2, default=str),
        encoding='utf-8')
    (out_dir / 'e1_run_meta.json').write_text(
        json.dumps(meta, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(f'\n=== 完成 -> {out_dir} (总耗时 {time.time()-t0:.0f}s) ===')


if __name__ == '__main__':
    main()
