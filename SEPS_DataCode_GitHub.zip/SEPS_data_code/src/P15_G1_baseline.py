# -*- coding: utf-8 -*-
"""Policy15 G1: 统一存量基准 T⁰ 与残余 R⁰（两套需求分别重建）。

选择规则（§1.4 冻结，词典序四阶段，不得从结果倒推）：
  Stage1  max ΣT                       （z=0、当前合同、硬资格χ边、b:=0 诊断口径）
  Stage2  max Σ Q0_e·T_e   s.t. ΣT=v0            → Q̄* = Qsum*/v0
  Stage3  min SDM          s.t. ΣT=v0, 平均Q⁰ ≥ (1−τ_Q)·Q̄*   （τ_Q=0.02 预注册）
  Stage4  min Σ idx(e)·T_e s.t. Stage3 全部约束 + Σe_j ≤ Σe*+tol（固定边索引破同解）
  SDM = 0.5·Σ_j |N_j/ΣT − D_j/D|（社区聚合口径，与遗留 E1 metrics_from_T 一致）

输出（runs/P15_G1/）:
  config_frozen.json / baseline_T0_<set>.parquet + .csv / residual_R0_<set>.xlsx
  baseline_audit_<set>.json / P15_G1_comparison.json / run log

保障处理：T⁰ 按 b:=0 诊断口径（Policy15 §4），正式保障不可行证书（Lemma1 最大流）
单独报告；机构与财政缺口按命题 1 事后计算并年化（口径 A，见 accounting_policy.md）。

Stage4 诚实性规则：允许 FEASIBLE_TIMEOUT——超时解仍满足 Stage1–3 全部词典序约束
（它们是 Stage4 的约束），事后三断言（ΣT/avgQ⁰/SDM）强制通过；仅"固定索引最小"
性质未认证，audit 如实记录 status=FEASIBLE_TIMEOUT + HiGHS 原生 bound/gap，
绝不写成 OPTIMAL。
"""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pulp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from run_E1_full import load_liuzhou, CONFIG  # noqa: E402
from solvers import lemma1_maxflow, psi  # noqa: E402
import model_io  # noqa: E402
model_io.CARE_TYPES = ('NH', 'BK', 'WELLNESS')

OUT = ROOT / 'runs' / 'P15_G1'
DATA_P15 = ROOT / 'data' / 'P15'
K_MAP = {'basic': 'NH', 'care': 'BK', 'wellness': 'WELLNESS'}
LEGACY2NEU = {'NH': 'TYPE1', 'BK': 'TYPE2', 'WELLNESS': 'TYPE3'}
SETS = {'upround': 'demand_upround.csv', 'total_preserving': 'demand_total_preserving.csv'}

# ---- 冻结配置（G1 开始前写入并进 hash；不得从结果倒推） ----
# 修订记录 v2（2026-09-28）：Stage4 timeLimit 1800→3600s（首轮 total_preserving
# 在 1800s 超时）；四阶段词典序规则、τ_Q=0.02、SDM 容差、固定索引规则均不变。
# v2 修正 solver 描述为实际使用值（v1 误写 1e-9/600s；实际全部 stage gap=1e-6）。
FROZEN = {
    'tau_Q': 0.02,                      # 平均 Q⁰ 损失容忍值（预注册）
    'stage4_tiebreak': 'min sum(idx(e)*T_e), idx=字典序( facility_id, community_id, care_type )秩',
    'stage4_sdm_tol': 1e-6,             # Σe_j 容差（SDM 容差 5e-7）
    'b_treatment': 'b:=0 诊断口径（T⁰ 非正式保障解）；保障不可行证书由 Lemma1 单独报告',
    'sdm_definition': '0.5*Σ_j |N_j/ΣT − D_j/D|，社区聚合（与遗留 metrics_from_T 一致）',
    'solver': 'PuLP 3.3.2 + HiGHS threads=1, mip_rel_gap=1e-6; '
              'Stage1–3 timeLimit=1800s, Stage4 timeLimit=1500s(MemoryError 时降 900s 重试一次); '
              'Stage4 含有效上界割；audit 记录 HiGHS 原生 model_status/objective/bound/gap',
    'network': 'amap v3/distance (travel_edges_osm.csv, ok=100%)，与遗留正式 run 同源',
    'revision_note': 'v3 2026-09-28: Stage4 时限 1800(v1)→3600s(v2: 13.9GB 内存耗尽 MemoryError)→'
                     '1500s+有效上界割(v3)；割=Σidx·T≤Stage3 可行解索引和（不改最优集，仅强剪枝）；'
                     '选择规则（四阶段词典序/τ_Q/容差/索引）不变',
    'stage4_time_limit_s': 1500,
    'stage4_memory_retry_s': 900,
    'stage4_fallback': 'FEASIBLE_TIMEOUT 且无整数 incumbent 时，T⁰ 回退 Stage3 最优解'
                       '（满足全部更高优先级词典序约束，SDM=SDM*）；audit 记录 t0_source',
}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def build_keys(P):
    """z=0 的 χ 可行边（C0>0）。"""
    keys = []
    for (a, j) in P.d:
        if P.d[(a, j)] > P.tau:
            continue
        if not P.hard_chi(a, j, 'NH')[0] and not P.hard_chi(a, j, 'BK')[0] \
                and not P.hard_chi(a, j, 'WELLNESS')[0]:
            continue
        for k in P.care_types:
            if P.L.get((j, k), 0) <= 0 or P.C0.get((a, k), 0) <= 0:
                continue
            if P.hard_chi(a, j, k)[0]:
                keys.append((a, j, k))
    return sorted(keys)


def native_info(prob):
    """提取 HiGHS 原生状态（Policy15 §10 要求记录 best bound/gap/status）。"""
    try:
        h = prob.solverModel
        info = h.getInfo()
        out = {'model_status': str(h.getModelStatus())}
        for k_src, k_dst in [('objective_function_value', 'objective'),
                             ('mip_dual_bound', 'bound'), ('mip_gap', 'gap')]:
            try:
                v = getattr(info, k_src)
                out[k_dst] = float(v) if v is not None and abs(v) < 1e30 else None
            except Exception:
                out[k_dst] = None
        return out
    except Exception as e:
        return {'error': repr(e)}


def solve_stage(name, sense, obj, cons, time_limit=1800, gap=1e-6):
    prob = pulp.LpProblem(f'P15G1_{name}', sense)
    for c in cons:
        prob += c
    prob += obj
    prob.solve(pulp.HiGHS(msg=0, timeLimit=time_limit, gapRel=gap, threads=1))
    st = {'Optimal': 'OPTIMAL', 'Not Solved': 'FEASIBLE_TIMEOUT',
          'Infeasible': 'PROVEN_INFEASIBLE', 'Unbounded': 'UNKNOWN'}.get(
        pulp.LpStatus[prob.status], 'UNKNOWN')
    ni = native_info(prob)
    if st == 'FEASIBLE_TIMEOUT':
        print(f'  [WARN] {name} timeout; 事后断言检验 SDM/ΣT/avgQ⁰ 必须通过')
    return st, ni, prob


def run_set(set_name, fname, P_full, meta_base):
    dem = pd.read_csv(DATA_P15 / fname, dtype={'community_id': str})
    L = {(r.community_id, K_MAP[r.care_type]): int(r.L) for r in dem.itertuples()}
    b = {(r.community_id, K_MAP[r.care_type]): int(r.guarantee_b) for r in dem.itertuples()}
    P = model_io.Params(**{**P_full.__dict__, 'L': L, 'b': b})
    audit = {'demand_set': set_name, 'demand_file': fname,
             'demand_sha256': sha256(DATA_P15 / fname), **meta_base}
    t00 = time.time()

    # ---------- Stage 0: 保障不可行证书（原 b，z=0） ----------
    z0 = {pid: 0 for pid in P.projects}
    y1 = {a: 1 for a in P.facilities}
    cert = {}
    for k in P.care_types:
        req = sum(P.b[(j, k)] for j in P.communities)
        if req <= 0:
            cert[k] = {'required': 0, 'note': '无保障需求，无需检验'}
            continue
        feas, mf, Sset = lemma1_maxflow(P, k, z0, y1)
        cert[k] = {'required': int(req), 'maxflow_z0': int(mf), 'feasible_z0': bool(feas),
                   'n_starved_side': int(len([j for j in Sset if P.b.get((j, k), 0) > 0])),
                   'verdict': 'FEASIBLE' if feas else 'PROVEN_INFEASIBLE_PHYSICAL'}
    audit['stage0_guarantee_certificate'] = cert

    # ---------- 边集合与静态系数 ----------
    keys = build_keys(P)
    idx = {e: i for i, e in enumerate(keys)}
    Q0 = {e: P.Q0(*e) for e in keys}
    D = sum(P.L.values())
    Dj = {j: sum(P.L[(j, k)] for k in P.care_types) for j in P.communities}
    audit['edges'] = {'n_chi_edges': len(keys), 'D_grand': int(D),
                      'C0_grand': int(sum(P.C0.values()))}

    # ---------- Stage 1: max ΣT (b:=0) ----------
    T = {e: pulp.LpVariable(f'T_{i}', lowBound=0, cat='Integer') for i, e in enumerate(keys)}
    by_ak, by_jk = {}, {}
    for e in keys:
        by_ak.setdefault((e[0], e[2]), []).append(e)
        by_jk.setdefault((e[1], e[2]), []).append(e)
    cons = []
    for a in P.facilities:
        for k in P.care_types:
            cap = P.C0.get((a, k), 0)
            if cap > 0 and (a, k) in by_ak:
                cons.append(pulp.lpSum(T[e] for e in by_ak[(a, k)]) <= cap)
    for (j, k), es in by_jk.items():
        cons.append(pulp.lpSum(T[e] for e in es) <= P.L[(j, k)])
    tot = pulp.lpSum(T.values())
    t1 = time.time()
    st1, ni1, _ = solve_stage('s1_coverage', pulp.LpMaximize, tot, cons)
    v0 = int(round(sum(T[e].value() for e in keys)))
    audit['stage1'] = {'status': st1, 'native': ni1, 'v0': v0,
                       'time_s': round(time.time() - t1, 1)}
    print(f'  [{set_name}] Stage1 {st1} v0={v0} ({audit["stage1"]["time_s"]}s)')
    assert st1 == 'OPTIMAL', 'Stage1 未证最优，中止（不得用可行解冒充 T⁰）'
    con_v0 = tot == v0

    # ---------- Stage 2: max ΣQ0·T s.t. ΣT=v0 ----------
    t2 = time.time()
    st2, ni2, _ = solve_stage('s2_maxq', pulp.LpMaximize,
                              pulp.lpSum(Q0[e] * T[e] for e in keys),
                              cons + [con_v0])
    qsum = float(sum(Q0[e] * T[e].value() for e in keys))
    qbar_star = qsum / v0
    audit['stage2'] = {'status': st2, 'native': ni2, 'Qsum_star': qsum,
                       'Qbar_star': qbar_star, 'time_s': round(time.time() - t2, 1)}
    print(f'  [{set_name}] Stage2 {st2} Q̄*={qbar_star:.6f} ({audit["stage2"]["time_s"]}s)')
    assert st2 == 'OPTIMAL'
    con_q = pulp.lpSum(Q0[e] * T[e] for e in keys) >= (1 - FROZEN['tau_Q']) * qsum - 1e-9

    # ---------- Stage 3: min SDM ----------
    ej = {j: pulp.LpVariable(f'e_{j}', lowBound=0) for j in P.communities}
    cons3 = list(cons) + [con_v0, con_q]
    for j in P.communities:
        Nj = pulp.lpSum(T[e] for e in by_jk.get((j, 'NH'), [])
                        + by_jk.get((j, 'BK'), []) + by_jk.get((j, 'WELLNESS'), []))
        dev = Nj / v0 - Dj[j] / D
        cons3 += [ej[j] >= dev, ej[j] >= -dev]
    t3 = time.time()
    st3, ni3, _ = solve_stage('s3_sdm', pulp.LpMinimize, pulp.lpSum(ej.values()), cons3)
    sum_e = float(sum(ej[j].value() for j in P.communities))
    sdm_star = 0.5 * sum_e
    audit['stage3'] = {'status': st3, 'native': ni3, 'SDM_star': sdm_star,
                       'avg_Q0_at_stage3': float(sum(Q0[e] * T[e].value() for e in keys)) / v0,
                       'time_s': round(time.time() - t3, 1)}
    print(f'  [{set_name}] Stage3 {st3} SDM*={sdm_star:.6f} ({audit["stage3"]["time_s"]}s)')
    assert st3 == 'OPTIMAL', 'Stage3 未证最优，中止（词典序规则要求 min-SDM 证优）'

    # Stage3 解留档：Stage4 无整数 incumbent 时的诚实回退源（FROZEN['stage4_fallback']）
    T0_s3 = {e: int(round(T[e].value())) for e in keys}
    assert sum(T0_s3.values()) == v0, 'Stage3 解 ΣT≠v0，模型缺陷'

    # ---------- Stage 4: 固定边索引破同解 ----------
    # 必须继承 Stage3 全部约束（含 ej≥±dev），再加 Σe_j 上界——否则 SDM 约束为空
    # 有效上界割：Stage3 解对 Stage4 可行，其索引和必 ≥ Stage4 最优（强剪枝不改最优集）
    s3_idxsum = float(sum(idx[e] * T[e].value() for e in keys))
    cons4 = list(cons3) + [pulp.lpSum(ej.values()) <= sum_e + FROZEN['stage4_sdm_tol'],
                           pulp.lpSum(idx[e] * T[e] for e in keys) <= s3_idxsum + 1e-6]
    t4 = time.time()
    mem_retry = False
    try:
        st4, ni4, _ = solve_stage('s4_tiebreak', pulp.LpMinimize,
                                  pulp.lpSum(idx[e] * T[e] for e in keys), cons4,
                                  time_limit=FROZEN['stage4_time_limit_s'])
    except MemoryError:
        mem_retry = True
        print(f'  [WARN] Stage4 MemoryError → 降时限 {FROZEN["stage4_memory_retry_s"]}s 重试一次')
        st4, ni4, _ = solve_stage('s4_tiebreak', pulp.LpMinimize,
                                  pulp.lpSum(idx[e] * T[e] for e in keys), cons4,
                                  time_limit=FROZEN['stage4_memory_retry_s'])
    audit['stage4'] = {'status': st4, 'native': ni4, 'rule': FROZEN['stage4_tiebreak'],
                       'time_s': round(time.time() - t4, 1),
                       'upper_bound_cut_s3_idxsum': s3_idxsum,
                       'memory_retry_900s': mem_retry}
    # 读取 Stage4 解向量：无整数 incumbent 时 PuLP 可能返回 None/无效值
    try:
        T0_s4 = {e: int(round(T[e].value())) for e in keys}
        has_incumbent = (sum(T0_s4.values()) == v0)
    except (TypeError, ValueError):
        T0_s4, has_incumbent = None, False

    if st4 == 'OPTIMAL' and has_incumbent:
        T0 = T0_s4
        audit['stage4']['t0_source'] = 'stage4_optimal'
    elif st4 == 'FEASIBLE_TIMEOUT' and has_incumbent:
        T0 = T0_s4
        audit['stage4']['t0_source'] = 'stage4_incumbent'
        audit['stage4']['note'] = ('破同解目标未证优（time limit，有可行 incumbent）；'
                                   'T⁰ 满足 Stage1–3 全部词典序约束，仅"固定索引最小"性质未认证')
        print(f'  [{set_name}] Stage4 {st4} — 接受可行解（事后校验强制）')
    elif st4 == 'FEASIBLE_TIMEOUT':
        # 无整数 incumbent（解向量无效）→ 诚实回退 Stage3 最优解（预注册规则）
        T0 = dict(T0_s3)
        audit['stage4']['t0_source'] = 'stage3_fallback_no_incumbent'
        audit['stage4']['note'] = ('Stage4 超时且无整数可行 incumbent；T⁰ 取 Stage3 最优解'
                                   '（满足全部更高优先级词典序约束，SDM=SDM*），'
                                   '"固定索引最小"性质未认证——确定性由求解器版本+输入唯一性保证')
        print(f'  [{set_name}] Stage4 无 incumbent → 回退 Stage3 解')
    else:
        raise RuntimeError(f'Stage4 {st4}: Stage3 解对 Stage4 恒可行，此状态说明模型缺陷')
    print(f'  [{set_name}] Stage4 {st4} ({audit["stage4"]["time_s"]}s), '
          f"t0_source={audit['stage4']['t0_source']}")

    # ---------- 事后校验（三断言，任一失败即中止） ----------
    N_chk = sum(T0.values())
    Nj_chk = {j: sum(T0.get(e, 0) for e in (by_jk.get((j, 'NH'), [])
              + by_jk.get((j, 'BK'), []) + by_jk.get((j, 'WELLNESS'), [])))
              for j in P.communities}
    sdm_chk = 0.5 * sum(abs(Nj_chk[j] / N_chk - Dj[j] / D) for j in P.communities)
    q_chk = sum(Q0[e] * T0[e] for e in keys) / N_chk
    checks = {
        'sumT_equals_v0': N_chk == v0,
        'avgQ0_ge_(1-tauQ)Qbar*': q_chk >= (1 - FROZEN['tau_Q']) * qbar_star - 1e-9,
        'SDM_le_SDM_star_plus_tol': sdm_chk <= sdm_star + 0.5 * FROZEN['stage4_sdm_tol'] + 1e-9,
    }
    audit['post_checks'] = {'values': {'sumT': N_chk, 'SDM': sdm_chk, 'avg_Q0': q_chk},
                            'checks': checks}
    assert all(checks.values()), f'Stage4 事后校验失败: {checks}'
    print(f'  [{set_name}] 事后校验通过: SDM={sdm_chk:.6f} (SDM*={sdm_star:.6f})')

    # ---------- 指标 / 残余 / 财政（命题1 + 口径A年化） ----------
    served_jk = {}
    for j in P.communities:
        for k in P.care_types:
            if P.L.get((j, k), 0) > 0:
                served_jk[(j, k)] = sum(T0.get((a, j, k), 0) for a in P.facilities)
    N = sum(served_jk.values())
    Nj = {j: sum(served_jk.get((j, k), 0) for k in P.care_types) for j in P.communities}
    sdm = 0.5 * sum(abs(Nj[j] / N - Dj[j] / D) for j in P.communities)
    avg_q = float(sum(Q0[e] * T0[e] for e in keys)) / N
    y = {a: int(any(T0.get((a, j, k), 0) > 0 for j in P.communities for k in P.care_types))
         for a in P.facilities}
    Psi_monthly, S_det = psi(P, T0, z0, y)          # K(z)=0，月度最低补贴 Ψ
    Psi_annual = 12.0 * Psi_monthly
    # 搁浅容量
    unused = {}
    for a in P.facilities:
        for k in P.care_types:
            u = P.C0.get((a, k), 0) - sum(T0.get((a, j, k), 0) for j in P.communities)
            if u > 0:
                has_edge = any(P.hard_chi(a, j, k)[0] and P.d.get((a, j), 999) <= P.tau
                               and P.L.get((j, k), 0) > 0 for j in P.communities)
                unused.setdefault(a, {'total': 0, 'has_chi_edge': has_edge})
                unused[a]['total'] += u

    audit.update({
        'baseline_origin': 'reconstructed_under_current_contract',
        'result': {'v0': N, 'coverage': N / D, 'SDM': sdm, 'avg_Q0': avg_q,
                   'Qbar_star': qbar_star, 'Q_loss_vs_star': 1 - avg_q / qbar_star,
                   'n_facilities_active': int(sum(y.values())),
                   'stranded_capacity': int(sum(P.C0.values())) - N,
                   'n_facilities_stranded': len(unused),
                   'Psi_monthly': Psi_monthly, 'Psi_annual_accountingA': Psi_annual,
                   'subsidy_annual': Psi_annual, 'buildK': 0.0,
                   'spend_annual_accountingA': Psi_annual,
                   'fiscal_note': '口径A：K(z)=0 + 12×ΣS；S 按命题1对 T⁰ 事后最小化；'
                                  'T⁰ 为诊断口径（b:=0），非满足正式保障的政策解'},
        'stranded_top': dict(sorted(
            ((a, v) for a, v in unused.items()), key=lambda kv: -kv[1]['total'])[:15]),
    })

    # ---------- 文件输出 ----------
    rows = [{'facility_id': a, 'community_id': j,
             'care_type_neutral': LEGACY2NEU[k], 'care_type_legacy': k, 'beds': t}
            for (a, j, k), t in T0.items() if t > 0]
    tdf = pd.DataFrame(rows).sort_values(['facility_id', 'community_id', 'care_type_legacy'])
    tdf.to_csv(OUT / f'baseline_T0_{set_name}.csv', index=False, encoding='utf-8-sig')
    tdf.to_parquet(OUT / f'baseline_T0_{set_name}.parquet', index=False)

    dist = {r.community_id: r.district_name for r in
            pd.ExcelFile(ROOT / 'data' / 'raw' / 'eldercare_inputs.xlsx')
            .parse('communities', dtype={'community_id': str}).itertuples()}
    res = pd.DataFrame([{'community_id': j, 'district_name': dist.get(j, ''),
                         'care_type_neutral': LEGACY2NEU[k], 'care_type_legacy': k,
                         'L': P.L[(j, k)], 'served': served_jk.get((j, k), 0),
                         'R0': P.L[(j, k)] - served_jk.get((j, k), 0)}
                        for (j, k) in served_jk])
    with pd.ExcelWriter(OUT / f'residual_R0_{set_name}.xlsx', engine='openpyxl') as w:
        res.to_excel(w, sheet_name='residual_by_jk', index=False)
        agg = (res.groupby(['district_name', 'care_type_neutral'], as_index=False)
               .agg(L=('L', 'sum'), served=('served', 'sum'), R0=('R0', 'sum')))
        agg.to_excel(w, sheet_name='by_district_type', index=False)
        summ = pd.DataFrame([
            {'metric': 'D_grand', 'value': D}, {'metric': 'v0_served', 'value': N},
            {'metric': 'coverage', 'value': N / D}, {'metric': 'SDM', 'value': sdm},
            {'metric': 'R0_total', 'value': int(res.R0.sum())},
            {'metric': 'Psi_annual_accountingA', 'value': Psi_annual},
            {'metric': 'avg_Q0', 'value': avg_q},
            {'metric': 'stranded_capacity', 'value': int(sum(P.C0.values())) - N}])
        summ.to_excel(w, sheet_name='summary', index=False)

    audit['residual'] = {'R0_total': int(res.R0.sum()),
                         'n_jk_with_deficit': int((res.R0 > 0).sum()),
                         'per_type': {LEGACY2NEU[k]: {
                             'L': int(res[res.care_type_legacy == k].L.sum()),
                             'served': int(res[res.care_type_legacy == k].served.sum()),
                             'R0': int(res[res.care_type_legacy == k].R0.sum())}
                             for k in ('NH', 'BK', 'WELLNESS')},
                         'by_district': {d: {'R0': int(g.R0.sum()), 'L': int(g.L.sum())}
                                         for d, g in res.groupby('district_name')}}
    audit['elapsed_s'] = round(time.time() - t00, 1)
    (OUT / f'baseline_audit_{set_name}.json').write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return audit


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--only', choices=['upround', 'total_preserving'], default=None,
                    help='只跑指定需求集（其余集合读取盘上已有 audit 参与对照）')
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    print('=== Policy15 G1: 存量基准 T⁰/R⁰（两套需求） ===')
    P_full, coords, fcoords, districts, meta = load_liuzhou(use_osm=True)
    print(f"  network={meta['net']}, edges={meta['n_edges_loaded']}, "
          f"input sha={meta['sha256_inputs'][:12]}...")
    cfg_path = OUT / 'config_frozen.json'
    cfg_path.write_text(json.dumps(
        {**FROZEN, 'inherited_CONFIG': CONFIG, 'network_meta': meta},
        ensure_ascii=False, indent=2, default=str), encoding='utf-8')

    meta_base = {
        'config_frozen': FROZEN,
        'config_sha256': sha256(cfg_path),
        'input_workbook_sha256': meta['sha256_inputs'],
        'network': {'source': 'amap v3/distance 2026-09-26 (CSV 名为历史遗留)',
                    'sha256': sha256(ROOT / 'data' / 'raw' / 'travel_edges_osm.csv')},
        'solver': FROZEN['solver'],
        'run_at': pd.Timestamp.now().isoformat(),
    }
    sets = SETS if args.only is None else {args.only: SETS[args.only]}
    for set_name, fname in sets.items():
        print(f'--- 需求集: {set_name} ---')
        run_set(set_name, fname, P_full, meta_base)

    # 对照表从盘上读取（支持 --only 分次运行）
    cmpj = {}
    for s in SETS:
        f = OUT / f'baseline_audit_{s}.json'
        if not f.exists():
            continue
        a = json.loads(f.read_text(encoding='utf-8'))
        r = a['result']
        cmpj[s] = {'v0': r['v0'], 'coverage': round(r['coverage'], 6),
                   'SDM': round(r['SDM'], 6), 'R0_total': a['residual']['R0_total'],
                   'Qbar_star': r['Qbar_star'], 'avg_Q0': r['avg_Q0'],
                   'Psi_annual': r['Psi_annual_accountingA'],
                   'stranded': r['stranded_capacity'],
                   'stage4_status': a['stage4']['status'],
                   'guarantee': a['stage0_guarantee_certificate'].get('NH', {})}
    (OUT / 'P15_G1_comparison.json').write_text(json.dumps(
        {'note': '两套需求在共同候选宇宙下的比较在 G2/G5-F 展开；此处先报告各自 T⁰/R⁰',
         'sets': cmpj}, ensure_ascii=False, indent=2), encoding='utf-8')
    print('=== G1 完成 ->', OUT)


if __name__ == '__main__':
    main()
