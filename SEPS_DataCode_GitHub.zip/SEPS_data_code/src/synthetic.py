# -*- coding: utf-8 -*-
"""E3/E4 合成实例生成器。

按 V2§5.3 规格，四档规模：
  - 小规模真值:  5 社区 × 10 机构 × 3 床型, 项目 ≤ 5, 枚举+MILP 双验
  - 中规模:     20 × 100 × 3, 项目 ≤ 10
  - 大规模:     50 × 300 / 100 × 600

合成逻辑：随机生成二部图 + Q⁰矩阵 + 距离矩阵 + 容量/需求 + 候选项目。
所有参数可种子化，确保可复现。

用法： python synthetic.py [--n_j 5 --n_a 10 --seed 0]
输出： data/synthetic/inst_*.json
"""
import argparse
import json
import math
import random
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / 'data' / 'synthetic'
OUT_DIR.mkdir(parents=True, exist_ok=True)


def _make_bipartite(n_j, n_a, edge_p, seed):
    """生成二部图：每个社区-机构对以 edge_p 概率连通（χ=1）。"""
    rng = random.Random(seed)
    edges = {}   # (a,j) -> True/False (chi)
    for j in range(n_j):
        for a in range(n_a):
            edges[(a, j)] = rng.random() < edge_p
    return edges


def _make_Q0(n_j, n_a, edges, seed):
    """对 χ=1 边生成 Q⁰ ∈ [0.2, 0.9]，χ=0 边 Q⁰=0。"""
    rng = random.Random(seed)
    Q0 = {}
    for (a, j), chi in edges.items():
        Q0[(a, j)] = round(rng.uniform(0.2, 0.9), 4) if chi else 0.0
    return Q0


def _make_dists(n_j, n_a, edge_p, tau, seed):
    """对 85% 的 (a,j) 对生成 d ∈ [5, τ-5]，其余 ∈ [τ+5, 60]。
    不再单独设 chi——禁边完全由 Params.hard_chi 决定 (d≤τ AND H≥h_min AND p≤p_cap AND afford≤θ)。"""
    rng = random.Random(seed)
    d = {}
    for j in range(n_j):
        for a in range(n_a):
            if rng.random() < edge_p:
                d[(a, j)] = round(rng.uniform(5, max(5, tau - 5)), 2)
            else:
                d[(a, j)] = round(rng.uniform(tau + 5, 60), 2)
    return d


def _make_demand(n_j, rate=0.05, n65_range=(800, 3000)):
    """需求上界 L 和保障 b。"""
    rng = random.Random(0)
    n65 = [rng.randint(*n65_range) for _ in range(n_j)]
    L = {}
    b = {}
    for j in range(n_j):
        n = n65[j]
        for k, sk in [('basic', 0.50), ('care', 0.30), ('wellness', 0.20)]:
            L[(j, k)] = math.ceil(rate * n * sk)
            b[(j, k)] = math.ceil(0.35 * L[(j, k)]) if k == 'basic' else 0
    return n65, L, b


def _make_capacity(n_a, L_total, overbuild=1.1):
    """各机构容量 C0，总量 ≈ L_total × overbuild。"""
    rng = random.Random(1)
    target = int(L_total * overbuild)
    cap = {a: {} for a in range(n_a)}
    assigned = 0
    for a in range(n_a):
        total = max(5, int(rng.uniform(target * 0.8 / n_a, target * 1.2 / n_a)))
        cap[a]['basic'] = int(round(total * 0.60))
        cap[a]['care'] = int(round(total * 0.30))
        cap[a]['wellness'] = total - cap[a]['basic'] - cap[a]['care']
        assigned += total
    # scale to match target
    scale = target / assigned
    for a in range(n_a):
        for k in ['basic', 'care', 'wellness']:
            cap[a][k] = max(1, int(round(cap[a][k] * scale)))
    return cap


def generate_instance(n_j, n_a, n_k=3, seed=0, edge_p=0.85, tau=30):
    """生成一个完整合成实例。禁边完全由 Params.hard_chi 统一决定：
       chi=1 iff d≤τ AND H≥h_min AND p≤p_cap AND p/I≤θ。"""
    assert n_k == 3, 'only 3 care types: basic/care/wellness'
    rng = random.Random(seed)
    np.random.seed(seed)

    d = _make_dists(n_j, n_a, edge_p, tau, seed)
    n65, L, b = _make_demand(n_j)
    L_total = sum(L.values())
    cap = _make_capacity(n_a, L_total)

    # 候选项目: 每家机构 1 个扩建 (basic +3) + 1 个改造 (care→basic +2/-2)
    projects = []
    pid = 0
    for a in range(n_a):
        projects.append({
            'id': f'p{pid}', 'facility': a, 'type': 'expansion',
            'target': 'basic', 'delta': 3, 'K': 45000, 'private': 0,
        })
        pid += 1
        projects.append({
            'id': f'p{pid}', 'facility': a, 'type': 'renovation',
            'from': 'care', 'to': 'basic', 'delta_from': -2, 'delta_to': 2,
            'K': 6000, 'private': 0,
        })
        pid += 1

    # 统计: Params.hard_chi 会用 H=0.60/0.70/0.80, p_cap=4000, afford=1.0, tau=30
    edges_allowed = sum(1 for v in d.values() if v <= tau)

    inst = {
        'meta': {
            'n_j': n_j, 'n_a': n_a, 'n_k': n_k,
            'seed': seed, 'edge_p': edge_p, 'tau': tau,
            'total_demand': L_total, 'total_capacity': sum(sum(c.values()) for c in cap.values()),
            'overbuild': round(sum(sum(c.values()) for c in cap.values()) / L_total, 3),
            'n_d_allowed_by_tau': edges_allowed,  # d≤τ 的 (a,j) 对数
        },
        'd': {f'{a},{j}': v for (a, j), v in d.items()},
        'n65': n65,
        'L': {f'{j},{k}': v for (j, k), v in L.items()},
        'b': {f'{j},{k}': v for (j, k), v in b.items()},
        'C0': {str(a): c for a, c in cap.items()},
        'price': {'basic': 2500, 'care': 3000, 'wellness': 3500},
        'cost_c': {'basic': 2000, 'care': 2400, 'wellness': 2800},
        'quality_H': {'basic': 0.60, 'care': 0.70, 'wellness': 0.80},  # ≥ h_min=0.55
        'projects': projects,
        'provenance': 'synthetic (random seed); H≥h_min=0.55; chi=Params.hard_chi 统一计算',
    }
    return inst


def write_instance(inst, out_dir=OUT_DIR):
    sid = f"J{inst['meta']['n_j']}_A{inst['meta']['n_a']}_s{inst['meta']['seed']}"
    path = Path(out_dir) / f"inst_{sid}.json"
    path.write_text(json.dumps(inst, indent=2), encoding='utf-8')
    print(f'  inst -> {path.name}: {inst["meta"]}')
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--n_j', type=int, default=5)
    parser.add_argument('--n_a', type=int, default=10)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--count', type=int, default=5)
    args = parser.parse_args()

    print(f'=== 生成 {args.count} 个 {args.n_j}×{args.n_a} 合成实例 ===')
    for s in range(args.seed, args.seed + args.count):
        inst = generate_instance(args.n_j, args.n_a, seed=s)
        write_instance(inst)


if __name__ == '__main__':
    main()
