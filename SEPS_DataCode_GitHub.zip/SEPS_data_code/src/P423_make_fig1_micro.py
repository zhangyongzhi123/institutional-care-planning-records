# -*- coding: utf-8 -*-
"""Main-text Fig. 1（原 Supplementary Fig. S3）：micro-instance verification.

(a) 子集瓶颈网络与最小割（PNG）: nodes, capacities, forbidden link, min-cut.
(b) 最小月度补贴 Ψ 随服务水平 v 的变化 + B_crit 门槛（EMF）.

清理：不再绘制求解器状态标签（PROVEN_INFEASIBLE / OPTIMAL）、seed/time-limit
配置框与长段审计注释；数字均来自 runs/P0b_E0_20260924。

单栏宽度 2.74 in；图内文字 8 pt。运行： python P423_make_fig1_micro.py
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import yaml
from matplotlib.patches import Ellipse, FancyArrowPatch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from model_io import load_params  # noqa: E402
from solvers import enumerate_all  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs" / "P0b_E0_20260924"
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 8,
    "axes.labelsize": 8,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "axes.linewidth": 0.6,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "svg.fonttype": "path",
})

E0A = json.loads((RUN / "E0A_feasibility.json").read_text(encoding="utf-8"))
E0B = json.loads((RUN / "E0B_subsidy.json").read_text(encoding="utf-8"))

CE = [r for r in E0A["rows"]
      if r["instance_id"] == "COUNTEREXAMPLE_subset_bottleneck"][0]
assert CE["total_b"] == 4 and CE["total_cap"] == 4
assert CE["m3_maxflow_value"] == 3 and CE["m3_required"] == 4
assert CE["starved_communities"] == ["j1"]

# ---------------------------------------------------------------- panel (a)
POS = {"s": (0.075, 0.535), "j1": (0.345, 0.800), "j2": (0.345, 0.270),
       "a2": (0.670, 0.800), "a1": (0.670, 0.270), "t": (0.935, 0.535)}
NODE_W, NODE_H = 0.086, 0.112          # ellipse width/height in axes coords
NODE_FILL = {"s": "#EAF0F8", "t": "#EAF0F8", "j1": "#FDF3E3",
             "j2": "#FDF3E3", "a1": "#EAF6EC", "a2": "#EAF6EC"}
BLUE, RED, DARK = "#1F3B73", "#C0392B", "#333333"


def panel_a(path_png):
    fig = plt.figure(figsize=(2.60, 1.88))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

    def edge(n1, n2, ls="-", color=BLUE, lw=1.0, arrow=True):
        (x1, y1), (x2, y2) = POS[n1], POS[n2]
        ax.add_patch(FancyArrowPatch(
            (x1, y1), (x2, y2),
            arrowstyle="-|>" if arrow else "-",
            mutation_scale=8, lw=lw, color=color, ls=ls,
            shrinkA=8.5, shrinkB=8.5, zorder=2))

    def lbl(x, y, s, color=DARK, fs=8, ha="center"):
        ax.text(x, y, s, fontsize=fs, ha=ha, va="center", color=color,
                zorder=5, bbox=dict(fc="white", ec="none", pad=0.10))

    edge("s", "j1"); edge("s", "j2")
    edge("j1", "a1"); edge("j2", "a1"); edge("j2", "a2")
    edge("a1", "t"); edge("a2", "t")
    edge("j1", "a2", ls=(0, (1, 1.7)), color="#555555", lw=0.9, arrow=False)

    # min-cut boundary: 只穿过三条割边 (s-j2, j1-a1, j1-a2[χ=0])
    cut = [(0.000, 0.300), (0.252, 0.361), (0.340, 0.520),
           (0.4165, 0.6834), (0.575, 0.800), (0.610, 0.890),
           (0.610, 1.000)]
    ax.plot([p[0] for p in cut], [p[1] for p in cut], ls=(0, (4, 2.5)),
            color=RED, lw=1.1, zorder=1)

    # forbidden-link marker
    ax.plot([0.488, 0.512], [0.783, 0.817], color=RED, lw=1.2, zorder=4)
    ax.plot([0.488, 0.512], [0.817, 0.783], color=RED, lw=1.2, zorder=4)

    for n, (x, y) in POS.items():
        ax.add_patch(Ellipse((x, y), NODE_W, NODE_H, fc=NODE_FILL[n],
                             ec=DARK, lw=0.6, zorder=3))
        sym = {"s": "$s$", "t": "$t$", "j1": "$j_1$", "j2": "$j_2$",
               "a1": "$a_1$", "a2": "$a_2$"}[n]
        ax.text(x, y, sym, fontsize=8, ha="center", va="center", zorder=4)

    # capacities / demands (on the corresponding links)
    lbl(0.1695, 0.6278, "$b$=2")
    lbl(0.1695, 0.4423, "$b$=2")
    lbl(0.4588, 0.6145, "$u$=1")
    lbl(0.4588, 0.4555, "$u$=2")
    lbl(0.5075, 0.2700, "$u$=1")
    lbl(0.8158, 0.4158, "$\\widehat{C}$=1")
    lbl(0.8158, 0.6542, "$\\widehat{C}$=3")

    lbl(0.500, 0.140, "min-cut = 3 < $\\Sigma b$ = 4", color=RED, fs=8.5)
    lbl(0.500, 0.062, "barred $a_2j_1$: $\\chi$=0 ($d$=45$>$30 min)",
        color=RED, fs=8)

    fig.savefig(path_png, dpi=300)
    plt.close(fig)


# ---------------------------------------------------------------- panel (b)
def min_psi_by_v():
    cfg = yaml.safe_load((ROOT / "config" / "exampleA.yaml").read_text(encoding="utf-8"))
    P, _T0 = load_params(ROOT / "data" / "raw" / "eldercare_inputs_A.xlsx", cfg)
    by_v = {}
    for T, pv in enumerate_all(P, {}, {"a1": 1, "a2": 1}):
        v = sum(T.values())
        by_v[v] = min(by_v.get(v, float("inf")), pv)
    return dict(sorted(by_v.items())), P


def panel_b(path_svg, path_png):
    by_v, P = min_psi_by_v()
    assert by_v == {5: 150.0, 6: 150.0, 7: 150.0}, by_v
    assert P.K_z({}) == 0.0, P.K_z({})   # z=0 无资本 → Ψ = 12·Σ[Δ]
    zy = [r for r in E0B["exampleA_by_zy"] if r["combo"] == "z=0,y=11"][0]
    Bc_m, eps_m = zy["B_crit_enum"], zy["threshold_tests_eps"]
    assert Bc_m == 150.0 and eps_m == 0.01
    # 归档为单期值；K=0 时首年 Ψ = 12×单期值（精确换算，非重跑）
    Bc, eps = 12.0 * Bc_m, 12.0 * eps_m

    fig = plt.figure(figsize=(2.60, 1.50))
    ax = fig.add_axes([0.255, 0.250, 0.720, 0.700])
    vs = list(by_v)
    ps = [12.0 * p for p in by_v.values()]
    # 门槛线只画在数据区间外侧，避免与蓝色 Ψ 线在同一 y 处叠压（EMF 导出会露出红边）
    for x0, x1 in [(4.55, 5.0), (7.0, 7.45)]:
        ax.plot([x0, x1], [Bc, Bc], color=RED, lw=0.9, ls=(0, (5, 2)), zorder=1)
    ax.plot(vs, ps, "-o", color=BLUE, lw=1.2, ms=4.0, zorder=3)
    ax.set_xlim(4.55, 7.45); ax.set_ylim(0, 2400)
    ax.set_xticks([5, 6, 7]); ax.set_yticks([0, 600, 1200, 1800, 2400])
    ax.set_xlabel("Served beds $v$ (guarantee-feasible)", fontsize=8, labelpad=2)
    ax.set_ylabel("Minimum first-year\nexpenditure\n$\\Psi$ (CNY)",
                  fontsize=8, labelpad=2)
    ax.text(7.40, 2120,
            f"$B_{{\\mathrm{{crit}}}}$ = {Bc:,.0f} $\\pm$ {eps:.2f}",
            fontsize=8, color=RED, ha="right", va="center")
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(axis="both", which="major", length=2.6, pad=2.0)

    fig.savefig(path_svg, format="svg")
    fig.savefig(path_png, dpi=300)
    plt.close(fig)


def svg_to_emf(svg, emf):
    """PowerPoint Shape.Export filter 5 = EMF (矢量)."""
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    app = win32com.client.Dispatch("PowerPoint.Application")
    app.Visible = True
    pres = app.Presentations.Add(WithWindow=False)
    try:
        slide = pres.Slides.Add(1, 12)  # ppLayoutBlank
        shp = slide.Shapes.AddPicture(str(svg), False, True, 0, 0, -1, -1)
        shp.Export(str(emf), 5)
    finally:
        pres.Close()
        app.Quit()
        pythoncom.CoUninitialize()


def main():
    out_a = FIG / "Fig1a_micro_network.png"
    svg_b = FIG / "Fig1b_micro_subsidy.svg"
    emf_b = FIG / "Fig1b_micro_subsidy.emf"
    png_b = FIG / "Fig1b_micro_subsidy.png"
    panel_a(out_a)
    panel_b(svg_b, png_b)
    svg_to_emf(svg_b, emf_b)
    print("[fig1] panel a ->", out_a)
    print("[fig1] panel b ->", emf_b, "(svg:", svg_b.name, "; png:", png_b.name, ")")


if __name__ == "__main__":
    main()
