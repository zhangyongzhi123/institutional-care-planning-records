# -*- coding: utf-8 -*-
"""E0-B：最低补贴与财政门槛（Proposition 1 + Theorem 1）。

对每个固定 (z,y)：枚举全部保障可行 T → Ψ 分布 → B_crit = min Ψ；
与"显式 S_a 变量的整数模型"（bcrit MILP）对照；
用 B_crit−ε / B_crit / B_crit+ε 三点测试门槛（ε=货币离散精度0.01；零门槛不设负预算）。
反例：3床/保障1/净贡献4/固定成本10 → 服务1/2/3床补贴 6/2/0 → B_crit=0，
禁止用"某一个满足保障的随手解"报 6。

用法： python run_E0B.py [--out runs/P0b_E0_20260924]
输出： <out>/E0B_subsidy.json
"""
import argparse
import platform
import sys
import time
import tracemalloc
from pathlib import Path

import pulp
import yaml

from model_io import load_params
from run_E0A import micro_params
from run_exampleA import dump, legal_zy_combos
from solvers import enumerate_all, get_stats, psi, reset_stats, solve_milp

ROOT = Path(__file__).resolve().parents[1]
EPS = 0.01  # 货币离散精度（元）


def zy_key(P, z, y):
    zv = int(list(z.values())[0]) if z else 0
    yv = "".join(str(y.get(a, 0)) for a in P.facilities)
    return f"z={zv},y={yv}"


def bcrit_for_zy(P, z, y, tag):
    """一个 (z,y) 的：Ψ分布、枚举B_crit、MILP对照、±ε三点门槛。"""
    sols = enumerate_all(P, z, y)  # 已含 b≤ΣT≤L 保障下界
    if not sols:
        return {"combo": tag, "feasible": False, "B_crit": None,
                "note": "无保障可行T → B_crit=∞（门槛测试不适用）"}
    psis = sorted(pv for _T, pv in sols)
    B_crit = min(pv for _T, pv in sols)
    argmin = [{"T": {",".join(e): t for e, t in T.items()},
               "S": {a: round(max(0.0, psi(P, T, z, y)[1][a]), 6) for a in P.facilities}}
              for T, pv in sols if abs(pv - B_crit) < 1e-9]
    # MILP 对照：显式 S_a 变量整数模型（bcrit 模式 min K+ΣS）
    r = solve_milp(P, z, y, 1e9, "bcrit")
    milp_ok = r["status"] == "OPTIMAL" and abs(r["obj"] - B_crit) < 1e-6
    # 三点门槛测试（maxflow 模式在预算下判可行；B_crit=0 时不设负预算）
    tests = []
    for label, Bt in [("B_crit-eps", B_crit - EPS), ("B_crit", B_crit),
                      ("B_crit+eps", B_crit + EPS)]:
        if label == "B_crit-eps" and B_crit <= 0:
            tests.append({"test": label, "B": None,
                          "skipped": "零门槛不设负预算（红线）"})
            continue
        rr = solve_milp(P, z, y, Bt, "maxflow")
        expect = "PROVEN_INFEASIBLE" if label == "B_crit-eps" else "OPTIMAL"
        tests.append({"test": label, "B": round(Bt, 2), "status": rr["status"],
                      "expected": expect, "pass": rr["status"] == expect,
                      "v_at_B": int(rr["obj"]) if rr["obj"] is not None else None})
    return {
        "combo": tag, "feasible": True,
        "n_guarantee_feasible_T": len(sols),
        "psi_distribution_sorted_unique": sorted({round(pv, 6) for _T, pv in sols}),
        "B_crit_enum": B_crit,
        "B_crit_milp_bcrit": r["obj"], "milp_matches_enum": bool(milp_ok),
        "argmin_allocations": argmin,
        "threshold_tests_eps": EPS, "threshold_tests": tests,
        "all_threshold_tests_pass": all(t.get("pass", True) for t in tests),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    t0w = time.time()
    tracemalloc.start()
    reset_stats()
    cfg = yaml.safe_load((ROOT / "config" / "exampleA.yaml").read_text(encoding="utf-8"))
    P_A, _ = load_params(ROOT / "data" / "raw" / "eldercare_inputs_A.xlsx", cfg)
    out = Path(args.out) if args.out else ROOT / "runs" / f"P0b_E0_{time.strftime('%Y%m%d_%H%M%S')}"
    out.mkdir(parents=True, exist_ok=True)

    # ---- 示例A 全部合法 (z,y) ----
    combos = legal_zy_combos(P_A)
    by_zy = [bcrit_for_zy(P_A, z, y, zy_key(P_A, z, y)) for z, y in combos]

    # ---- 反例：3床/保障1/净贡献4/固定成本10（任务单§3） ----
    P_c = micro_params(
        communities=["j1"], facilities=["a1"], L={("j1", "NH"): 3},
        b={("j1", "NH"): 1}, I={"j1": 4000.0}, C0={("a1", "NH"): 3},
        p={("a1", "NH"): 10.0}, cst={("a1", "NH"): 6.0},
        H={("a1", "NH"): 1.0}, F0={"a1": 10.0}, Pi0={"a1": 0.0},
        d={("a1", "j1"): 0.0}, U0={"j1": -10.0}, alpha={"j1": 0.0},
        beta_h={"j1": 0.0}, afford_cap=10.0,
    )
    z, y = {}, {"a1": 1}
    ce = bcrit_for_zy(P_c, z, y, "COUNTEREXAMPLE_Bcrit0")
    # 反例语义补充：随手解陷阱演示——保障可行解 T=(1床) 的 Ψ=6，但联合最小 Ψ=0
    naive = [T for T, pv in enumerate_all(P_c, z, y) if sum(T.values()) == 1]
    ce["naive_solution_trap"] = {
        "note": ("取某个仅满足保障的最大流解（如 T={a1j1:1}，Ψ=6）来报告'最低补贴'，"
                 "正是正文 Section V-D 要打的错误；命题1要求与分配联合取最小。"),
        "example_T_serving_1": {",".join(e): t for e, t in naive[0].items()},
        "psi_of_that_T": psi(P_c, naive[0], z, y)[0],
        "joint_min_psi": ce["B_crit_enum"],
        "beds_1_2_3_psi": [6.0, 2.0, 0.0],
        "conclusion": "B_crit = 0（服务3床时无需补贴）；门槛测试 B=0 可行、B=−ε 不设负预算跳过",
    }

    n_bad = sum(1 for b in by_zy if not b.get("all_threshold_tests_pass", True))
    n_milp = sum(1 for b in by_zy if b["feasible"] and not b["milp_matches_enum"])
    report = {
        "purpose": "验证 B_crit 与分配联合取最小（Prop1/Theorem1），枚举=MILP=门槛测试",
        "eps": EPS,
        "exampleA_by_zy": by_zy,
        "counterexample": ce,
        "summary": {
            "n_zy": len(by_zy),
            "n_feasible_zy": sum(1 for b in by_zy if b["feasible"]),
            "n_milp_mismatch": n_milp,
            "n_threshold_test_fail": n_bad,
            "B_crit_z0_y11": next(b["B_crit_enum"] for b in by_zy if b["combo"] == "z=0,y=11"),
            "B_crit_z1_y11": next(b["B_crit_enum"] for b in by_zy if b["combo"] == "z=1,y=11"),
        },
        "run_stats": {
            "wall_time_s": round(time.time() - t0w, 3),
            "inner_calls": get_stats(),
            "peak_memory_mb": round(tracemalloc.get_traced_memory()[1] / 1e6, 2),
            "python": sys.version.split()[0], "platform": platform.platform(),
            "solver": f"PuLP {pulp.__version__} + HiGHS", "status": "OPTIMAL",
        },
    }
    assert n_bad == 0 and n_milp == 0, "E0-B 存在门槛测试失败或 MILP 不一致，先修复"
    assert ce["B_crit_enum"] == 0.0 and ce["naive_solution_trap"]["psi_of_that_T"] == 6.0
    dump(out, "E0B_subsidy", report)
    print(f"[run_E0B] by_zy={len(by_zy)} B_crit(z0,y11)={report['summary']['B_crit_z0_y11']} "
          f"B_crit(z1,y11)={report['summary']['B_crit_z1_y11']} "
          f"counterexample B_crit={ce['B_crit_enum']} ({time.time()-t0w:.1f}s)")


if __name__ == "__main__":
    main()
