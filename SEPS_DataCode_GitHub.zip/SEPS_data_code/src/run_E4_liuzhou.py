# -*- coding: utf-8 -*-
"""E4（柳州）：参数敏感性。

前置：E1 判定 B_crit=∞（物理瓶颈）。敏感性分两部分：

A. 主口径 τ 可行性门槛（快，最大流）：
   对 τ ∈ {20,25,30,35,40,45,60}，全项目激活 (z=1,y=1) 下 NH 最大流 vs Σb=5026，
   给出"恢复可行性所需的服务范围门槛 τ*"——这是物理瓶颈的政策含义核心。
   b 不调低、不调 τ 凑数：只扫描并如实报告门槛位置。

B. 诊断口径（b:=0，与 E1/E2 同口径）参数扰动：
   τ ∈ {25,45}（30 为基准）、需求率 r ∈ {0.03,0.08}（0.05 基准，L 与 Σb 同比例缩放）、
   成本比 c/p ∈ {0.70,0.90}（0.80 基准）。每情景解 stock(z≡0) 与 full(满预算)，
   报 v/coverage/SDM/spend。不预设任何方向，结果如实记录。

用法: python run_E4_liuzhou.py [--time-limit 180]
输出: runs/E4_liuzhou_<ts>/ e4_tau_feasibility.csv, e4_summary.csv,
      e4_sensitivity.json, e4_run_meta.json, figures/Fig10_*.png/pdf
"""
import argparse
import dataclasses
import json
import math
import time
from pathlib import Path

import pandas as pd
import pulp

ROOT = Path(__file__).resolve().parents[1]
import sys  # noqa: E402
sys.path.insert(0, str(ROOT / 'src'))

from run_E1_full import BIG_B, K_MAP, load_liuzhou, metrics_from_T, solve_joint  # noqa: E402
from solvers import lemma1_maxflow  # noqa: E402

TAUS_A = [20, 25, 30, 35, 40, 45, 60]
TAUS_B = [25, 45]
RATES = [0.03, 0.08]
CPS = [0.70, 0.90]
# V2 §1.9 预注册：可负担比上限 θ 敏感性 0.8/1.0/1.2（1.0 为基准；
# 实测高端价4800 > 全部区县收入max 4493 → θ=1.0 下康养全区不可负担，θ 扫描给出政策含义）
THETAS = [0.8, 1.2]
R0 = 0.05


def scale_L_b(P, rate):
    """需求率 r：L、b 同比例 ceil 缩放（基准 r0=0.05）。"""
    f = rate / R0
    L = {kk: int(math.ceil(v * f - 1e-9)) for kk, v in P.L.items()}
    b = {kk: int(math.ceil(v * f - 1e-9)) for kk, v in P.b.items()}
    return L, b


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--time-limit', type=int, default=180)
    ap.add_argument('--gap', type=float, default=0.01)
    args = ap.parse_args()
    t0 = time.time()

    P, coords, fcoords, districts, meta = load_liuzhou(True)
    Pd = dataclasses.replace(P, b={kk: 0 for kk in P.b})
    print(f"=== E4 柳州敏感性 ({meta['net']}) ===")
    out_dir = ROOT / 'runs' / f"E4_liuzhou_{time.strftime('%Y%m%d_%H%M%S')}"
    out_dir.mkdir(parents=True, exist_ok=True)

    # ---- A. τ 可行性门槛（主口径，NH 保障 b） ----
    z_all = {pid: 1 for pid in P.projects}
    y_all = {a: 1 for a in P.facilities}
    z0 = {pid: 0 for pid in P.projects}
    rows = []
    for tau in TAUS_A:
        Pt = dataclasses.replace(P, tau=float(tau))
        req = sum(Pt.b[(j, 'NH')] for j in Pt.communities)
        t1 = time.time()
        feas1, mf0, _ = lemma1_maxflow(Pt, 'NH', z0, y_all)
        feas2, mf1, _ = lemma1_maxflow(Pt, 'NH', z_all, y_all)
        rows.append({'tau_min': tau, 'required_b_NH': req,
                     'maxflow_z0': mf0, 'maxflow_z1_all': mf1,
                     'feasible_z0': bool(feas1), 'feasible_z1': bool(feas2),
                     'verdict': ('FEASIBLE' if feas2 else
                                 'INFEASIBLE_PHYSICAL_BOTTLENECK'),
                     'time_s': round(time.time() - t1, 2)})
        print(f"  τ={tau}min: maxflow(z1)={mf1} vs Σb={req} -> {rows[-1]['verdict']}")
    tau_df = pd.DataFrame(rows)
    tau_df.to_csv(out_dir / 'e4_tau_feasibility.csv', index=False,
                  encoding='utf-8-sig')
    feas_taus = [r['tau_min'] for r in rows if r['feasible_z1']]
    tau_star = min(feas_taus) if feas_taus else None
    print(f"  可行性门槛: τ* = {tau_star} (最小可行 τ 档位)" if tau_star
          else "  扫描范围内无可行 τ（≥60min 仍不可行）")

    # ---- B. 诊断口径参数扰动 ----
    v_base = spend_base = cov_base = None
    rows_b = []
    scen = [('baseline', Pd)]
    for tau in TAUS_B:
        scen.append((f'tau={tau}', dataclasses.replace(Pd, tau=float(tau))))
    for rate in RATES:
        L, _ = scale_L_b(Pd, rate)
        scen.append((f'rate={rate}', dataclasses.replace(Pd, L=L)))
    for cp in CPS:
        cst = {kk: cp * Pd.p[kk] for kk in Pd.p}
        scen.append((f'cp={cp}', dataclasses.replace(Pd, cst=cst)))
    for th in THETAS:
        scen.append((f'theta={th}', dataclasses.replace(Pd, afford_cap=float(th))))

    for tag, Ps in scen:
        t1 = time.time()
        rs = solve_joint(Ps, 'coverage', B=BIG_B, fix_z={pid: 0 for pid in Ps.projects},
                         time_limit=args.time_limit, gap=args.gap)
        t2 = time.time()
        rf = solve_joint(Ps, 'coverage', B=BIG_B, time_limit=args.time_limit, gap=args.gap)
        ms = metrics_from_T(Ps, rs['T']) if rs['status'] == 'OPTIMAL' else {}
        mf = metrics_from_T(Ps, rf['T']) if rf['status'] == 'OPTIMAL' else {}
        row = {'scenario': tag,
               'D': sum(Ps.L.values()),
               'stock_v': ms.get('v'), 'stock_cov': ms.get('coverage'),
               'full_v': mf.get('v'), 'full_cov': mf.get('coverage'),
               'full_SDM': mf.get('SDM'), 'full_spend': rf.get('spend'),
               'full_buildK': rf.get('buildK'), 'full_subsidy': rf.get('subsidy'),
               'time_s': round(time.time() - t1 + (time.time() - t2), 1)}
        if tag == 'baseline':
            v_base, spend_base, cov_base = row['full_v'], row['full_spend'], row['full_cov']
            row['d_full_v'] = 0
            row['d_full_spend'] = 0
        else:
            row['d_full_v'] = (row['full_v'] - v_base) if (row['full_v'] and v_base) else None
            row['d_full_spend'] = ((row['full_spend'] - spend_base)
                                   if (row['full_spend'] and spend_base) else None)
        rows_b.append(row)
        print(f"  [{tag}] stock={row['stock_v']}, full={row['full_v']} "
              f"(Δv={row['d_full_v']}), spend={row['full_spend'] and round(row['full_spend'])}, "
              f"SDM={row['full_SDM'] and round(row['full_SDM'], 4)}")

    df_b = pd.DataFrame(rows_b)
    df_b.to_csv(out_dir / 'e4_summary.csv', index=False, encoding='utf-8-sig')

    # ---- 落盘 + 图 ----
    sens = {'part_A_tau_threshold': {'tau_star_min': tau_star,
                                     'verdict_by_tau': rows,
                                     'note': '主口径 NH 保障；z=1,y=1 全激活上界判据（Lemma 1）'},
            'part_B_diagnostic': {'rows': rows_b,
                                  'note': 'b:=0 诊断口径（与 E1/E2 同口径）；'
                                          '每情景 stock+full 两解；不预设方向'},
            'perturbation_protocol': {'tau': TAUS_B, 'demand_rate': RATES,
                                      'cost_ratio_cp': CPS,
                                      'baseline': {'tau': 30, 'rate': R0, 'cp': 0.80}}}
    (out_dir / 'e4_sensitivity.json').write_text(
        json.dumps(sens, ensure_ascii=False, indent=2, default=str),
        encoding='utf-8')

    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman'],
                             'font.size': 8})
        fig_dir = out_dir / 'figures'
        fig_dir.mkdir(exist_ok=True)

        # Fig.10a: τ 门槛（主口径最大流 vs Σb）
        fig, ax = plt.subplots(figsize=(3.5, 2.6))
        ax.plot(tau_df['tau_min'], tau_df['maxflow_z1_all'], 'o-',
                color='#1a1a1a', ms=4, label='Maxflow (z=1, all projects)')
        ax.axhline(int(tau_df['required_b_NH'].iloc[0]), color='#c0392b',
                   ls='--', lw=1, label=r'Required $\sum b$ (NH)')
        ax.axvline(30, color='#888888', ls=':', lw=0.8)
        ax.annotate(r'baseline $\tau$=30', (30, ax.get_ylim()[0]),
                    textcoords='offset points', xytext=(3, 4), fontsize=6,
                    color='#555555')
        if tau_star:
            ax.axvline(tau_star, color='#2e7d32', ls='-.', lw=0.9)
            ax.annotate(fr'$\tau^*$', (tau_star, tau_df['maxflow_z1_all'].max()),
                        textcoords='offset points', xytext=(3, -8),
                        fontsize=8, color='#2e7d32')
        ax.set_xlabel(r'Service range $\tau$ (min)')
        ax.set_ylabel('Max guaranteeable NH beds')
        ax.grid(alpha=0.25, linewidth=0.4)
        ax.legend(frameon=False, fontsize=6.5, loc='lower right')
        fig.tight_layout()
        fig.savefig(fig_dir / 'Fig10a_tau_threshold.pdf')
        fig.savefig(fig_dir / 'Fig10a_tau_threshold.png', dpi=600)
        plt.close(fig)

        # Fig.10b: 诊断口径扰动 tornado（Δv_full 与 Δspend_full）
        pert = [r for r in rows_b if r['scenario'] != 'baseline']
        if pert and v_base:
            fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.4))
            labels = [r['scenario'] for r in pert]
            y = range(len(pert))
            axes[0].barh(list(y), [r['d_full_v'] for r in pert], color='#555555')
            axes[0].set_yticks(list(y), labels, fontsize=7)
            axes[0].axvline(0, color='#1a1a1a', lw=0.8)
            axes[0].set_xlabel(r'$\Delta$ covered beds (full build)')
            axes[1].barh(list(y), [r['d_full_spend'] / 1e4 if r['d_full_spend']
                                   is not None else 0 for r in pert],
                         color='#555555')
            axes[1].set_yticks(list(y), labels, fontsize=7)
            axes[1].axvline(0, color='#1a1a1a', lw=0.8)
            axes[1].set_xlabel(r'$\Delta$ spend (10k CNY)')
            for ax in axes:
                ax.grid(alpha=0.25, axis='x', linewidth=0.4)
            fig.tight_layout()
            fig.savefig(fig_dir / 'Fig10b_tornado.pdf')
            fig.savefig(fig_dir / 'Fig10b_tornado.png', dpi=600)
            plt.close(fig)
    except Exception as e:  # noqa: BLE001
        print(f'  [WARN] 出图失败: {e}')

    meta.update({'e4': {'tau_star_min': tau_star,
                        'baseline_full_v': v_base, 'baseline_spend': spend_base},
                 'elapsed_s': round(time.time() - t0, 1),
                 'solver': f'PuLP {pulp.__version__} + HiGHS, threads=1, gap={args.gap}',
                 'sha256_inputs': meta['sha256_inputs']})
    (out_dir / 'e4_run_meta.json').write_text(
        json.dumps(meta, ensure_ascii=False, indent=2, default=str),
        encoding='utf-8')
    print(f'\n=== E4 完成 -> {out_dir} (总耗时 {time.time()-t0:.0f}s) ===')


if __name__ == '__main__':
    main()
