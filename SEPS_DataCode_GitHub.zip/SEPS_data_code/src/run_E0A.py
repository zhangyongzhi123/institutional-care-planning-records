# -*- coding: utf-8 -*-
"""E0-A：服务保障可行性三方对照（穷举整数T / 子集割条件 / 最大流最小割）。

固定 (z,y) 与床型 k 的网络上，三种方法结论必须一致。
必须包含反例：总容量≥总需求，但某社区子集邻域容量不足 → 不可行，
且最小割报出具体社区与床型；该缺口无法用运营补贴修复。

用法： python run_E0A.py [--out runs/P0b_E0_20260924]
输出： <out>/E0A_feasibility.json
"""
import argparse
import itertools
import platform
import random
import sys
import time
import tracemalloc
from pathlib import Path

import networkx as nx
import pulp
import yaml

from model_io import Params, load_params
from run_exampleA import dump, legal_zy_combos
from solvers import get_stats, lemma1_maxflow, reset_stats, solve_milp, u_bound

ROOT = Path(__file__).resolve().parents[1]
EXHAUST_LIMIT = 200_000


# ---------------- 方法1：穷举整数T（保障可行性） ----------------
def exhaust_feasible(P: Params, k, z, y):
    """存在 T：0≤T_aj≤u、Σ_j T_aj≤Ĉ_a、Σ_a T_aj≥b_j（仅床型k的边）。"""
    edges = [(a, j) for a in P.facilities for j in P.communities
             if u_bound(P, a, j, k, z, y) > 0]
    n_comb = 1
    for a, j in edges:
        n_comb *= u_bound(P, a, j, k, z, y) + 1
        if n_comb > EXHAUST_LIMIT:
            return None, n_comb
    C = {a: P.capacity(a, k, z) if y.get(a, 0) else 0 for a in P.facilities}
    for combo in itertools.product(*[range(u_bound(P, a, j, k, z, y) + 1)
                                     for a, j in edges]):
        Tj = {j: 0 for j in P.communities}
        Ta = {a: 0 for a in P.facilities}
        for (a, j), t in zip(edges, combo):
            Tj[j] += t
            Ta[a] += t
        if all(Tj[j] >= P.b[(j, k)] for j in P.communities) and \
           all(Ta[a] <= C[a] for a in P.facilities):
            return True, n_comb
    return False, n_comb


# ---------------- 方法2：子集割条件（Lemma 1） ----------------
def subset_cut_feasible(P: Params, k, z, y):
    """∀X⊆J, X≠∅: Σ_{j∈X} b_jk ≤ Σ_a min{Ĉ_ak, Σ_{j∈X} u_ajk}。"""
    C = {a: P.capacity(a, k, z) if y.get(a, 0) else 0 for a in P.facilities}
    J = P.communities
    for r in range(1, len(J) + 1):
        for X in itertools.combinations(J, r):
            need = sum(P.b[(j, k)] for j in X)
            avail = sum(min(C[a], sum(u_bound(P, a, j, k, z, y) for j in X))
                        for a in P.facilities)
            if need > avail:
                return False, list(X)
    return True, None


# ---------------- 实例构造 ----------------
def micro_params(**kw):
    base = dict(
        communities=[], facilities=[], care_types=["NH"],
        L={}, b={}, I={}, C0={}, p={}, cst={}, H={}, F0={}, Pi0={}, d={},
        U0={}, alpha={}, beta_h={},
        tau=30.0, p_cap=3200.0, h_min=0.5, afford_cap=1.0,
        projects={}, deltaC={}, proj_of_fac={},
        W=(1 / 3, 1 / 3, 1 / 3), d0=20.0, gamma_p=1.0,
        theta=(0.5, 0.5, 2.0), lam_grid=(0.0, 2.0), omega_R=0.5,
        v_norm_bounds=(3000.0, 4600.0), pref={"NH": 1.0}, config={},
    )
    base.update(kw)
    return Params(**base)


def counterexample_subset():
    """任务单§2反例：a1=1,a2=3；j1只连a1；总容量4=总需求4，但X={j1}邻域1<2。"""
    return micro_params(
        communities=["j1", "j2"], facilities=["a1", "a2"],
        L={("j1", "NH"): 2, ("j2", "NH"): 2},
        b={("j1", "NH"): 2, ("j2", "NH"): 2},
        I={"j1": 4000.0, "j2": 4000.0},
        C0={("a1", "NH"): 1, ("a2", "NH"): 3},
        p={("a1", "NH"): 3000.0, ("a2", "NH"): 3000.0},
        cst={("a1", "NH"): 2000.0, ("a2", "NH"): 2000.0},
        H={("a1", "NH"): 0.8, ("a2", "NH"): 0.8},
        F0={"a1": 100.0, "a2": 100.0}, Pi0={"a1": 0.0, "a2": 0.0},
        d={("a1", "j1"): 5.0, ("a1", "j2"): 10.0,
           ("a2", "j1"): 45.0, ("a2", "j2"): 10.0},
        U0={"j1": -10.0, "j2": -10.0},
        alpha={"j1": 0.001, "j2": 0.001}, beta_h={"j1": 0.001, "j2": 0.001},
    )


def dual_type():
    """双床型实例：NH 可行、BK 子集瓶颈（总容量3=总需求3，X={j2} 邻域1<2）。

    j2 的 BK 保障只能由 a2 满足（a1j2 超时禁边），a2 BK 容量1 < b=2。
    """
    return micro_params(
        communities=["j1", "j2"], facilities=["a1", "a2"],
        care_types=["BK", "NH"],
        L={("j1", "NH"): 3, ("j1", "BK"): 2, ("j2", "NH"): 2, ("j2", "BK"): 2},
        b={("j1", "NH"): 1, ("j1", "BK"): 1, ("j2", "NH"): 0, ("j2", "BK"): 2},
        I={"j1": 4000.0, "j2": 4000.0},
        C0={("a1", "NH"): 2, ("a1", "BK"): 2, ("a2", "NH"): 2, ("a2", "BK"): 1},
        p={(a, k): 3000.0 for a in ("a1", "a2") for k in ("BK", "NH")},
        cst={(a, k): 2000.0 for a in ("a1", "a2") for k in ("BK", "NH")},
        H={(a, k): 0.8 for a in ("a1", "a2") for k in ("BK", "NH")},
        F0={"a1": 100.0, "a2": 100.0}, Pi0={"a1": 0.0, "a2": 0.0},
        d={("a1", "j1"): 10.0, ("a1", "j2"): 35.0,
           ("a2", "j1"): 25.0, ("a2", "j2"): 10.0},
        U0={"j1": -10.0, "j2": -10.0},
        alpha={"j1": 0.001, "j2": 0.001}, beta_h={"j1": 0.001, "j2": 0.001},
        pref={"NH": 1.0, "BK": 1.0},
    )


def random_micro(rng):
    """随机微型实例（确定性种子）：χ 由 d≤τ 决定，其余阈值全放行。"""
    n_j = rng.choice([2, 3, 4])
    n_a = rng.choice([2, 3])
    communities = [f"j{i+1}" for i in range(n_j)]
    facilities = [f"a{i+1}" for i in range(n_a)]
    d = {(a, j): round(rng.uniform(5, 50), 1)
         for a in facilities for j in communities}
    L = {(j, "NH"): rng.randint(1, 3) for j in communities}
    b = {(j, "NH"): rng.randint(0, min(2, L[(j, "NH")])) for j in communities}
    if sum(b.values()) == 0:
        j = rng.choice(communities)
        b[(j, "NH")] = 1
    C0 = {(a, "NH"): rng.randint(1, 4) for a in facilities}
    return micro_params(
        communities=communities, facilities=facilities, L=L, b=b,
        I={j: 4000.0 for j in communities},
        C0=C0,
        p={(a, "NH"): 3000.0 for a in facilities},
        cst={(a, "NH"): 2000.0 for a in facilities},
        H={(a, "NH"): 0.8 for a in facilities},
        F0={a: 100.0 for a in facilities}, Pi0={a: 0.0 for a in facilities},
        d=d, U0={j: -10.0 for j in communities},
        alpha={j: 0.001 for j in communities},
        beta_h={j: 0.001 for j in communities},
    )


# ---------------- 三方对照引擎 ----------------
def three_way(P: Params, k, z, y, instance_id, run_milp_check=True):
    row = {"instance_id": instance_id, "care_type": k,
           "z": z, "y": y,
           "total_b": sum(P.b[(j, k)] for j in P.communities),
           "total_cap": sum(P.capacity(a, k, z) if y.get(a, 0) else 0
                            for a in P.facilities)}
    # 方法1 穷举
    m1, n_comb = exhaust_feasible(P, k, z, y)
    row["m1_exhaustive"] = ("SKIPPED" if m1 is None else ("FEASIBLE" if m1 else "INFEASIBLE"))
    row["m1_n_combinations"] = n_comb
    # 方法2 子集割
    m2, Xbad = subset_cut_feasible(P, k, z, y)
    row["m2_subset_cut"] = "FEASIBLE" if m2 else "INFEASIBLE"
    row["m2_violated_subset"] = Xbad
    # 方法3 最大流/最小割
    ok, val, Sset = lemma1_maxflow(P, k, z, y)
    blocked = sorted(Sset & set(P.communities))
    row["m3_maxflow"] = "FEASIBLE" if ok else "INFEASIBLE"
    row["m3_maxflow_value"] = val
    row["m3_required"] = row["total_b"]
    row["m3_mincut_blocked_communities"] = blocked if not ok else []
    # 每社区实收流量 → 精确判starved（比mincut源侧集更细：反例中j2未被卡）
    G = nx.DiGraph()
    src, snk = "SRC", "SNK"
    for j in P.communities:
        if P.b[(j, k)] > 0:
            G.add_edge(src, j, capacity=int(P.b[(j, k)]))
    for a in P.facilities:
        for j in P.communities:
            u = u_bound(P, a, j, k, z, y)
            if u > 0:
                G.add_edge(j, a, capacity=int(u))
        cap = P.capacity(a, k, z) if y.get(a, 0) else 0
        if cap > 0:
            G.add_edge(a, snk, capacity=int(cap))
    if nx.has_path(G, src, snk):
        _fv, flow_dict = nx.maximum_flow(G, src, snk,
                                         flow_func=nx.algorithms.flow.shortest_augmenting_path)
        received = {j: sum(flow_dict.get(j, {}).get(a, 0) for a in P.facilities)
                    for j in P.communities}
        row["received_by_community"] = received
        row["starved_communities"] = sorted(j for j in P.communities
                                            if received[j] < P.b[(j, k)])
    else:
        row["received_by_community"] = {j: 0 for j in P.communities}
        row["starved_communities"] = [j for j in P.communities if P.b[(j, k)] > 0]
    # 一致性
    verdicts = [row["m2_subset_cut"], row["m3_maxflow"]]
    if m1 is not None:
        verdicts.append(row["m1_exhaustive"])
    row["consistent"] = len(set(verdicts)) == 1
    row["m1_skipped"] = m1 is None
    # 反例语义：不可行时，无限预算MILP仍不可行 → 补贴无法修复
    if not ok and run_milp_check:
        r = solve_milp(P, z, y, 1e9, "maxflow")
        row["unlimited_budget_milp_status"] = r["status"]
        row["subsidy_cannot_fix"] = r["status"] == "PROVEN_INFEASIBLE"
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    t0w = time.time()
    tracemalloc.start()
    reset_stats()
    cfg = yaml.safe_load((ROOT / "config" / "exampleA.yaml").read_text(encoding="utf-8"))
    P_A, _ = load_params(ROOT / "data" / "raw" / "eldercare_inputs_A.xlsx", cfg)
    out = Path(args.out) if args.out else ROOT / "runs" / f"P0b_E0_{time.strftime('%Y%m%d_%H%M%S')}"
    out.mkdir(parents=True, exist_ok=True)

    rows = []
    # ① 示例A：z=0 与 z=1（y 全参与）
    for tag, z, y in [("exampleA_z0", {}, {"a1": 1, "a2": 1}),
                      ("exampleA_z1", {"p1": 1}, {"a1": 1, "a2": 1})]:
        rows.append(three_way(P_A, "NH", z, y, tag))
    # ② 子集瓶颈反例
    rows.append(three_way(counterexample_subset(), "NH", {}, {"a1": 1, "a2": 1},
                          "COUNTEREXAMPLE_subset_bottleneck"))
    # ③ 双床型实例（NH 可行 / BK 不可行 → 分床型独立 + BK自身为子集瓶颈）
    P_D = dual_type()
    for k in ("NH", "BK"):
        rows.append(three_way(P_D, k, {}, {"a1": 1, "a2": 1}, f"dual_type_{k}"))
    # ④ 随机微型实例（固定种子）
    rng = random.Random(20260923)
    made, tries = 0, 0
    while made < 24 and tries < 200:
        tries += 1
        P_r = random_micro(rng)
        if sum(P_r.b[(j, "NH")] for j in P_r.communities) == 0:
            continue
        made += 1
        rows.append(three_way(P_r, "NH", {}, {a: 1 for a in P_r.facilities},
                              f"RND_{made:03d}"))

    n_inc = sum(1 for r in rows if not r["consistent"])
    n_infeas = sum(1 for r in rows if r["m3_maxflow"] == "INFEASIBLE")
    report = {
        "purpose": "验证 Lemma 1 割条件实现正确：穷举/子集割/最大流三方一致",
        "seed": 20260923, "exhaust_limit": EXHAUST_LIMIT,
        "n_instances_rows": len(rows), "n_inconsistent": n_inc,
        "n_infeasible": n_infeas,
        "counterexample_statement": (
            "反例（COUNTEREXAMPLE_subset_bottleneck / dual_type_BK）：总容量≥总需求，"
            "但存在社区子集 X（最小割报出 X={j1} / X={j2} 与床型）使邻域容量不足 → "
            "三方法一致判不可行；无限预算 MILP 仍 PROVEN_INFEASIBLE —— "
            "在该固定项目与资格网络下，加运营补贴无法修复这个缺口（正文 Section V）。"
            "修复只能来自新增合格容量（如扩建该子集的邻域机构）。"),
        "cut_condition_boundary": (
            "割条件不再充分的边界（只声明、未解决）：跨床型共享护理人员、不可拆分的家庭安排、"
            "服务互补性、有限重配置等结构下，逐床型割条件通过不保证整体联合可行；"
            "E0 仅在'逐床型独立、床内可拆分'假设下使用该判据。"),
        "rows": rows,
        "run_stats": {
            "wall_time_s": round(time.time() - t0w, 3),
            "inner_calls": get_stats(),
            "peak_memory_mb": round(tracemalloc.get_traced_memory()[1] / 1e6, 2),
            "python": sys.version.split()[0], "platform": platform.platform(),
            "solver": f"PuLP {pulp.__version__} + HiGHS", "status": "OPTIMAL",
        },
    }
    assert n_inc == 0, f"E0-A 三方对照存在不一致 {n_inc} 处，先修复再进案例实验"
    dump(out, "E0A_feasibility", report)
    print(f"[run_E0A] rows={len(rows)} inconsistent={n_inc} infeasible={n_infeas} "
          f"-> {out/'E0A_feasibility.json'} ({time.time()-t0w:.1f}s)")


if __name__ == "__main__":
    main()
