# -*- coding: utf-8 -*-
"""E2（柳州）：三种规划机制 + 两类参与消融（任务单§6 E2）。

前置：E1 正式版判定 B_crit=∞（物理瓶颈）→ 与 E1 诊断模式完全同口径：
b:=0、预算 B=B_scale（满配全候选最低可实施支出）、真实路网（高德）。
共享：需求、候选项目宇宙、合同（χ 规则）、b、预算、评价指标、求解精度与时间上限。

机制（对照目标=基础 GMRA 词典序 max ΣT → max ΣQ0·T，不混入 QMA/PA 层）：
  Stock-only  : z≡0，允许存量重分配
  Sequential  : 冻结 T⁰（预注册 = Stock-only 覆盖最优解），T = T⁰ + U，z,y 自由；
                财政按终态 T 一次计列（T⁰ ⊆ T，不重复计费）
  Integrated  : 全系统联合重分配
若 Sequential 与 Integrated 同解，如实记录退化，不得伪造差异。

参与消融（模型约束消融，可行域改变；只报表面收益 + 实施缺口，不做无条件优劣排名）：
  no_IR     : 去机构参与理性（S/IR/补贴移除，财政仅 K(z) ≤ B）
  no_accept : 去家庭接受门槛（H/价格帽/可负担比；τ 服务范围边宇宙保留）

用法: python run_E2_liuzhou.py [--time-limit 180]
输出: runs/E2_liuzhou_<ts>/ e2_mechanisms.json, e2_ablations.json,
      e2_summary.csv, e2_run_meta.json, figures/Fig4_mechanisms.*
"""
import argparse
import dataclasses
import json
import time
from pathlib import Path

import pandas as pd
import pulp

ROOT = Path(__file__).resolve().parents[1]
import sys  # noqa: E402
sys.path.insert(0, str(ROOT / 'src'))

from run_E1_full import BIG_B, load_liuzhou, metrics_from_T, solve_joint  # noqa: E402


def pack(P, res, tag, t1):
    m = metrics_from_T(P, res['T'])
    return {'tag': tag, 'status': res['status'], 'v': res.get('v'),
            'spend': res.get('spend'), 'buildK': res.get('buildK'),
            'subsidy': res.get('subsidy'),
            'n_fac': sum(res['y'].values()), 'n_proj': sum(res['z'].values()),
            'time_s': round(time.time() - t1, 1), **m}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--time-limit', type=int, default=180)
    ap.add_argument('--gap', type=float, default=0.01)
    args = ap.parse_args()

    t0 = time.time()
    P, coords, fcoords, districts, meta = load_liuzhou(True)
    Pd = dataclasses.replace(P, b={kk: 0 for kk in P.b})
    print(f"=== E2 柳州三机制 ({meta['net']}, 诊断口径 b:=0) ===")

    out_dir = ROOT / 'runs' / f"E2_liuzhou_{time.strftime('%Y%m%d_%H%M%S')}"
    out_dir.mkdir(parents=True, exist_ok=True)

    # ---- 0. B_scale：满配全候选最低可实施支出（与 E1 满预算解同口径） ----
    t1 = time.time()
    r_full = solve_joint(Pd, 'coverage', B=BIG_B, time_limit=args.time_limit, gap=args.gap)
    B_scale = r_full['spend']
    v_full = r_full['v']
    print(f"  满配: {r_full['status']} v={v_full}, spend={B_scale:,.0f} "
          f"({time.time()-t1:.0f}s)")

    def q0_coeff(res):
        return {e: Pd.Q0(*e) for e in res['T']}

    # ---- 1. Stock-only（z≡0；T⁰ 预注册 = 其覆盖最优解） ----
    z0 = {pid: 0 for pid in Pd.projects}
    t1 = time.time()
    r_stock = solve_joint(Pd, 'coverage', B=B_scale, fix_z=z0,
                          time_limit=args.time_limit, gap=args.gap)
    T0 = r_stock['T']
    m_stock = pack(Pd, r_stock, 'Stock-only', t1)
    t1 = time.time()
    r_stock_q = solve_joint(Pd, 'maxq', B=B_scale, coeff=q0_coeff(r_stock),
                            v=r_stock['v'], fix_z=z0, time_limit=args.time_limit, gap=args.gap)
    if r_stock_q['status'] == 'OPTIMAL':
        m_stock.update(pack(Pd, r_stock_q, 'Stock-only', t1))
        T0 = r_stock_q['T']
    print(f"  Stock-only: v={m_stock['v']}, SDM={m_stock['SDM']}, "
          f"spend={m_stock['spend']:,.0f}")

    # ---- 2. Sequential（T ≥ T⁰ 冻结；z,y 自由；终态财政一次计列） ----
    t1 = time.time()
    r_seq = solve_joint(Pd, 'coverage', B=B_scale, T_floor=T0,
                        time_limit=args.time_limit, gap=args.gap)
    m_seq = pack(Pd, r_seq, 'Sequential(T0=stock-optimal)', t1)
    if r_seq['status'] == 'OPTIMAL':
        t1 = time.time()
        r_seq_q = solve_joint(Pd, 'maxq', B=B_scale, coeff=q0_coeff(r_seq),
                              v=r_seq['v'], T_floor=T0, time_limit=args.time_limit, gap=args.gap)
        if r_seq_q['status'] == 'OPTIMAL':
            m_seq.update(pack(Pd, r_seq_q, 'Sequential(T0=stock-optimal)', t1))
    print(f"  Sequential: v={m_seq['v']}, SDM={m_seq['SDM']}, "
          f"spend={m_seq['spend']:,.0f}")

    # ---- 3. Integrated（联合重分配） ----
    t1 = time.time()
    r_int = solve_joint(Pd, 'coverage', B=B_scale, time_limit=args.time_limit, gap=args.gap)
    m_int = pack(Pd, r_int, 'Integrated', t1)
    if r_int['status'] == 'OPTIMAL':
        t1 = time.time()
        r_int_q = solve_joint(Pd, 'maxq', B=B_scale, coeff=q0_coeff(r_int),
                              v=r_int['v'], time_limit=args.time_limit, gap=args.gap)
        if r_int_q['status'] == 'OPTIMAL':
            m_int.update(pack(Pd, r_int_q, 'Integrated', t1))
    print(f"  Integrated: v={m_int['v']}, SDM={m_int['SDM']}, "
          f"spend={m_int['spend']:,.0f}")

    degenerate = (r_seq['status'] == 'OPTIMAL' and r_int['status'] == 'OPTIMAL'
                  and m_seq['v'] == m_int['v']
                  and r_seq_q.get('T') is not None and r_int_q.get('T') is not None
                  and r_seq_q['T'] == r_int_q['T'])
    mech = {'shared': {'b': '0 (diagnostic, E1 verdict B_crit=INF_PHYSICAL)',
                       'B_scale': B_scale, 'T0_source': 'Stock-only coverage-optimal '
                       '(pre-registered)', 'objective': 'lex (max sum T -> max sum Q0*T)',
                       'net': meta['net'], 'time_limit': args.time_limit},
            'T0': {",".join(e): int(v) for e, v in T0.items() if v > 0},
            'T0_v': m_stock['v'],
            'stock_only': m_stock, 'sequential': m_seq, 'integrated': m_int,
            'degenerate_note': ('Sequential 与 Integrated 同解（T 逐边相同）——如实记录退化'
                                if degenerate else
                                'Sequential 与 Integrated 解不同（T⁰ 冻结产生真实差异）')}

    # ---- 4. 参与消融（模型约束消融：只报表面收益 + 实施缺口） ----
    v_int = m_int['v'] or 0
    abl = {'reference': {'tag': 'Integrated', 'v': v_int, 'B_scale': B_scale},
           'note': ('模型约束消融：可行域改变，只报"表面收益+实施缺口"，'
                    '禁止与原模型做无条件优劣排名（任务单§4.3）')}

    t1 = time.time()
    r_nir = solve_joint(Pd, 'coverage', B=B_scale, drop_ir=True,
                        time_limit=args.time_limit, gap=args.gap)
    nir = {'tag': 'no_IR', 'status': r_nir['status'], 'v': r_nir.get('v'),
           'surface_gain_v': (r_nir.get('v') or 0) - v_int,
           'time_s': round(time.time() - t1, 1)}
    if r_nir['status'] == 'OPTIMAL':
        nir['subsidy_required_psi'] = r_nir['spend']
        nir['facilities_needing_subsidy'] = {
            a: round(d, 2) for a, d in r_nir['S'].items() if d > 1e-9}
        nir['gap_note'] = ('这些机构在原模型下因 Π<Π⁰ 拒绝参与；无补贴则分配不可实施')
    abl['no_IR'] = nir
    print(f"  no_IR: v={nir['v']} (表面收益 {nir['surface_gain_v']:+d}), "
          f"需补贴机构 {len(nir.get('facilities_needing_subsidy', {}))}")

    t1 = time.time()
    r_nch = solve_joint(Pd, 'coverage', B=B_scale, drop_chi=True,
                        time_limit=args.time_limit, gap=args.gap)
    nch = {'tag': 'no_household_acceptance', 'status': r_nch['status'],
           'v': r_nch.get('v'),
           'surface_gain_v': (r_nch.get('v') or 0) - v_int,
           'time_s': round(time.time() - t1, 1)}
    if r_nch['status'] == 'OPTIMAL':
        viol = [{'edge': ",".join(e), 'beds': t} for e, t in r_nch['T'].items()
                if t > 0 and not Pd.hard_chi(*e)[0]]
        nch['beds_on_violating_edges'] = int(sum(x['beds'] for x in viol))
        nch['n_violating_edges'] = len(viol)
        nch['gap_note'] = ('这些床放在 χ=0 边上（质量/价格/可负担比被拒）：家庭会拒绝，'
                           '构成实施缺口；τ 服务范围边宇宙保留')
    abl['no_acceptance'] = nch
    print(f"  no_accept: v={nch['v']} (表面收益 {nch['surface_gain_v']:+d}), "
          f"违χ床数 {nch.get('beds_on_violating_edges')}")

    # ---- 5. 落盘 + Fig.4 ----
    (out_dir / 'e2_mechanisms.json').write_text(
        json.dumps(mech, ensure_ascii=False, indent=2), encoding='utf-8')
    (out_dir / 'e2_ablations.json').write_text(
        json.dumps(abl, ensure_ascii=False, indent=2), encoding='utf-8')
    rows = [m_stock, m_seq, m_int]
    pd.DataFrame(rows).to_csv(out_dir / 'e2_summary.csv', index=False,
                              encoding='utf-8-sig')

    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman'],
                             'font.size': 8})
        fig_dir = out_dir / 'figures'
        fig_dir.mkdir(exist_ok=True)
        ok = [r for r in rows if r['status'] == 'OPTIMAL' and r.get('v')]
        tags = {'Stock-only': 'o', 'Sequential(T0=stock-optimal)': 's',
                'Integrated': '^'}
        fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.8))
        for ax, ykey, ylab in [(axes[0], 'coverage', 'Coverage'),
                               (axes[1], 'SDM', 'SDM')]:
            for r in ok:
                ax.plot(r['spend'] / 1e4, r[ykey] * (100 if ykey == 'coverage' else 1),
                        tags[r['tag']], color='#1a1a1a', ms=6,
                        label=r['tag'].split('(')[0])
            ax.set_xlabel('Actual spend (10k CNY)')
            ax.set_ylabel(ylab + (' (%)' if ykey == 'coverage' else ''))
            ax.grid(alpha=0.25, linewidth=0.4)
        axes[0].legend(frameon=False, fontsize=7, loc='lower right')
        for i, r in enumerate(ok):
            axes[0].annotate(r['tag'].split('(')[0], (r['spend'] / 1e4,
                             r['coverage'] * 100), textcoords='offset points',
                             xytext=(0, -11 if i else 6), fontsize=6)
        axes[0].set_title('(a) Coverage vs spend', fontsize=9)
        axes[1].set_title('(b) Equity vs spend', fontsize=9)
        fig.tight_layout()
        fig.savefig(fig_dir / 'Fig4_mechanisms.pdf')
        fig.savefig(fig_dir / 'Fig4_mechanisms.png', dpi=600)
        plt.close(fig)
    except Exception as e:  # noqa: BLE001
        print(f'  [WARN] 出图失败: {e}')

    meta.update({'e2': {'B_scale': B_scale, 'v_stock': m_stock['v'],
                        'v_seq': m_seq['v'], 'v_int': m_int['v'],
                        'degenerate': degenerate,
                        'abl_no_ir_v': nir['v'],
                        'abl_no_accept_v': nch['v']},
                 'elapsed_s': round(time.time() - t0, 1),
                 'solver': f'PuLP {pulp.__version__} + HiGHS, threads=1, gap={args.gap}',
                 'sha256_inputs': meta['sha256_inputs']})
    (out_dir / 'e2_run_meta.json').write_text(
        json.dumps(meta, ensure_ascii=False, indent=2, default=str),
        encoding='utf-8')
    print(f'\n=== E2 完成 -> {out_dir} (总耗时 {time.time()-t0:.0f}s) ===')


if __name__ == '__main__':
    main()
