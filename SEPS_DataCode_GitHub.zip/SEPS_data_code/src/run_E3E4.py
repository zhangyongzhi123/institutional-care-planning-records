# -*- coding: utf-8 -*-
"""E3 算法层消融 + E4 规模/敏感性 —— 合成数据全量实验。

按 V2§5.3 规格:
  小规模真值:  5×10×3, 10种子 (已P2试跑)
  中规模:     20×100×3, 10种子 (edge_p=0.85)
  大规模:     50×300 / 100×600 (edge_p=0.85, 5种子)

消融方法: 基础GMRA(maxflow)、原QMA(λ=0)、PA-QMA(λ=2)、No-R、No-V

输出: runs/E3E4_20260924/e3e4_results.json + e3e4_summary.csv

用法: python run_E3E4.py --mode small|mid|large|all --time-limit 120
"""
import argparse
import json
import sys
import time
import tracemalloc
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import model_io; model_io.CARE_TYPES = ('NH', 'BK', 'WELLNESS')
from run_E3_p2 import inst_to_params
from solvers import solve_milp
from metrics import compute_metrics
from synthetic import generate_instance


def run_one(inst, config):
    """单实例多方法求解。"""
    P = inst_to_params(inst)
    BIG_B = 1e12
    z = {pid: 0 for pid in P.projects}
    y = {a: 1 for a in P.facilities}
    tl = config.get('time_limit', 120)

    res = {'meta': inst['meta'], 'methods': {}}
    tracemalloc.start()

    # 1. maxflow (GMRA 基础)
    t0 = time.time()
    r_mf = solve_milp(P, z, y, BIG_B, 'maxflow', time_limit=tl)
    t_mf = time.time() - t0
    T_mf = r_mf.get('T') or {}
    vmax = int(r_mf.get('obj', 0) or 0)
    res['vmax'] = vmax
    res['methods']['GMRA'] = {
        'status': r_mf['status'], 'v': vmax, 'time_s': round(t_mf, 3),
        'metrics': compute_metrics(P, T_mf) if T_mf else {},
    }

    if vmax <= 0:
        tracemalloc.stop()
        res['peak_mem_mb'] = round(tracemalloc.get_traced_memory()[1] / 1e6, 1)
        return res

    # 2. Q0, Q̄, PA-QMA 信号
    Q0_map = {e: P.Q0(*e) for e in P.edges()}
    chi_map = {e: P.hard_chi(*e)[0] for e in P.edges()}
    allowed_Q0 = [Q0_map[e] for e in P.edges() if chi_map[e]]
    mean_Q0 = sum(allowed_Q0) / max(1, len(allowed_Q0))
    delta0 = max(0.01, (sum((q - mean_Q0)**2 for q in allowed_Q0) / max(1, len(allowed_Q0))) ** 0.5)

    Qbar_map, fvals = P.qma_Qbar(Q0_map, delta0)
    R_map = P.R_signal(T_mf)
    V_map = P.V_signal()
    pi_map = P.pi_signal(R_map, V_map)

    # 3. 原QMA (λ=0 退化)
    t0 = time.time()
    r_qma = solve_milp(P, z, y, BIG_B, 'maxq_budget', v=vmax, coeff=Qbar_map, time_limit=tl)
    t_qma = time.time() - t0
    T_qma = r_qma.get('T') or {}
    res['methods']['QMA_l0'] = {
        'status': r_qma['status'], 'time_s': round(t_qma, 3),
        'metrics': compute_metrics(P, T_qma) if T_qma else {},
    }

    # 4. PA-QMA (λ=2)
    for lam in [1.0, 2.0]:
        QPA_map = P.QPA(Qbar_map, pi_map, lam)
        t0 = time.time()
        r_pa = solve_milp(P, z, y, BIG_B, 'maxq_budget', v=vmax, coeff=QPA_map, time_limit=tl)
        t_pa = time.time() - t0
        T_pa = r_pa.get('T') or {}
        res['methods'][f'PA_QMA_l{lam}'] = {
            'status': r_pa['status'], 'time_s': round(t_pa, 3),
            'metrics': compute_metrics(P, T_pa) if T_pa else {},
        }

    # 5. No-R 消融 (R=0 → π=V → Q^PA 退化为 ω_V·Q̄·(1+λV)/(1+λ))
    pi_no_r = {r: 0.5 * 0 + 0.5 * V_map.get(r, 0) for r in R_map}  # ω_R=0.5, R=0
    QPA_no_r = P.QPA(Qbar_map, pi_no_r, 2.0)
    t0 = time.time()
    r_nor = solve_milp(P, z, y, BIG_B, 'maxq_budget', v=vmax, coeff=QPA_no_r, time_limit=tl)
    t_nor = time.time() - t0
    T_nor = r_nor.get('T') or {}
    res['methods']['No_R_l2'] = {
        'status': r_nor['status'], 'time_s': round(t_nor, 3),
        'metrics': compute_metrics(P, T_nor) if T_nor else {},
    }

    # 6. No-V 消融 (V=0 → π=R → Q^PA 退化为 ω_R·Q̄·(1+λR)/(1+λ))
    pi_no_v = {r: 0.5 * R_map.get(r, 0) + 0.5 * 0 for r in R_map}
    QPA_no_v = P.QPA(Qbar_map, pi_no_v, 2.0)
    t0 = time.time()
    r_nov = solve_milp(P, z, y, BIG_B, 'maxq_budget', v=vmax, coeff=QPA_no_v, time_limit=tl)
    t_nov = time.time() - t0
    T_nov = r_nov.get('T') or {}
    res['methods']['No_V_l2'] = {
        'status': r_nov['status'], 'time_s': round(t_nov, 3),
        'metrics': compute_metrics(P, T_nov) if T_nov else {},
    }

    tracemalloc.stop()
    res['peak_mem_mb'] = round(tracemalloc.get_traced_memory()[1] / 1e6, 1)
    res['delta0'] = round(delta0, 4)
    return res


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', default='small', choices=['small', 'mid', 'large', 'all'])
    parser.add_argument('--time-limit', type=int, default=120)
    parser.add_argument('--out', default='runs/E3E4_20260924')
    args = parser.parse_args()

    config = {'time_limit': args.time_limit}
    out_dir = ROOT / args.out
    out_dir.mkdir(parents=True, exist_ok=True)

    scales = {
        'small': [(5, 10, 10)],       # (n_j, n_a, count)
        'mid':   [(20, 100, 10)],
        'large': [(50, 300, 5), (100, 600, 5)],
    }
    if args.mode == 'all':
        runs = []
        for m in ['small', 'mid', 'large']:
            runs.extend([(m,) + x for x in scales[m]])
    else:
        runs = [(args.mode,) + x for x in scales[args.mode]]

    all_results = []
    for scale_name, n_j, n_a, count in runs:
        print(f'\n=== {scale_name}: {n_j}×{n_a}×3, {count}种子 ===')
        t_scale = time.time()
        for s in range(count):
            inst = generate_instance(n_j, n_a, seed=s, edge_p=0.85)
            r = run_one(inst, config)
            all_results.append(r)
            vmax = r.get('vmax', 0)
            if vmax > 0:
                gmra_cov = r['methods']['GMRA']['metrics'].get('coverage', 0)
                qma_cov = r['methods'].get('QMA_l0', {}).get('metrics', {}).get('coverage', 0)
                pa_cov = r['methods'].get('PA_QMA_l2', {}).get('metrics', {}).get('coverage', 0)
                print(f'  s={s}: vmax={vmax}, GMRA_cov={gmra_cov:.3f}, QMA_cov={qma_cov:.3f}, PA_cov={pa_cov:.3f}, '
                      f't={r["methods"]["GMRA"]["time_s"]:.2f}s, mem={r.get("peak_mem_mb",0):.1f}MB')
            else:
                print(f'  s={s}: vmax=0 INFEASIBLE')
        print(f'  scale done in {time.time()-t_scale:.1f}s')

    # 汇总
    print(f'\n=== E3/E4 汇总 ===')
    summary_rows = []
    for r in all_results:
        meta = r['meta']
        if r.get('vmax', 0) <= 0:
            continue
        for method, mr in r['methods'].items():
            m = mr.get('metrics', {})
            summary_rows.append({
                'scale': f"{meta['n_j']}x{meta['n_a']}",
                'seed': meta['seed'], 'method': method,
                'vmax': r['vmax'], 'time_s': mr['time_s'],
                'status': mr['status'], 'peak_mem_mb': r['peak_mem_mb'],
                'coverage': m.get('coverage'), 'SDM': m.get('SDM'),
                'dist': m.get('dist'), 'Q0_avg': m.get('Q0_avg'),
            })
    df = pd.DataFrame(summary_rows)
    if len(df):
        agg = df.groupby(['scale', 'method']).agg(
            n=('seed', 'count'),
            cov_mean=('coverage', 'mean'), cov_std=('coverage', 'std'),
            SDM_mean=('SDM', 'mean'), SDM_std=('SDM', 'std'),
            time_mean=('time_s', 'mean'), time_p90=('time_s', lambda x: x.quantile(0.9)),
            mem_mean=('peak_mem_mb', 'mean'),
        ).round(4).reset_index()
        print(agg.to_string(index=False))
        agg.to_csv(out_dir / 'e3e4_summary.csv', index=False)
        df.to_csv(out_dir / 'e3e4_raw.csv', index=False)

    (out_dir / 'e3e4_results.json').write_text(
        json.dumps(all_results, indent=2, default=lambda x: float(x) if hasattr(x, '__float__') else str(x),
                   allow_nan=True), encoding='utf-8')
    print(f'\n结果 -> {out_dir}')


if __name__ == '__main__':
    main()
