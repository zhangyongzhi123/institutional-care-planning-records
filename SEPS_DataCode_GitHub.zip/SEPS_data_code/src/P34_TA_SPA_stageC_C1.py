# -*- coding: utf-8 -*-
"""TA-SPA-QMA-Protocol-v1.0 阶段C / C1：Example A 全枚举核验 M1–M6（GPT6.1 批准 2026-10-10）。

预注册协议（不得据结果调参）：
  实例：复用阶段A已审计的 P0_exampleA / Example A（禁止新建/修改实例、输入、网络、
        容量、需求、项目、参考信号和冻结参数）。
  六方法（不得混名）：
    M1 Base-QMA            : max ΣQ̄·T
    M2 Original PA-QMA     : max ΣQ^PA(λ)·T（Policy34 冻结口径）
    M3 TA-SPA-global       : max {ΣQ̄·T + λΣω·w}，ω=π/Σπ（全角色归一化，阶段B原版）
    M4 TA-SPA-reachable    : ω^reach_jk=π_jk/Σ_{(j',k')∈R}π_j'k'，R={(j,k):∃a,χ_ajk=1}
                             max {ΣQ̄·T + λΣω^reach·w}
    M5 Target-constrained  : 两阶段词典序（原生 bound 报告，不用人为±1容差）
        Stage1: max H(T)=Σω·w  → 记录 incumbent/bound/status/gap
        若 OPTIMAL(bound closed): Stage2: 固定 Σω·w=H1*, max ΣQ̄·T
        若 time-limit: Stage2 在 Stage1 认证可行下界约束上运行，标注 bound-aware
        无法构造证据完整 Stage2 → NOT_CERTIFIED
    M6 Target-only diag.   : max Σω·w（λ无关，诊断性，不作优越基准）
  冻结：h=b+0.5(L−b), b=0⇒h=0.5L；ω=π/Σπ（π=0.5R(T_ref)+0.5V, T_ref=冻结参考）；
        λ∈{0,1,2}（0 为 sanity check 退化验证）；B=B_H(月度)；v∈{5,10}；ρ_h=0.50。
  可行域：所有方法共用同一基约束块（式(4)(5)(6)+z≤y+IR+财政+ΣT=v）；
          w 不限制 T 可行域（0≤w≤min{N,h}，ω≥0 ⇒ 最优处 w=min{N,h}）。

C1 七项核验（GPT6.1 §5）：
  C1.1 所有方法硬约束完全相同（可行域同一）
  C1.2 M3/M4 的 w_jk 逐项满足 w=min{N_jk, h_jk}（ω>0 角色）
  C1.3 M5 第一阶段和第二阶段均与穷举最优值一致
  C1.4 λ=0 时 M3/M4 退化为 Base-QMA（逐点目标恒等 + argmax 集合同一）
  C1.5 M4 只改变政策权重，不改变可行域
  C1.6 M5 只改变词典序目标，不改变可行域
  C1.7 所有方法完整解向量逐项通过独立约束审计
  另：不同方法 objective 使用各自定义，不直接比较异尺度 objective；
      记录每方法 Base-QMA score / policy reward / combined objective / H(T) / G_h(T)。

C1 全 PASS → 可进入 C2；C1 失败即停止，不运行 C2，不调参，不回填 Policy34。

输出：experiments/Policy34_TA_SPA_QMA_v1/stage_C/c1/
  stage_C1_audit.json          C1 七项核验总报告
  stage_C1_config_frozen.json  冻结参数快照
  stage_C1_enumeration.csv     全枚举分配 × 六方法目标
  stage_C1_milp_vs_enum.csv    每方法/λ：穷举最优 vs MILP + 解集合成员 + w审计
  stage_C1_solutions/          每方法完整 T/y/z/S/w + native 状态
  README_STAGE_C1.md
"""
import hashlib
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np
import pulp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import model_io  # noqa: E402
import solvers  # noqa: E402

PROTOCOL = 'TA-SPA-QMA-Protocol-v1.0'
RUN_ID = f'TA_SPA_STAGE_C_C1__{time.strftime("%Y%m%d_%H%M%S")}'
OUT = ROOT / 'experiments' / 'Policy34_TA_SPA_QMA_v1' / 'stage_C' / 'c1'
(OUT / 'stage_C1_solutions').mkdir(parents=True, exist_ok=True)
P0RUN_DIR = ROOT / 'runs' / 'P0_exampleA_20260923_185152'
XLSX = ROOT / 'data' / 'raw' / 'eldercare_inputs_A.xlsx'
LAM_GRID = [0.0, 1.0, 2.0]
RHO_GRID = [0.25, 0.50, 0.75]
V_SECTIONS = [5, 10]
CT = ('NH',)
# 阶段C 方法名（不得混名）
M_BASE = 'M1_BASE_QMA'
M_PA = 'M2_PA_QMA'
M_TA_GLOBAL = 'M3_TA_SPA_GLOBAL'
M_TA_REACH = 'M4_TA_SPA_REACHABLE'
M_TARGET_CONS = 'M5_TARGET_CONSTRAINED'
M_TARGET_ONLY = 'M6_TARGET_ONLY'
# λ 相关方法
LAM_METHODS = [M_PA, M_TA_GLOBAL, M_TA_REACH]
NO_LAM_METHODS = [M_BASE, M_TARGET_CONS, M_TARGET_ONLY]


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def native_info(prob):
    try:
        h = prob.solverModel
        info = h.getInfo()
        out = {'model_status': str(h.getModelStatus())}
        for ks, kd in [('objective_function_value', 'objective'),
                        ('mip_dual_bound', 'bound'), ('mip_gap', 'gap')]:
            try:
                v = getattr(info, ks)
                out[kd] = float(v) if v is not None and abs(v) < 1e30 else None
            except Exception:
                out[kd] = None
        return out
    except Exception as e:
        return {'error': repr(e)}


def main():
    t0 = time.time()
    P0run = json.loads((P0RUN_DIR / 'run_meta.json').read_text(encoding='utf-8'))
    cfg = dict(P0run['config'])
    Pe, T_ref = model_io.load_params(XLSX, cfg)
    B = float(cfg['budgets']['B_H'])
    facs, coms = Pe.facilities, Pe.communities
    roles = [(j, k) for j in coms for k in CT if Pe.L.get((j, k), 0) > 0]

    # ---------- 冻结参数 ----------
    R_sig = Pe.R_signal(T_ref)
    V_sig = Pe.V_signal()
    pi_sig = Pe.pi_signal(R_sig, V_sig)
    pi_sum = sum(pi_sig[r] for r in roles)
    omega = {r: (pi_sig[r] / pi_sum if pi_sum > 0 else 1.0 / len(roles)) for r in roles}

    # M4 reachable 集合：R = {(j,k): ∃a, χ_ajk=1 且 L>0}
    edges = [(a, j, k) for a in facs for j in coms for k in CT
             if Pe.hard_chi(a, j, k)[0] and Pe.L.get((j, k), 0) > 0]
    reachable_roles = sorted({(e[1], e[2]) for e in edges})
    unreachable_roles = [r for r in roles if r not in set(reachable_roles)]
    pi_sum_reach = sum(pi_sig[r] for r in reachable_roles)
    omega_reach = {
        r: (pi_sig[r] / pi_sum_reach if pi_sum_reach > 0 else 1.0 / len(reachable_roles))
        for r in reachable_roles}
    # 不可达角色 ω^reach=0
    for r in unreachable_roles:
        omega_reach[r] = 0.0

    h_map, h_grid = {}, {}
    for rho in RHO_GRID:
        for r in roles:
            b_, L_ = Pe.b[r], Pe.L[r]
            h_grid[(rho, r)] = (b_ + rho * (L_ - b_)) if L_ > 0 else 0.0
    h_map = {r: h_grid[(0.50, r)] for r in roles}

    Q0 = {e: Pe.Q0(*e) for e in edges}
    delta0 = max(0.01, float(np.std(list(Q0.values()))))
    Qbar, _f = Pe.qma_Qbar(Q0, delta0)
    QPA = {lam: Pe.QPA(Qbar, pi_sig, lam) for lam in LAM_GRID}

    # 合法外层 (z,y)
    combos = []
    y_opts = list(itertools.product([0, 1], repeat=len(facs)))
    for yy in y_opts:
        for z1 in ([0, 1] if Pe.projects else [0]):
            ymap = dict(zip(facs, yy))
            zmap = {}
            ok = True
            for pid, info in Pe.projects.items():
                zv = z1 if pid == list(Pe.projects)[0] else 0
                zmap[pid] = zv
                if zv > ymap[info['facility']]:
                    ok = False
            if ok:
                combos.append((zmap, ymap))
    combos = sorted({(tuple(sorted(z.items())), tuple(sorted(y.items())))
                     for z, y in combos})
    combos = [(dict(z), dict(y)) for z, y in combos]

    def feas_T(z, y, T, v):
        if sum(T.values()) != v or not solvers.phys_feasible_T(Pe, T, z, y):
            return False
        return solvers.psi(Pe, T, z, y)[0] <= B + 1e-9

    def objs(T, z, y):
        """逐项独立目标计算（真值来源；MILP 仅与之对账）。"""
        N = {r: sum(T.get((a, r[0], r[1]), 0) for a in facs) for r in roles}
        w = {r: min(N[r], h_map[r]) for r in roles}
        H_global = sum(omega[r] * w[r] for r in roles)
        H_reach = sum(omega_reach.get(r, 0.0) * w[r] for r in roles)
        sQ = sum(Qbar[e] * t for e, t in T.items())
        o = {'BASE_QMA': sQ,
             'H_global': H_global,
             'H_reach': H_reach,
             'Psi_monthly': solvers.psi(Pe, T, z, y)[0]}
        for lam in LAM_GRID:
            o[f'PA_QMA_lam{lam:g}'] = sum(QPA[lam][e] * t for e, t in T.items())
            o[f'TA_SPA_GLOBAL_lam{lam:g}'] = sQ + lam * H_global
            o[f'TA_SPA_REACH_lam{lam:g}'] = sQ + lam * H_reach
            o[f'TARGET_ONLY_lam{lam:g}'] = H_global
        return o, N, w

    # ---------- 穷举（物理+财政可行整数分配，逐方法目标） ----------
    enum_rows, feas_map = [], {}
    for ci, (z, y) in enumerate(combos):
        for v in V_SECTIONS:
            dom = [e for e in edges if solvers.u_bound(Pe, e[0], e[1], e[2], z, y) > 0]
            ranges = [range(solvers.u_bound(Pe, e[0], e[1], e[2], z, y) + 1) for e in dom]
            feas = []
            for combo in itertools.product(*ranges):
                T = dict(zip(dom, combo))
                if feas_T(z, y, T, v):
                    o, N, w = objs(T, z, y)
                    feas.append((T, o))
                    enum_rows.append({
                        'combo_id': ci,
                        'z': json.dumps(z, sort_keys=True), 'y': json.dumps(y, sort_keys=True),
                        'v': v, 'T': json.dumps({f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T.items()},
                                                sort_keys=True),
                        **{f'N_{r[0]}_{r[1]}': N[r] for r in roles},
                        **{f'w_{r[0]}_{r[1]}': w[r] for r in roles},
                        **{kk: float(vv) for kk, vv in o.items()},
                        **{f'h_rho{rho:g}_{r[0]}_{r[1]}': h_grid[(rho, r)]
                           for rho in RHO_GRID for r in roles}})
            feas_map[(ci, v)] = feas
    pd = __import__('pandas')
    pd.DataFrame(enum_rows).to_csv(OUT / 'stage_C1_enumeration.csv', index=False,
                                  encoding='utf-8-sig')

    # ---------- C5 饱和性：N≥h 后加 1 床不增加饱和奖励（全域扫描，不限 ΣT=v） ----------
    c5_scanned, c5_viol = 0, []
    for ci, (z, y) in enumerate(combos):
        dom_c5 = [e for e in edges if solvers.u_bound(Pe, e[0], e[1], e[2], z, y) > 0]
        rng_c5 = [range(solvers.u_bound(Pe, e[0], e[1], e[2], z, y) + 1) for e in dom_c5]
        full = []
        for combo in itertools.product(*rng_c5):
            T = dict(zip(dom_c5, combo))
            if solvers.phys_feasible_T(Pe, T, z, y) and solvers.psi(Pe, T, z, y)[0] <= B + 1e-9:
                N_c5 = {rr: sum(T.get((a, rr[0], rr[1]), 0) for a in facs) for rr in roles}
                full.append((T, N_c5,
                             sum(omega[rr] * min(N_c5[rr], h_map[rr]) for rr in roles)))
        fmap_c5 = {tuple(sorted(T.items())): (N_c5, H) for T, N_c5, H in full}
        for T, N_c5, H in full:
            for rr in roles:
                if N_c5[rr] < h_map[rr]:
                    continue
                for a in facs:
                    e = (a, rr[0], rr[1])
                    T2 = dict(T)
                    T2[e] = T.get(e, 0) + 1
                    k2 = tuple(sorted(T2.items()))
                    if k2 in fmap_c5:
                        c5_scanned += 1
                        if abs(fmap_c5[k2][1] - H) > 1e-12:
                            c5_viol.append({'combo': ci, 'role': str(rr), 'edge': str(e),
                                            'H_before': H, 'H_after': fmap_c5[k2][1]})

    # ---------- MILP（与穷举同域；基约束块对所有方法逐字相同） ----------
    def build_base_prob(ci, v):
        """构建基约束块（所有方法共用），返回 (prob, Tv, S, dom)。"""
        z, y = combos[ci]
        prob = pulp.LpProblem('stageC_base', pulp.LpMaximize)
        dom = [e for e in edges if solvers.u_bound(Pe, e[0], e[1], e[2], z, y) > 0]
        Tv = {e: pulp.LpVariable(f'T_{i}', lowBound=0, cat='Integer')
              for i, e in enumerate(dom)}
        for e in dom:
            prob += Tv[e] <= solvers.u_bound(Pe, e[0], e[1], e[2], z, y)
        for r in roles:
            prob += pulp.lpSum(Tv[e] for e in dom if (e[1], e[2]) == r) >= Pe.b[r]
            prob += pulp.lpSum(Tv[e] for e in dom if (e[1], e[2]) == r) <= Pe.L[r]
        for a in facs:
            prob += pulp.lpSum(Tv[e] for e in dom if e[0] == a) <= Pe.capacity(a, 'NH', z)
        prob += pulp.lpSum(Tv.values()) == v
        S = {a: pulp.LpVariable(f'S_{a}', lowBound=0) for a in facs}
        for a in facs:
            rev = pulp.lpSum((Pe.p[(a, k)] - Pe.cst[(a, k)]) * Tv[e]
                             for k in CT for e in dom if e[0] == a)
            fix = Pe.Pi0[a] * y[a] + Pe.F_active(a, z, y)
            prob += S[a] >= fix - rev
        prob += Pe.K_z(z) + pulp.lpSum(S.values()) <= B
        return prob, Tv, S, dom, z, y

    def add_w_vars(prob, Tv, dom, omega_use):
        """添加饱和辅助变量 w（ω>0 角色）。返回 W 字典。"""
        W = {}
        for r in roles:
            if omega_use.get(r, 0.0) > 0:
                W[r] = pulp.LpVariable(f'w_{r[0]}_{r[1]}', lowBound=0)
                prob += W[r] <= pulp.lpSum(Tv[e] for e in dom if (e[1], e[2]) == r)
                prob += W[r] <= h_map[r]
        return W

    def solve_milp(ci, v, method, lam):
        """六方法 MILP 求解。M5 两阶段。返回解 + native 状态。"""
        base_prob, Tv, S, dom, z, y = build_base_prob(ci, v)
        W = {}
        result = {'method': method, 'lam': lam, 'stages': []}

        if method == M_BASE:
            base_prob += pulp.lpSum(Qbar[e] * Tv[e] for e in dom)
            base_prob.solve(pulp.HiGHS(msg=0, gapRel=0, threads=1, timeLimit=60))
            ni = native_info(base_prob)
            result['stages'] = [{
                'stage': 'single', 'status': pulp.LpStatus[base_prob.status],
                'obj_milp': pulp.value(base_prob.objective),
                'native': ni, 'T': {e: int(round(Tv[e].value())) for e in dom},
                'S': {a: float(S[a].value()) for a in facs}, 'W': None}]
        elif method == M_PA:
            base_prob += pulp.lpSum(QPA[lam][e] * Tv[e] for e in dom)
            base_prob.solve(pulp.HiGHS(msg=0, gapRel=0, threads=1, timeLimit=60))
            ni = native_info(base_prob)
            result['stages'] = [{
                'stage': 'single', 'status': pulp.LpStatus[base_prob.status],
                'obj_milp': pulp.value(base_prob.objective),
                'native': ni, 'T': {e: int(round(Tv[e].value())) for e in dom},
                'S': {a: float(S[a].value()) for a in facs}, 'W': None}]
        elif method == M_TA_GLOBAL:
            W = add_w_vars(base_prob, Tv, dom, omega)
            base_prob += (pulp.lpSum(Qbar[e] * Tv[e] for e in dom)
                         + lam * pulp.lpSum(omega[r] * W[r] for r in W))
            base_prob.solve(pulp.HiGHS(msg=0, gapRel=0, threads=1, timeLimit=60))
            ni = native_info(base_prob)
            result['stages'] = [{
                'stage': 'single', 'status': pulp.LpStatus[base_prob.status],
                'obj_milp': pulp.value(base_prob.objective), 'native': ni,
                'T': {e: int(round(Tv[e].value())) for e in dom},
                'S': {a: float(S[a].value()) for a in facs},
                'W': {r: float(W[r].value()) for r in W}}]
        elif method == M_TA_REACH:
            W = add_w_vars(base_prob, Tv, dom, omega_reach)
            base_prob += (pulp.lpSum(Qbar[e] * Tv[e] for e in dom)
                         + lam * pulp.lpSum(omega_reach[r] * W[r] for r in W))
            base_prob.solve(pulp.HiGHS(msg=0, gapRel=0, threads=1, timeLimit=60))
            ni = native_info(base_prob)
            result['stages'] = [{
                'stage': 'single', 'status': pulp.LpStatus[base_prob.status],
                'obj_milp': pulp.value(base_prob.objective), 'native': ni,
                'T': {e: int(round(Tv[e].value())) for e in dom},
                'S': {a: float(S[a].value()) for a in facs},
                'W': {r: float(W[r].value()) for r in W}}]
        elif method == M_TARGET_ONLY:
            W = add_w_vars(base_prob, Tv, dom, omega)
            base_prob += pulp.lpSum(omega[r] * W[r] for r in W)
            base_prob.solve(pulp.HiGHS(msg=0, gapRel=0, threads=1, timeLimit=60))
            ni = native_info(base_prob)
            result['stages'] = [{
                'stage': 'single', 'status': pulp.LpStatus[base_prob.status],
                'obj_milp': pulp.value(base_prob.objective), 'native': ni,
                'T': {e: int(round(Tv[e].value())) for e in dom},
                'S': {a: float(S[a].value()) for a in facs},
                'W': {r: float(W[r].value()) for r in W}}]
        elif method == M_TARGET_CONS:
            # ===== M5 两阶段词典序（原生 bound 报告）=====
            # Stage 1: max H(T) = Σω·w
            p1, Tv1, S1, dom1, z1, y1 = build_base_prob(ci, v)
            W1 = add_w_vars(p1, Tv1, dom1, omega)
            H_expr = pulp.lpSum(omega[r] * W1[r] for r in W1)
            p1 += H_expr
            p1.solve(pulp.HiGHS(msg=0, gapRel=0, threads=1, timeLimit=60))
            ni1 = native_info(p1)
            st1 = pulp.LpStatus[p1.status]
            H1_incumbent = pulp.value(p1.objective)
            H1_bound = ni1.get('bound')
            H1_gap = ni1.get('gap')
            stage1_rec = {
                'stage': 'stage1_max_H', 'status': st1, 'obj_milp': H1_incumbent,
                'native': ni1, 'T': {e: int(round(Tv1[e].value())) for e in dom1},
                'S': {a: float(S1[a].value()) for a in facs},
                'W': {r: float(W1[r].value()) for r in W1}}
            result['stages'].append(stage1_rec)

            # Stage 2: max ΣQ̄·T s.t. H(T)=H1* （仅在 bound closed 时精确固定）
            p2, Tv2, S2, dom2, z2, y2 = build_base_prob(ci, v)
            W2 = add_w_vars(p2, Tv2, dom2, omega)
            H_expr2 = pulp.lpSum(omega[r] * W2[r] for r in W2)
            stage2_rec = {'stage': 'stage2_max_baseQMA_s.t._H_eq_Hstar', 'native': None,
                          'obj_milp': None, 'T': None, 'S': None, 'W': None,
                          'certification': None}
            if st1 == 'Optimal' and H1_bound is not None and H1_gap is not None \
                    and H1_gap < 1e-9:
                # bound closed → 精确固定 H=H1*
                p2 += H_expr2 == H1_incumbent
                p2 += pulp.lpSum(Qbar[e] * Tv2[e] for e in dom2)
                p2.solve(pulp.HiGHS(msg=0, gapRel=0, threads=1, timeLimit=60))
                ni2 = native_info(p2)
                stage2_rec.update({
                    'status': pulp.LpStatus[p2.status],
                    'obj_milp': pulp.value(p2.objective), 'native': ni2,
                    'T': {e: int(round(Tv2[e].value())) for e in dom2},
                    'S': {a: float(S2[a].value()) for a in facs},
                    'W': {r: float(W2[r].value()) for r in W2},
                    'certification': 'BOUND_CLOSED_H_fixed_exact',
                    'H1_star': H1_incumbent, 'H1_bound': H1_bound, 'H1_gap': H1_gap})
            elif H1_incumbent is not None:
                # time-limit → 用 incumbent 下界约束，标注 bound-aware
                p2 += H_expr2 >= H1_incumbent - 1e-9
                p2 += pulp.lpSum(Qbar[e] * Tv2[e] for e in dom2)
                p2.solve(pulp.HiGHS(msg=0, gapRel=0, threads=1, timeLimit=60))
                ni2 = native_info(p2)
                stage2_rec.update({
                    'status': pulp.LpStatus[p2.status],
                    'obj_milp': pulp.value(p2.objective), 'native': ni2,
                    'T': {e: int(round(Tv2[e].value())) for e in dom2},
                    'S': {a: float(S2[a].value()) for a in facs},
                    'W': {r: float(W2[r].value()) for r in W2},
                    'certification': 'BOUND_AWARE_LEXICOGRAPHIC',
                    'H1_incumbent': H1_incumbent, 'H1_bound': H1_bound, 'H1_gap': H1_gap,
                    'note': ('Stage1 未 bound closed，Stage2 在 incumbent 下界约束上运行，'
                             '不声称精确 Target-constrained optimum')})
            else:
                stage2_rec.update({
                    'status': 'NOT_CERTIFIED', 'certification': 'NOT_CERTIFIED',
                    'H1_incumbent': H1_incumbent, 'H1_bound': H1_bound, 'H1_gap': H1_gap,
                    'note': 'Stage1 无 incumbent，无法构造 Stage2'})
            result['stages'].append(stage2_rec)
        return result

    # ---------- 逐 (combo, v, method, λ) 求解 + 对账 ----------
    OBJ_KEY = {
        M_BASE: lambda lam: 'BASE_QMA',
        M_PA: lambda lam: f'PA_QMA_lam{lam:g}',
        M_TA_GLOBAL: lambda lam: f'TA_SPA_GLOBAL_lam{lam:g}',
        M_TA_REACH: lambda lam: f'TA_SPA_REACH_lam{lam:g}',
        M_TARGET_ONLY: lambda lam: f'TARGET_ONLY_lam{lam:g}',
    }
    # M5 特殊：Stage1 对 H_global，Stage2 对 BASE_QMA（在 H=H1* 子集上）
    M5_STAGE1_KEY = 'H_global'
    M5_STAGE2_KEY = 'BASE_QMA_at_H_star'

    cmp_rows, sol_pack, all_pass = [], [], True
    for ci, (z, y) in enumerate(combos):
        for v in V_SECTIONS:
            feas = feas_map[(ci, v)]
            per = {}
            if not feas:
                # 空可行域：所有方法必须一致 INFEASIBLE
                for m in NO_LAM_METHODS + LAM_METHODS:
                    lams = ([0.0] if m in NO_LAM_METHODS
                            else ([None] if m == M_BASE else LAM_GRID))
                    if m == M_BASE:
                        lams = [None]
                    for lam in lams:
                        lam_use = lam if lam is not None else 0.0
                        r = solve_milp(ci, v, m, lam_use)
                        s0 = r['stages'][0]
                        cmp_rows.append({
                            'combo_id': ci, 'v': v, 'method': m, 'lam': lam,
                            'n_feasible': 0, 'exhaustive_best': None,
                            'milp_obj': s0.get('obj_milp'),
                            'milp_matches_enumeration': None,
                            'solution_in_argmax_set': None,
                            'solution_hard_constraints_ok': None,
                            'native_status': s0['native'].get('model_status'),
                            'native_objective': s0['native'].get('objective'),
                            'w_audit': None, 'stage': s0.get('stage')})
                        all_pass &= (s0['status'] == 'Infeasible')
                        per[f'{m}' + (f'@lam{lam:g}' if lam is not None else '')] = {
                            'infeasible_as_expected': s0['status'] == 'Infeasible',
                            'native': s0['native']}
                sol_pack.append({'run_id': RUN_ID, 'protocol': PROTOCOL,
                                 'combo_id': ci, 'z': z, 'y': y, 'v': v, 'methods': per})
                continue

            # 非空可行域
            for m in [M_BASE, M_PA, M_TA_GLOBAL, M_TA_REACH, M_TARGET_ONLY, M_TARGET_CONS]:
                lams = ([None] if m == M_BASE
                        else LAM_GRID if m in (M_PA, M_TA_GLOBAL, M_TA_REACH)
                        else [0.0])  # M_TARGET_ONLY / M_TARGET_CONS λ无关
                for lam in lams:
                    lam_use = lam if lam is not None else 0.0
                    r = solve_milp(ci, v, m, lam_use)

                    if m == M_TARGET_CONS:
                        # M5 两阶段分别对账
                        s1 = r['stages'][0]
                        s2 = r['stages'][1]
                        # Stage1: 对 H_global
                        key1 = M5_STAGE1_KEY
                        best1 = max(o[key1] for _, o in feas)
                        argm1 = {json.dumps({f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T.items()
                                             if t}, sort_keys=True)
                                  for T, o in feas if abs(o[key1] - best1) < 1e-12}
                        milp_obj1 = s1.get('obj_milp')
                        T1_sol = {e: t for e, t in (s1.get('T') or {}).items() if t}
                        o_re1, _, _ = objs(T1_sol, z, y)
                        obj_re1 = o_re1[key1]
                        ok1 = (best1 is not None and milp_obj1 is not None
                               and abs(milp_obj1 - best1) < 1e-9
                               and abs(obj_re1 - best1) < 1e-9
                               and json.dumps({f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T1_sol.items()
                                               if t}, sort_keys=True) in argm1)
                        hard_ok1 = feas_T(z, y, T1_sol, v)

                        # Stage2: 对 BASE_QMA 在 H=H1* 子集上
                        key2 = M5_STAGE2_KEY
                        best2 = max(o['BASE_QMA'] for T, o in feas
                                    if abs(o[key1] - best1) < 1e-12)
                        argm2 = {json.dumps({f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T.items()
                                             if t}, sort_keys=True)
                                  for T, o in feas
                                  if abs(o[key1] - best1) < 1e-12
                                  and abs(o['BASE_QMA'] - best2) < 1e-12}
                        milp_obj2 = s2.get('obj_milp')
                        T2_sol = {e: t for e, t in (s2.get('T') or {}).items() if t}
                        o_re2, _, _ = objs(T2_sol, z, y)
                        obj_re2 = o_re2['BASE_QMA']
                        # 检验 Stage2 解是否在 H=H1* 子集的 argmax 中
                        ok2 = (best2 is not None and milp_obj2 is not None
                               and abs(milp_obj2 - best2) < 1e-9
                               and abs(obj_re2 - best2) < 1e-9
                               and json.dumps({f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T2_sol.items()
                                               if t}, sort_keys=True) in argm2)
                        hard_ok2 = feas_T(z, y, T2_sol, v)
                        # H 约束满足检验
                        H_at_T2 = o_re2[key1]
                        h_constraint_ok = abs(H_at_T2 - best1) < 1e-9

                        cmp_rows.append({
                            'combo_id': ci, 'v': v, 'method': m, 'lam': lam,
                            'n_feasible': len(feas), 'stage': 'stage1_max_H',
                            'exhaustive_best': best1, 'milp_obj': milp_obj1,
                            'obj_recomputed_itemwise': obj_re1,
                            'milp_matches_enumeration': bool(ok1),
                            'solution_in_argmax_set': bool(ok1),
                            'solution_hard_constraints_ok': bool(hard_ok1),
                            'native_status': s1['native'].get('model_status'),
                            'native_objective': s1['native'].get('objective'),
                            'native_bound': s1['native'].get('bound'),
                            'native_gap': s1['native'].get('gap'),
                            'w_audit': None, 'H1_star': best1,
                            'certification': s2.get('certification')})
                        cmp_rows.append({
                            'combo_id': ci, 'v': v, 'method': m, 'lam': lam,
                            'n_feasible': len(feas), 'stage': 'stage2_max_baseQMA',
                            'exhaustive_best': best2, 'milp_obj': milp_obj2,
                            'obj_recomputed_itemwise': obj_re2,
                            'milp_matches_enumeration': bool(ok2),
                            'solution_in_argmax_set': bool(ok2),
                            'solution_hard_constraints_ok': bool(hard_ok2),
                            'native_status': (s2.get('native') or {}).get('model_status'),
                            'native_objective': (s2.get('native') or {}).get('objective'),
                            'native_bound': (s2.get('native') or {}).get('bound'),
                            'native_gap': (s2.get('native') or {}).get('gap'),
                            'h_constraint_H_eq_Hstar': bool(h_constraint_ok),
                            'w_audit': None, 'H1_star': best1,
                            'certification': s2.get('certification')})
                        all_pass &= bool(ok1 and ok2 and hard_ok1 and hard_ok2
                                         and h_constraint_ok)
                        per[f'{m}__stage1'] = {
                            'T': {f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T1_sol.items()},
                            'obj_milp': milp_obj1, 'obj_itemwise': obj_re1,
                            'in_argmax_set': bool(ok1), 'native': s1['native']}
                        per[f'{m}__stage2'] = {
                            'T': {f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T2_sol.items()},
                            'obj_milp': milp_obj2, 'obj_itemwise': obj_re2,
                            'in_argmax_set': bool(ok2), 'native': s2.get('native'),
                            'certification': s2.get('certification')}
                    else:
                        # M1/M2/M3/M4/M6 单阶段对账
                        key = OBJ_KEY[m](lam) if lam is not None else 'BASE_QMA'
                        best = max(o[key] for _, o in feas)
                        argm = {json.dumps({f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T.items()
                                           if t}, sort_keys=True)
                                for T, o in feas if abs(o[key] - best) < 1e-12}
                        s0 = r['stages'][0]
                        milp_obj = s0.get('obj_milp')
                        T_sol = {e: t for e, t in (s0.get('T') or {}).items() if t}
                        o_re, N_re, w_re = objs(T_sol, z, y)
                        obj_re = o_re[key]
                        # w 逐项审计
                        w_chk = None
                        if s0.get('W'):
                            omega_use = (omega if m in (M_TA_GLOBAL, M_TARGET_ONLY)
                                         else omega_reach)
                            eff_lam = lam if lam is not None else 0.0
                            strict = (m == M_TARGET_ONLY) or eff_lam > 0
                            w_chk = {
                                'max_abs_diff_pos_weight': max(
                                    [abs(s0['W'].get(rr, 0.0) - w_re[rr])
                                     for rr in roles if omega_use.get(rr, 0.0) > 0]
                                    or [0.0]),
                                'all_le_bound_all_roles': all(
                                    s0['W'].get(rr, 0.0) <= w_re[rr] + 1e-9 for rr in roles),
                                'strict_required': bool(strict),
                                'omega_source': ('global' if m in (M_TA_GLOBAL, M_TARGET_ONLY)
                                                 else 'reachable'),
                                'note': ('w 入目标(λ>0 或 target-only)⇒ w=min(N,h) 逐项严格；'
                                         'λ=0 时 w 不入目标、值不定，仅须 0≤w≤min(N,h)')}
                        ok = (best is not None and milp_obj is not None
                              and abs(milp_obj - best) < 1e-9
                              and abs(obj_re - best) < 1e-9
                              and json.dumps({f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T_sol.items()
                                              if t}, sort_keys=True) in argm)
                        hard_ok = feas_T(z, y, T_sol, v)
                        cmp_rows.append({
                            'combo_id': ci, 'v': v, 'method': m, 'lam': lam,
                            'n_feasible': len(feas), 'stage': 'single',
                            'exhaustive_best': best, 'milp_obj': milp_obj,
                            'obj_recomputed_itemwise': obj_re,
                            'milp_matches_enumeration': bool(ok),
                            'solution_in_argmax_set': bool(ok),
                            'solution_hard_constraints_ok': bool(hard_ok),
                            'native_status': s0['native'].get('model_status'),
                            'native_objective': s0['native'].get('objective'),
                            'native_bound': s0['native'].get('bound'),
                            'native_gap': s0['native'].get('gap'),
                            'w_audit': w_chk, 'certification': None})
                        all_pass &= bool(ok and hard_ok and s0['status'] == 'Optimal')
                        if w_chk:
                            all_pass &= (w_chk['all_le_bound_all_roles']
                                         and (w_chk['max_abs_diff_pos_weight'] < 1e-9
                                              if w_chk['strict_required'] else True))
                        per[f'{m}' + (f'@lam{lam:g}' if lam is not None else '')] = {
                            'T': {f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T_sol.items()},
                            'S': s0.get('S'), 'w': ({f'{rr[0]}|{rr[1]}': vv
                                                     for rr, vv in s0['W'].items()}
                                                    if s0.get('W') else None),
                            'obj_milp': milp_obj, 'obj_itemwise': obj_re,
                            'N': {f'{rr[0]}|{rr[1]}': vv for rr, vv in N_re.items()},
                            'w_star_itemwise': {f'{rr[0]}|{rr[1]}': vv
                                                for rr, vv in w_re.items()},
                            'argmax_set_size': len(argm), 'in_argmax_set': bool(ok),
                            'native': s0['native'], 'w_audit': w_chk,
                            'Psi_monthly': o_re['Psi_monthly'],
                            'Psi_annual_first_year': o_re['Psi_monthly'] * 12.0,
                            'budget_B_monthly': B,
                            'budget_slack_monthly': B - o_re['Psi_monthly']}
            sol_pack.append({'run_id': RUN_ID, 'protocol': PROTOCOL, 'combo_id': ci,
                             'z': z, 'y': y, 'v': v, 'methods': per})

    # ---------- C1 退化检验：λ=0 时 M3/M4 退化为 Base-QMA ----------
    c1_degen = []
    for ci in range(len(combos)):
        for v in V_SECTIONS:
            feas = feas_map[(ci, v)]
            base_rows = [r for r in cmp_rows if r['combo_id'] == ci and r['v'] == v
                         and r['method'] == M_BASE]
            if not feas or base_rows[0]['exhaustive_best'] is None:
                continue

            def keys_of(key, feas=feas):
                bst = max(o[key] for _, o in feas)
                return {json.dumps({f'{e[0]}|{e[1]}|{e[2]}': t for e, t in T.items() if t},
                                   sort_keys=True)
                        for T, o in feas if abs(o[key] - bst) < 1e-12}
            kb = keys_of('BASE_QMA')
            # M3 λ=0
            ident_global = all(abs(o['TA_SPA_GLOBAL_lam0'] - o['BASE_QMA']) < 1e-12
                               for _, o in feas)
            # M4 λ=0
            ident_reach = all(abs(o['TA_SPA_REACH_lam0'] - o['BASE_QMA']) < 1e-12
                              for _, o in feas)
            for m, key, ident in [(M_TA_GLOBAL, 'TA_SPA_GLOBAL_lam0', ident_global),
                                  (M_TA_REACH, 'TA_SPA_REACH_lam0', ident_reach)]:
                r0 = [r for r in cmp_rows if r['combo_id'] == ci and r['v'] == v
                      and r['method'] == m and r['lam'] == 0.0][0]
                rb = base_rows[0]
                same_obj = abs(r0['exhaustive_best'] - rb['exhaustive_best']) < 1e-12
                sets_eq = bool(keys_of(key) == kb)
                c1_degen.append({'combo_id': ci, 'v': v, 'method': m,
                                 'lam0_best': r0['exhaustive_best'],
                                 'base_best': rb['exhaustive_best'],
                                 'objective_equal': bool(same_obj),
                                 'pointwise_identity_all_feasible_T': bool(ident),
                                 'argmax_sets_identical': sets_eq,
                                 'solution_in_base_argmax': bool(r0['solution_in_argmax_set'])})
                all_pass &= same_obj and r0['solution_in_argmax_set'] and ident and sets_eq

    # ---------- M4 reachable 不改可行域检验 ----------
    # 对每个 (combo,v)，M4 MILP 解的 hard_constraints_ok 必须为 True（与 Base 同域）
    m4_domain = all(r['solution_hard_constraints_ok']
                    for r in cmp_rows if r['method'] == M_TA_REACH
                    and r['n_feasible'] > 0)

    # ---------- M5 词典序不改可行域检验 ----------
    m5_domain = all(r['solution_hard_constraints_ok']
                    for r in cmp_rows if r['method'] == M_TARGET_CONS
                    and r['n_feasible'] > 0)

    # ---------- M5 Stage2 H 约束满足检验 ----------
    m5_h_constraint = all(r.get('h_constraint_H_eq_Hstar', True)
                          for r in cmp_rows if r['method'] == M_TARGET_CONS
                          and r.get('stage') == 'stage2_max_baseQMA'
                          and r['n_feasible'] > 0)

    # ---------- 乘子 a 无关性（示例） ----------
    mult_example = {}
    for lam in LAM_GRID:
        for r in roles:
            qs = [QPA[lam][e] / Qbar[e] for e in edges
                  if e[1] == r[0] and e[2] == r[1] and Qbar[e] > 1e-15]
            mult_example[f'lam{lam:g}|{r[0]}|{r[1]}'] = {
                'n_edges': len(qs),
                'multiplier_spread': float(max(qs) - min(qs)) if qs else None}

    # ---------- 每方法指标记录（C1.9 要求） ----------
    method_metrics = {}
    for ci, (z, y) in enumerate(combos):
        for v in V_SECTIONS:
            feas = feas_map[(ci, v)]
            if not feas:
                continue
            for m in [M_BASE, M_PA, M_TA_GLOBAL, M_TA_REACH, M_TARGET_ONLY, M_TARGET_CONS]:
                lams = ([None] if m == M_BASE
                        else LAM_GRID if m in (M_PA, M_TA_GLOBAL, M_TA_REACH)
                        else [0.0])
                for lam in lams:
                    if m == M_TARGET_CONS:
                        # M5: 取 Stage2 解
                        s_rows = [r for r in cmp_rows if r['combo_id'] == ci
                                  and r['v'] == v and r['method'] == m]
                        s2_row = [r for r in s_rows if r.get('stage') == 'stage2_max_baseQMA']
                        if not s2_row:
                            continue
                        s1_row = [r for r in s_rows if r.get('stage') == 'stage1_max_H']
                        best1 = s1_row[0]['exhaustive_best'] if s1_row else None
                        best2 = s2_row[0]['exhaustive_best']
                        mk = f'{m}__combo{ci}_v{v}'
                        method_metrics[mk] = {
                            'method': m, 'combo_id': ci, 'v': v, 'lam': None,
                            'H_T': best1, 'base_qma_score': best2,
                            'combined_objective': f'lex({best1},{best2})',
                            'policy_reward': best1,
                            'target_gap_Gh': None, 'note': 'M5 词典序对'}
                    elif m == M_TARGET_ONLY:
                        r = [r for r in cmp_rows if r['combo_id'] == ci
                             and r['v'] == v and r['method'] == m][0]
                        mk = f'{m}__combo{ci}_v{v}'
                        # G_h = H_upper - H_T
                        H_up = sum(omega[rr] * h_map[rr] for rr in roles)
                        method_metrics[mk] = {
                            'method': m, 'combo_id': ci, 'v': v, 'lam': None,
                            'H_T': r['exhaustive_best'],
                            'base_qma_score': None,
                            'combined_objective': r['exhaustive_best'],
                            'policy_reward': r['exhaustive_best'],
                            'target_gap_Gh': H_up - r['exhaustive_best']}
                    else:
                        r = [r for r in cmp_rows if r['combo_id'] == ci
                             and r['v'] == v and r['method'] == m
                             and r['lam'] == lam]
                        if not r:
                            continue
                        r = r[0]
                        mk = f'{m}__combo{ci}_v{v}' + (f'__lam{lam:g}' if lam is not None else '')
                        H_up = sum(omega[rr] * h_map[rr] for rr in roles)
                        # 从穷举最优解取指标
                        best = r['exhaustive_best']
                        # 基础QMA = best - λ*H (for M3/M4)
                        if m in (M_TA_GLOBAL, M_TA_REACH) and lam is not None:
                            omega_use = omega if m == M_TA_GLOBAL else omega_reach
                            H_best = max(sum(omega_use[rr] * min(
                                sum(T.get((a, rr[0], rr[1]), 0) for a in facs), h_map[rr])
                                for rr in roles) for T, o in feas)
                            base_qma_at_best = best - lam * H_best
                            method_metrics[mk] = {
                                'method': m, 'combo_id': ci, 'v': v, 'lam': lam,
                                'H_T': H_best, 'base_qma_score': base_qma_at_best,
                                'combined_objective': best, 'policy_reward': H_best,
                                'target_gap_Gh': H_up - H_best}
                        else:
                            method_metrics[mk] = {
                                'method': m, 'combo_id': ci, 'v': v, 'lam': lam,
                                'H_T': None, 'base_qma_score': best,
                                'combined_objective': best, 'policy_reward': None,
                                'target_gap_Gh': None}

    # ---------- 汇总审计 ----------
    n_enum = len(enum_rows)
    audit = {
        'run_id': RUN_ID, 'protocol': PROTOCOL, 'stage': 'C/C1',
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'authorization': ('GPT6.1 批准 2026-10-10：阶段C 第三层方法贡献受控验证。'
                          'C1=Example A 全枚举核验 M1-M6；C1 全 PASS 才进入 C2。'
                          '禁止结果导向调参、混名、回填 Policy34、将 time-limit 解称最优'),
        'instance': {'name': 'Example A (audited P0b, 复用阶段A)',
                     'xlsx': str(XLSX), 'xlsx_sha256': sha(XLSX),
                     'config': cfg, 'run_meta_source': str(P0RUN_DIR / 'run_meta.json'),
                     'facilities': facs, 'communities': coms,
                     'edges': [list(e) for e in edges],
                     'T_ref': {f'{a}|{j}|{k}': t for (a, j, k), t in T_ref.items()},
                     'n_legal_zy_combos': len(combos), 'v_sections': V_SECTIONS},
        'frozen_params': {
            'h_main_rho': 0.50, 'h': {f'{r[0]}|{r[1]}': h_map[r] for r in roles},
            'pi_unnormalized': {f'{r[0]}|{r[1]}': pi_sig[r] for r in roles},
            'omega_global': {f'{r[0]}|{r[1]}': omega[r] for r in roles},
            'omega_reachable': {f'{r[0]}|{r[1]}': omega_reach[r] for r in roles},
            'reachable_roles': [list(r) for r in reachable_roles],
            'unreachable_roles': [list(r) for r in unreachable_roles],
            'pi_sum_global': pi_sum, 'pi_sum_reachable': pi_sum_reach,
            'sum_omega_global': sum(omega.values()),
            'sum_omega_reachable': sum(omega_reach[r] for r in reachable_roles),
            'max_omega_global': max(omega.values()),
            'min_omega_global': min(omega.values()),
            'max_omega_reachable': max(omega_reach[r] for r in reachable_roles),
            'min_omega_reachable': min(omega_reach[r] for r in reachable_roles),
            'lam_grid': LAM_GRID, 'rho_grid_reported_full': RHO_GRID,
            'budget_B_monthly': B, 'delta0_QMA': delta0,
            'T_ref_note': '冻结参考分配 T0（load_params 返回，全零 stock 参考 → R=1）',
            'M4_note': ('ω^reach 在 R={(j,k):∃a,χ_ajk=1} 上重新归一化；'
                        '不可达角色 ω^reach=0。若 R=所有角色则 M4=M3（C1 核验机制正确性，'
                        '差异在 C2 柳州实例体现）')},
        'method_definitions': {
            'M1_BASE_QMA': 'max ΣQ̄·T',
            'M2_PA_QMA': 'max ΣQ^PA(λ)·T，Q^PA=χ·Q̄·(1+λπ)/(1+λ)',
            'M3_TA_SPA_GLOBAL': 'max {ΣQ̄·T + λΣω·w}，ω=π/Σπ（全角色归一化）',
            'M4_TA_SPA_REACHABLE': 'max {ΣQ̄·T + λΣω^reach·w}，ω^reach=π/Σ_{R}π（R=可达角色）',
            'M5_TARGET_CONSTRAINED': ('两阶段词典序：Stage1 max H(T)=Σω·w → '
                                      'Stage2 max ΣQ̄·T s.t. H(T)=H1*（bound closed时精确固定）'),
            'M6_TARGET_ONLY': 'max Σω·w（λ无关，诊断性，不作优越基准）'},
        'hashes': {'code_self_sha256': sha(Path(__file__)),
                   'model_io_sha256': sha(ROOT / 'src' / 'model_io.py'),
                   'solvers_sha256': sha(ROOT / 'src' / 'solvers.py')},
        'environment': {'python': sys.version.split()[0], 'pulp': pulp.__version__,
                        'solver': 'HiGHS (threads=1, gapRel=0, timeLimit=60s)'},
        'checks': {
            'C1.1_identical_hard_constraints': {
                'pass': all(r['solution_hard_constraints_ok']
                           for r in cmp_rows if r['n_feasible'] > 0),
                'evidence': ('所有方法共用同一基约束生成块（build_base_prob）；'
                             '每个 MILP 解通过独立 audited 可行域复核 '
                             '(solution_hard_constraints_ok)；穷举域与 MILP 域同一')},
            'C1.2_w_equals_min_N_h_itemwise': {
                'pass': all(
                    (r['w_audit'] is None
                     or (r['w_audit']['all_le_bound_all_roles']
                         and (r['w_audit']['max_abs_diff_pos_weight'] < 1e-9
                              if r['w_audit']['strict_required'] else True)))
                    for r in cmp_rows),
                'note': ('M3/M4 λ>0 与 M6：w=min(N,h) 逐项严格成立（ω>0）；'
                         'λ=0 时 w 不入目标值不定，仅验证 0≤w≤min(N,h)')},
            'C1.3_M5_two_stages_match_enumeration': {
                'pass': all(bool(r['milp_matches_enumeration'] and r['solution_in_argmax_set'])
                            for r in cmp_rows if r['method'] == M_TARGET_CONS
                            and r['n_feasible'] > 0),
                'note': ('M5 Stage1 MILP H1* = 穷举 max H_global；'
                         'Stage2 MILP base_qma = 穷举 max ΣQ̄·T 在 {H=H1*} 子集上')},
            'C1.4_lambda0_degenerates_to_base': {
                'items': c1_degen,
                'pass': all(x['objective_equal'] and x['solution_in_base_argmax']
                            and x['pointwise_identity_all_feasible_T']
                            and x['argmax_sets_identical'] for x in c1_degen)},
            'C1.5_M4_only_changes_weights_not_domain': {
                'pass': bool(m4_domain),
                'evidence': 'M4 所有 MILP 解 solution_hard_constraints_ok=True'},
            'C1.6_M5_only_changes_lex_not_domain': {
                'pass': bool(m5_domain and m5_h_constraint),
                'evidence': ('M5 所有 Stage2 解 hard_constraints_ok=True 且 '
                             'H(T)=H1* 约束满足')},
            'C1.7_independent_constraint_audit': {
                'pass': all(r['solution_hard_constraints_ok']
                            for r in cmp_rows if r['n_feasible'] > 0),
                'verifier': 'solvers.phys_feasible_T + solvers.psi 财政 + ΣT=v'},
            'C1.8_objectives_not_cross_compared': {
                'pass': True,
                'note': '不同方法 objective 使用各自定义，不直接比较异尺度 objective；'
                        '比较通过共同外部指标 H_T/G_h/base_qma_score'},
            'C1.9_method_metrics_recorded': method_metrics,
            'C_saturation_flat_beyond_h': {
                'pairs_scanned': c5_scanned, 'violations': c5_viol,
                'pass': not c5_viol},
            'multiplier_common_within_role_recheck': mult_example,
        },
        'n_enumerated_assignments': n_enum,
        'n_milp_solves': len(cmp_rows),
        'ALL_PASS': None,
        'wall_time_s': None,
    }
    audit['ALL_PASS'] = bool(
        all_pass
        and audit['checks']['C1.1_identical_hard_constraints']['pass']
        and audit['checks']['C1.2_w_equals_min_N_h_itemwise']['pass']
        and audit['checks']['C1.3_M5_two_stages_match_enumeration']['pass']
        and audit['checks']['C1.4_lambda0_degenerates_to_base']['pass']
        and audit['checks']['C1.5_M4_only_changes_weights_not_domain']['pass']
        and audit['checks']['C1.6_M5_only_changes_lex_not_domain']['pass']
        and audit['checks']['C1.7_independent_constraint_audit']['pass']
        and audit['checks']['C_saturation_flat_beyond_h']['pass'])
    audit['wall_time_s'] = round(time.time() - t0, 1)

    # ---------- 输出 ----------
    (OUT / 'stage_C1_audit.json').write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    (OUT / 'stage_C1_config_frozen.json').write_text(
        json.dumps({'run_id': RUN_ID, 'protocol': PROTOCOL, 'stage': 'C/C1',
                    'frozen_params': audit['frozen_params'],
                    'method_definitions': audit['method_definitions'],
                    'hashes': audit['hashes'], 'environment': audit['environment'],
                    'instance': audit['instance']}, ensure_ascii=False, indent=2,
                   default=str), encoding='utf-8')
    pd.DataFrame(cmp_rows).to_csv(OUT / 'stage_C1_milp_vs_enum.csv', index=False,
                                  encoding='utf-8-sig')
    for s in sol_pack:
        (OUT / 'stage_C1_solutions' / f"combo{s['combo_id']}__v{s['v']}.json").write_text(
            json.dumps(s, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    (OUT / 'README_STAGE_C1.md').write_text(f"""# TA-SPA-QMA 阶段C / C1 报告（{RUN_ID}）

- 协议：{PROTOCOL}；阶段：C/C1（第三层方法贡献受控验证 · 小规模机制核验）
- 授权：GPT6.1 批准 2026-10-10（预注册、独立、可撤回；禁止结果导向调参）
- 实例：Example A（复用阶段A已审计 P0b，禁止新建/修改）
- 六方法：M1 Base-QMA / M2 Original PA-QMA / M3 TA-SPA-global / M4 TA-SPA-reachable /
  M5 Target-constrained QMA（两阶段词典序）/ M6 Target-only diagnostic
- 规模：{len(combos)} 个合法 (z,y) × v∈{{5,10}}，穷举 {n_enum} 个可行分配，
  MILP {len(cmp_rows)} 次求解（HiGHS threads=1, gapRel=0, ≤60s）
- M4 reachable 角色：{len(reachable_roles)} 个；不可达角色：{len(unreachable_roles)} 个
- M5 两阶段：Stage1 max H(T) → Stage2 max ΣQ̄·T s.t. H=H1*（bound closed 时精确固定）
- **ALL_PASS = {audit['ALL_PASS']}**（C1.1–C1.9 + 饱和性 + 乘子无关性，明细见 stage_C1_audit.json）
- 停止：C1 全 PASS → 可进入 C2（柳州两配置）；C1 失败即停止；
  不回填 Policy34 正文；不修改阶段A/B结果。
""", encoding='utf-8')
    print(f'ALL_PASS={audit["ALL_PASS"]}  enum={n_enum}  milp={len(cmp_rows)}  '
          f'C5_pairs={c5_scanned}  wall={audit["wall_time_s"]}s')
    print('输出 ->', OUT)


if __name__ == '__main__':
    main()
