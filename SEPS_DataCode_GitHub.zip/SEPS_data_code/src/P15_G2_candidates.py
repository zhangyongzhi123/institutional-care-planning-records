# -*- coding: utf-8 -*-
"""Policy15 G2: 新建候选点池 + 加权最大覆盖贪心预筛 + 新点路由调用量预估。

要点（Policy15 §5）:
  - 地点池：1,147 社区按行政区划代码前 9 位（乡镇级）分组，取成员坐标中位数为代表点；
    全部标 PLANNING_PROXY（非实测地块、道路可接入性未验证），坐标 CGCS2000。
  - 共址（<1km）只打标不合并，人工核查留待作者确认后。
  - 贪心预筛：h_cjk = 候选点 c 到社区 j 的代理时间 ≤ τ(30min) 且 R0_jk>0；
    w_jk = 1（默认，弱势权重仅作预设政策情景，本阶段不启用）；
    每步选边际增益最大点，同分按 site_id 升序；M=10/20/40 嵌套集合。
    1−1/e 保证仅对本次预筛成立，不得延伸至后续容量—参与—预算联合分配。
  - 代理时间 = 大圆距离 × 1.25 ÷ 40 km/h（PROXY，不得拼进主实验冒充真实驾车时间）。
  - 路由：本阶段禁止实际调用高德 API，只出调用量预估（routing_estimate.md），
    待作者确认配额与 key 后执行；断连单列，不静默填 0；key 不入交付物。

输入: runs/P15_G1/residual_R0_<set>.xlsx（R⁰ 冻结）
输出（runs/P15_G2/）: candidate_sites.xlsx / greedy_trajectory_<set>.csv
                      / P15_G2_summary.json / routing_estimate.md
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from run_E1_full import CONFIG  # noqa: E402  # tau=30.0

RAW = ROOT / 'data' / 'raw' / 'eldercare_inputs.xlsx'
G1 = ROOT / 'runs' / 'P15_G1'
OUT = ROOT / 'runs' / 'P15_G2'
SETS = {'upround': 'upround（主口径）', 'total_preserving': 'total_preserving（敏感性预览）'}
M_GRID = (10, 20, 40)
TAU = CONFIG['tau']
DETOUR, SPEED_KMH = 1.25, 40.0
R_EARTH = 6371.0088


def haversine_km(lon1, lat1, lon2, lat2):
    lo1, la1, lo2, la2 = map(np.radians, [lon1, lat1, lon2, lat2])
    h = np.sin((la2 - la1) / 2) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((lo2 - lo1) / 2) ** 2
    return 2 * R_EARTH * np.arcsin(np.sqrt(h))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    xl = pd.ExcelFile(RAW)
    cm = xl.parse('communities', dtype={'community_id': str})
    fac = xl.parse('facilities', dtype={'facility_id': str})

    # ---------- 地点池：乡镇代表点 ----------
    cm['tk'] = cm.community_id.str[:9]
    grp = cm.groupby('tk')
    sites = grp.agg(lon=('lon', 'median'), lat=('lat', 'median'),
                    district_name=('district_name', 'first'),
                    n_member=('community_id', 'size'),
                    members=('community_id', lambda s: ';'.join(sorted(s))))
    sites = sites.reset_index().rename(columns={'tk': 'township_code'})
    sites['site_id'] = 'CAND_' + sites.township_code
    sites = sites.sort_values('site_id').reset_index(drop=True)
    print(f'候选池: {len(sites)} 个乡镇级代表点（成员社区 {len(cm)}）')

    # ---------- 共址标记（<1km，只标不合并） ----------
    cl_fac, cl_cand = [], []
    S = sites[['lon', 'lat']].values                     # (n_sites, 2)
    F_arr = fac[['lon', 'lat']].values                    # (n_fac, 2)
    # 广播: S[:,0:1]  (n,1)  F[:,0][None,:]  (1,m)  →  (n,m)
    d_sf = haversine_km(S[:, 0:1], S[:, 1:2],
                        F_arr[:, 0][None, :], F_arr[:, 1][None, :])
    for i in range(len(sites)):
        hits = fac.facility_id.values[d_sf[i] < 1.0]
        cl_fac.append(';'.join(hits))
    d_ss = haversine_km(S[:, 0:1], S[:, 1:2],
                        S[:, 0][None, :], S[:, 1][None, :])
    for i in range(len(sites)):
        hits = sites.site_id.values[(d_ss[i] < 1.0) & (np.arange(len(sites)) != i)]
        cl_cand.append(';'.join(hits))
    sites['colocated_existing_facilities'] = cl_fac
    sites['colocated_candidate_sites'] = cl_cand

    # ---------- 代理时间矩阵（候选 × 社区） ----------
    C = cm[['lon', 'lat']].values                         # (1147, 2)
    dmat = haversine_km(S[:, 0:1], S[:, 1:2],
                        C[:, 0][None, :], C[:, 1][None, :])  # (117, 1147) km
    tmat = dmat * DETOUR / SPEED_KMH * 60.0          # 分钟，PROXY
    within = tmat <= TAU                              # 服务范围规则 τ=30min

    # ---------- 贪心（两套 R⁰） ----------
    traj_paths, summary = {}, {}
    for set_name in SETS:
        res = pd.read_excel(G1 / f'residual_R0_{set_name}.xlsx',
                            sheet_name='residual_by_jk',
                            dtype={'community_id': str})
        res = res[res.R0 > 0].reset_index(drop=True)
        jmap = {j: i for i, j in enumerate(res.community_id.unique())}
        pair_ok = np.array([jmap[j] for j in res.community_id])
        cov = np.zeros((len(sites), len(res)), dtype=bool)      # 候选×残缺(j,k)对
        for ci in range(len(sites)):
            cov[ci, :] = within[ci, pair_ok]
        w_beds = res.R0.values.astype(float)
        n_pairs = len(res)
        uncovered = np.ones(n_pairs, dtype=bool)
        selected, rows = [], []
        cum_pairs = cum_beds = 0.0
        while len(selected) < M_GRID[-1]:
            gain_p = cov[:, uncovered].sum(axis=1) if uncovered.any() else np.zeros(len(sites))
            gain_b = cov[:, uncovered] @ w_beds[uncovered] if uncovered.any() else np.zeros(len(sites))
            if selected:
                gain_p[selected] = -1
            if gain_p.max() <= 0:
                break
            best = int(np.argmax(gain_p))   # 同分取最小索引 == site_id 升序（sites 已排序）
            newly = cov[best] & uncovered
            mp, mb = float(newly.sum()), float(w_beds[newly].sum())
            cum_pairs += mp
            cum_beds += mb
            uncovered &= ~newly
            selected.append(best)
            rows.append({'step': len(selected), 'site_id': sites.site_id[best],
                         'district_name': sites.district_name[best],
                         'marginal_pairs': int(mp), 'cum_pairs': int(cum_pairs),
                         'marginal_R0_beds': round(mb, 1),
                         'cum_R0_beds': round(cum_beds, 1),
                         'pool_remaining': int(len(sites) - len(selected)),
                         'rule': 'w_jk=1; tie-break=site_id asc; PROXY travel time'})
        tdf = pd.DataFrame(rows)
        tdf.to_csv(OUT / f'greedy_trajectory_{set_name}.csv', index=False, encoding='utf-8-sig')
        traj_paths[set_name] = f'greedy_trajectory_{set_name}.csv'

        msum = []
        for M in M_GRID:
            sel = selected[:min(M, len(selected))]
            if not sel:
                continue
            cc = cov[sel].any(axis=0)
            msum.append({'M': M, 'n_selected': len(sel),
                         'covered_pairs': int(cc.sum()), 'pair_coverage_pct': round(100 * cc.sum() / n_pairs, 2),
                         'covered_R0_beds': round(float(w_beds[cc].sum()), 1),
                         'bed_coverage_pct_of_R0': round(100 * float(w_beds[cc].sum()) / w_beds.sum(), 2),
                         'site_ids': ';'.join(sites.site_id[sel])})
        # 遗漏角色：任何候选点都在 τ 外的残缺对（结构性不可达，非选择所致）
        struct = ~cov.any(axis=0)
        summary[set_name] = {
            'R0_pairs_total': int(n_pairs), 'R0_beds_total': round(float(w_beds.sum()), 1),
            'greedy_steps': int(len(selected)),
            'M_sets': msum,
            'structurally_uncovered_pairs': int(struct.sum()),
            'structurally_uncovered_R0_beds': round(float(w_beds[struct].sum()), 1),
            'note': '遗漏=池内无任何候选点在 τ 内（结构性）；其余为 M 限制所致',
            'proxy_disclaimer': '代理时间=大圆×1.25÷40km/h（PROXY），正式筛选须高德真实路由',
            'greedy_guarantee': '1−1/e 仅对此固定覆盖预筛成立，不延伸至联合分配',
        }
        print(f'  [{set_name}] 贪心 {len(selected)} 步; M=10/20/40 对覆盖: '
              f"{[m['pair_coverage_pct'] for m in msum[:3]]}%")

    # ---------- candidate_sites.xlsx ----------
    out_sites = sites.copy()
    out_sites['coord_system'] = 'CGCS2000'
    out_sites['source'] = 'estimated_roles_1147 社区坐标按乡镇(代码前9位)分组中位数'
    out_sites['site_type'] = 'PLANNING_PROXY'
    out_sites['is_measured_site'] = 0
    out_sites['road_access_status'] = 'not_verified_phase1'
    out_sites['snap_status'] = 'not_performed_phase1'
    out_sites['snap_distance_m'] = np.nan
    out_sites['snap_original_lon'] = out_sites.lon
    out_sites['snap_original_lat'] = out_sites.lat
    out_sites['exclusion_reason'] = ''
    cols = ['site_id', 'township_code', 'lon', 'lat', 'coord_system', 'district_name',
            'n_member', 'members', 'source', 'site_type', 'is_measured_site',
            'road_access_status', 'snap_status', 'snap_distance_m',
            'snap_original_lon', 'snap_original_lat',
            'colocated_existing_facilities', 'colocated_candidate_sites', 'exclusion_reason']
    out_sites = out_sites[cols]
    with pd.ExcelWriter(OUT / 'candidate_sites.xlsx', engine='openpyxl') as w:
        out_sites.to_excel(w, sheet_name='candidate_sites', index=False)
        pd.DataFrame([{'item': 'pool_size', 'value': len(sites)},
                      {'item': 'tau_min', 'value': TAU},
                      {'item': 'proxy_rule', 'value': 'great-circle × 1.25 ÷ 40 km/h (PROXY)'},
                      {'item': 'weight', 'value': 'w_jk=1 (default; 弱势权重仅作预设政策情景)'},
                      {'item': 'dedup_rule', 'value': '共址<1km只标记不合并（人工核查待作者确认）'},
                      {'item': 'api_calls_this_phase', 'value': 0},
                      {'item': 'api_policy', 'value': '本阶段禁止实际调用；先报量待作者确认'}]
                     ).to_excel(w, sheet_name='meta', index=False)
        for s in SETS:
            pd.DataFrame(summary[s]['M_sets']).to_excel(w, sheet_name=f'M_sets_{s}', index=False)

    # ---------- 路由调用量预估 ----------
    pool_n = len(sites)
    per_cand_pairs = len(cm)                       # 每候选点 × 1,147 社区
    per_cand_req = int(np.ceil(per_cand_pairs / 100))   # 高德批量 100 对/请求
    rt = f"""# routing_estimate.md — 新点路由调用量预估（先报量，未执行）

状态：**未调用任何 API**（Policy15 §5.2：执行前先回报，作者确认后再发起）。
高德 API key 不写入本交付物。

## 1. 调用量

每个候选点需对其 1,147 个社区各取一条驾车时间 OD（候选→社区），即
{per_cand_pairs:,} 对/点。沿用既有 128 机构抓取的批量模式（v3/distance 批量，
100 对/请求），每点 ≈ **{per_cand_req} 次请求**。

| 方案 | 新增 OD 对 | 请求次数（100对/次） |
|---|---|---|
| M=10（嵌套前 10） | {10*per_cand_pairs:,} | {10*per_cand_req} |
| M=20 | {20*per_cand_pairs:,} | {20*per_cand_req} |
| M=40 | {40*per_cand_pairs:,} | {40*per_cand_req} |
| 全池（{pool_n} 点，供宽池敏感性 G5-D） | {pool_n*per_cand_pairs:,} | {pool_n*per_cand_req} |

嵌套集按贪心顺序取前 M，路由可只对 M=40 的点执行（480 请求）即覆盖全部三档；
宽池敏感性需另路由其余 {pool_n-40} 点（{(pool_n-40)*per_cand_req} 请求）。

## 2. 配额与耗时（以作者账号实际配额为准，此处不臆测具体数值）

- 需作者提供：key 的 QPS 与日配额、并发上限；
- 参考耗时：按既有 146,816 对抓取速率，480 请求 ≈ 单批分钟级；全池 ≈ 十几分钟级；
- 分批方案：每批 ≤500 请求，批间落盘 checkpoint（断点续跑）；
- 缓存：既有 128 机构 × 1,147 社区 = 146,816 对已抓取（2026-09-26 快照），
  **不重复抓取**；新点抓取后另存快照（source/snapshot 版本/时间戳）。

## 3. 失败与质量规则（执行时生效）

- 断连/超限单列 status='failed_*'，**不得静默填 0**，不回退大圆值冒充驾车时间；
- 返回时间 > τ 的边保留记录（用于服务范围判定）；
- key、授权令牌不进入任何结果文件；请求参数与快照版本入 provenance。

## 4. 待作者确认项

1. 是否同意按 M=40（480 请求）先路由嵌套集；
2. 提供可用 key 及配额信息；
3. 候选点坐标是否需先做道路吸附（当前 phase1 未吸附，标 PLANNING_PROXY）。
"""
    (OUT / 'routing_estimate.md').write_text(rt, encoding='utf-8')

    (OUT / 'P15_G2_summary.json').write_text(json.dumps(
        {'script': Path(__file__).name, 'run_at': pd.Timestamp.now().isoformat(),
         'pool_size': pool_n, 'tau_min': TAU,
         'proxy_rule': f'haversine×{DETOUR}÷{SPEED_KMH}km/h×60 (PROXY)',
         'travel_source': 'PROXY — phase1 未调用 API',
         'sets': summary,
         'files': {'candidate_sites': 'candidate_sites.xlsx',
                   'trajectories': traj_paths,
                   'routing_estimate': 'routing_estimate.md'}},
        ensure_ascii=False, indent=2), encoding='utf-8')
    print('=== G2 完成 ->', OUT)


if __name__ == '__main__':
    main()
