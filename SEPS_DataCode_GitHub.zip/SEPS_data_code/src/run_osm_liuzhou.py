# -*- coding: utf-8 -*-
"""柳州 OSM 路网时间计算（替代大圆 fallback）。

流程:
  1. 从 eldercare_inputs.xlsx 读 communities + facilities 经纬度
  2. osmnx.graph_from_bbox 拉柳州市路网（一次计算，缓存）
  3. nearest_nodes 匹配每个点到路网节点
  4. networkx.dijkstra_path_length 算两两最短路
  5. 时间 = 距离 / 平均速度 (km/h) × 60 分钟
  6. 输出 travel_edges_osm.csv 合并回 eldercare_inputs.xlsx

用法: python run_osm_liuzhou.py
"""
import csv
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'raw'


def load_points():
    """读社区和机构的 (id, lat, lon)。"""
    xl = pd.ExcelFile(DATA / 'eldercare_inputs.xlsx')
    comm = xl.parse('communities')
    fac = xl.parse('facilities')
    pts = []
    for _, r in comm.iterrows():
        pts.append({'id': r['community_id'], 'lat': float(r['lat']), 'lon': float(r['lon']), 'type': 'community'})
    for _, r in fac.iterrows():
        pts.append({'id': r['facility_id'], 'lat': float(r['lat']), 'lon': float(r['lon']), 'type': 'facility'})
    return pd.DataFrame(pts)


def build_osm_graph(lats, lons, buffer=0.1):
    """拉 OSM 路网。osmnx 2.x API: graph_from_bbox(bbox=tuple, ...)"""
    import osmnx as ox
    import networkx as nx

    lat_min, lat_max = lats.min() - buffer, lats.max() + buffer
    lon_min, lon_max = lons.min() - buffer, lons.max() + buffer
    # osmnx 2.x: bbox = (south, north, west, east)
    bbox = (lat_min, lat_max, lon_min, lon_max)

    print(f'  bbox: lat=[{lat_min:.2f},{lat_max:.2f}], lon=[{lon_min:.2f},{lon_max:.2f}]')
    t0 = time.time()
    G = ox.graph_from_bbox(bbox, network_type='drive', simplify=True)
    print(f'  OSM 路网: |V|={G.number_of_nodes()}, |E|={G.number_of_edges()}, 耗时 {time.time()-t0:.1f}s')
    G = ox.project_graph(G)
    return G


def compute_times(G, pts_df, speed_kmh=40.0):
    """对每个 community → facility 算最短驾车时间（分钟）。"""
    import networkx as nx
    from itertools import product

    # 匹配最近路网节点
    print('  匹配最近节点...')
    t0 = time.time()
    nodes = {}
    for _, r in pts_df.iterrows():
        try:
            n = ox.distance.nearest_nodes(G, r['lon'], r['lat'])
            nodes[r['id']] = n
        except Exception as e:
            print(f'    ! {r["id"]} 匹配失败: {e}')
    print(f'  完成 {len(nodes)}/{len(pts_df)}, 耗时 {time.time()-t0:.1f}s')

    communities = pts_df[pts_df['type'] == 'community']['id'].tolist()
    facilities = pts_df[pts_df['type'] == 'facility']['id'].tolist()

    print(f'  计算 {len(communities)}×{len(facilities)} = {len(communities)*len(facilities)} 对最短路...')
    t0 = time.time()
    rows = []
    for i, cid in enumerate(communities):
        nc = nodes.get(cid)
        if nc is None:
            continue
        # Dijkstra 从 nc 出发一次到所有可达节点
        try:
            lengths = nx.single_source_dijkstra_path_length(G, nc, weight='length')
        except Exception as e:
            print(f'    ! c={cid} dijkstra 失败: {e}')
            continue
        for fid in facilities:
            nf = nodes.get(fid)
            if nf is None:
                rows.append({'community_id': cid, 'facility_id': fid, 'travel_min': np.nan, 'status': 'missing'})
                continue
            dist_m = lengths.get(nf, None)
            if dist_m is None:
                rows.append({'community_id': cid, 'facility_id': fid, 'travel_min': np.nan, 'status': 'unreachable'})
            else:
                tmin = dist_m / 1000.0 / speed_kmh * 60.0
                rows.append({'community_id': cid, 'facility_id': fid, 'travel_min': round(tmin, 2), 'status': 'ok'})
        if (i+1) % 100 == 0:
            elapsed = time.time() - t0
            rate = (i+1) / elapsed if elapsed > 0 else 0
            print(f'    {i+1}/{len(communities)} done, 耗时 {elapsed:.1f}s, {rate:.1f} c/s')

    print(f'  完成, 耗时 {time.time()-t0:.1f}s')
    return pd.DataFrame(rows)


def main():
    print('=== 柳州 OSM 路网计算 ===')
    pts = load_points()
    print(f'  点数: {len(pts)} ({sum(pts.type=="community")} 社区, {sum(pts.type=="facility")} 机构)')

    G = build_osm_graph(pts.lat, pts.lon)
    te = compute_times(G, pts)

    out = DATA / 'travel_edges_osm.csv'
    te.to_csv(out, index=False)
    ok = te[te.status == 'ok']
    print(f'\n=== 汇总 ===')
    print(f'  输出: {out}')
    print(f'  ok: {len(ok)} ({len(ok)/len(te)*100:.1f}%)')
    print(f'  unreachable: {sum(te.status == "unreachable")}')
    print(f'  missing: {sum(te.status == "missing")}')
    if len(ok):
        print(f'  可达边: mean={ok.travel_min.mean():.1f}min, median={ok.travel_min.median():.1f}min, max={ok.travel_min.max():.1f}min')
        print(f'  ≤30min: {(ok.travel_min <= 30).sum()} ({(ok.travel_min <= 30).sum()/len(ok)*100:.1f}%)')


if __name__ == '__main__':
    main()
