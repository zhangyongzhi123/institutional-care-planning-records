# -*- coding: utf-8 -*-
"""P34 公共模块：参数重建与缓存、哈希、目录约定（Policy34 V2.0 阶段A审计）。"""
import hashlib
import json
import pickle
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
RUN_G5 = ROOT / 'runs' / 'P15_G5_20260930_020428'
OUT = ROOT / 'runs' / 'P34_verification_v2'          # 阶段性产出（包组装时拷贝）
OUT.mkdir(parents=True, exist_ok=True)
CACHE = ROOT / 'runs' / 'P34_cache'
CACHE.mkdir(parents=True, exist_ok=True)
PKG = ROOT.parent.parent                              # 数据目录
G2 = ROOT / 'runs' / 'P15_G2'

SRC_FILES = ['P15_G5_matrix.py', 'P15_G4_joint_allocation.py', 'run_E1_full.py',
             'model_io.py', 'solvers.py', 'P15_G5_negative_example.py',
             'P15_G5_figs_B_D.py', 'P15_G5_figs_A_E.py']


def sha256_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def code_hashes():
    return {f: sha256_file(ROOT / 'src' / f) for f in SRC_FILES}


def input_hashes():
    frozen = json.loads((RUN_G5 / 'G5_config_frozen.json').read_text(encoding='utf-8'))
    return {'input_sha256': frozen.get('input_sha256'),
            'routing_sha256': frozen.get('routing_sha256'),
            'routing_wide_sha256': frozen.get('routing_wide_sha256'),
            'run_at': frozen.get('run_at'),
            'time_limit_per_stage_s': frozen.get('time_limit_per_stage_s'),
            'gapRel': frozen.get('gapRel'),
            'solver': frozen.get('solver')}


def _cache_get(name):
    fp = CACHE / f'{name}.pkl'
    if fp.exists():
        return pickle.loads(fp.read_bytes())
    return None


def _cache_put(name, obj):
    (CACHE / f'{name}.pkl').write_bytes(pickle.dumps(obj))


def get_P_base():
    from run_E1_full import load_liuzhou
    obj = _cache_get('P_base_meta')
    if obj is None:
        P_base, coords, fcoords, districts, meta = load_liuzhou(use_osm=True)
        obj = (P_base, {a: {'lon': fcoords[a][0], 'lat': fcoords[a][1]} for a in fcoords},
               districts, meta)
        _cache_put('P_base_meta', obj)
    return obj


def get_P_variant(set_tag, dem):
    """set_tag ∈ {LEGACY, NEW, NEW_LOW}；dem ∈ {upround, total_preserving}。"""
    name = f'P_{set_tag}__{dem}'
    obj = _cache_get(name)
    if obj is None:
        from P15_G4_joint_allocation import extend_params, SCEN_K, REAL_CSV
        P_base, geo, districts, meta = get_P_base()
        ktag = {'LEGACY': None, 'NEW': 'BASE_15W_PER_BED', 'NEW_LOW': 'LOW_COST_750K'}[set_tag]
        sites = [] if set_tag == 'LEGACY' else pd.read_csv(
            G2 / f'greedy_trajectory_{dem}.csv').head(40).site_id.tolist()
        routing = (pd.read_csv(REAL_CSV, dtype={'site_id': str, 'community_id': str})
                   if sites else pd.DataFrame(columns=['site_id']))
        K_new = SCEN_K[ktag] if ktag else 0.0
        obj = extend_params(P_base, f'demand_{dem}.csv', sites, K_new, routing)
        _cache_put(name, obj)
    return obj


def demand_totals():
    """两套需求的 L/b 合计（按床型），并核对工作簿原始 b。"""
    out = {}
    from P15_G4_joint_allocation import DATA_P15
    from run_E1_full import K_MAP
    for dem in ('upround', 'total_preserving'):
        df = pd.read_csv(DATA_P15 / f'demand_{dem}.csv')
        L_by = df.groupby('care_type').L.sum().to_dict()
        b_by = df.groupby('care_type').guarantee_b.sum().to_dict()
        out[dem] = {'L_total': int(df.L.sum()), 'b_total': int(df.guarantee_b.sum()),
                    'L_by_type': {K_MAP[k]: int(v) for k, v in L_by.items()},
                    'b_by_type': {K_MAP[k]: int(v) for k, v in b_by.items()},
                    'n_communities': int(df.community_id.nunique())}
    return out


def stage_iter(rec):
    """统一迭代配置内各求解 stage：(stage_id, stage_dict)。"""
    stages = rec.get('solver_stages', {})
    if not stages and rec.get('inner_status'):
        stages = {'inner_qpa': {'status': rec['inner_status'],
                                'native': rec.get('native', {}) or {},
                                'time_s': rec.get('inner_time_s')}}
    return stages.items()


def objective_sense(stage_id):
    return {'stage1': 'max', 'stage2_cost': 'min', 'stage3_q': 'max', 'stage4_index': 'min',
            'minC': 'min', 'maxQ_tiebreak': 'max', 'inner_qpa': 'max'}.get(stage_id, '?')


TIME_LIMIT = {'stage1': 600, 'stage2_cost': 600, 'stage3_q': 600, 'stage4_index': 300,
              'minC': 600, 'maxQ_tiebreak': 600, 'inner_qpa': 600}
