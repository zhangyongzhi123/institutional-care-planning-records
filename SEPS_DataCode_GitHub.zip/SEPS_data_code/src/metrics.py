# -*- coding: utf-8 -*-
"""真实指标（核心模型V1.1 式(13)-(15)）。N=0 时指标为 None（N/A，原因码）。"""


def compute_metrics(P, T):
    N_jk = {(j, k): sum(T.get((a, j, k), 0) for a in P.facilities)
            for (j, k) in P.L}
    N_j = {j: sum(N_jk[(j, k)] for k in P.care_types) for j in P.communities}
    N = sum(N_j.values())
    D_j = {j: sum(P.L[(j, k)] for k in P.care_types) for j in P.communities}
    D = sum(D_j.values())
    m = {"N": N, "N_j": N_j, "N_jk": N_jk, "D": D, "D_j": D_j}
    if N == 0:
        m.update({"coverage": None, "SDM": None, "burden": None, "dist": None,
                  "quality": None, "Q0_avg": None, "na_reason": "N=0"})
        return m
    m["coverage"] = N / D
    m["SDM"] = 0.5 * sum(abs(N_j[j] / N - D_j[j] / D) for j in P.communities)
    m["burden"] = sum(P.p[(a, k)] / P.I[j] * T.get((a, j, k), 0)
                      for (a, j, k) in T) / N
    m["dist"] = sum(P.d[(a, j)] * T.get((a, j, k), 0) for (a, j, k) in T) / N
    m["quality"] = sum(P.H[(a, k)] * T.get((a, j, k), 0) for (a, j, k) in T) / N
    m["Q0_avg"] = sum(P.Q0(a, j, k) * T.get((a, j, k), 0) for (a, j, k) in T) / N
    m["na_reason"] = None
    return m


def shortfall(P, T):
    """社区×床型缺额 [L − Σ_a T]₊ 与保障缺口 [b − Σ_a T]₊。"""
    out = {}
    for (j, k) in P.L:
        s = sum(T.get((a, j, k), 0) for a in P.facilities)
        out[(j, k)] = {"unmet": P.L[(j, k)] - s, "unmet_guarantee": P.b[(j, k)] - s}
    return out
