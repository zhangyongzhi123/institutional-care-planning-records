# -*- coding: utf-8 -*-
"""模型输入加载与信号计算（核心模型V1.1 式(3)-(9)、(22)-(27)）。

所有ID按字符串读取；金额单位元/期；距离单位分钟。
"""
import math
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

CARE_TYPES = ("NH", "BK", "WELLNESS")  # 基本/护理/康养 固定编码


@dataclass
class Params:
    communities: list
    facilities: list
    care_types: list
    L: dict          # (j,k) -> int
    b: dict          # (j,k) -> int
    I: dict          # j -> float
    C0: dict         # (a,k) -> int
    p: dict          # (a,k) -> float
    cst: dict        # (a,k) -> float  单位运营成本
    H: dict          # (a,k) -> float
    F0: dict         # a -> float
    Pi0: dict        # a -> float
    d: dict          # (a,j) -> float 分钟
    U0: dict         # j -> float
    alpha: dict      # j -> float
    beta_h: dict     # j -> float
    tau: float
    p_cap: float
    h_min: float
    afford_cap: float
    projects: dict   # pid -> dict(facility, K, private)
    deltaC: dict     # (pid,k) -> int
    proj_of_fac: dict  # a -> [pid]
    W: tuple         # (w_d, w_p, w_h)
    d0: float
    gamma_p: float
    # QMA / PA 预注册参数
    theta: tuple     # (beta, zeta, rho)
    lam_grid: tuple  # 预注册区间
    omega_R: float
    v_norm_bounds: tuple  # V 归一化固定收入界 (I_lo, I_hi)
    pref: dict       # k -> float
    config: dict = field(default_factory=dict)

    # ---------- 容量与项目（式(3)） ----------
    def capacity(self, a, k, z):
        """C_ak(z) = C0 + Σ ΔC·z_p（仅当项目附属该机构）。"""
        c = self.C0[(a, k)]
        for pid in self.proj_of_fac.get(a, []):
            c += self.deltaC.get((pid, k), 0) * z.get(pid, 0)
        return c

    def K_z(self, z):
        return sum(self.projects[pid]["K"] * zp for pid, zp in z.items())

    def F_active(self, a, z, y):
        """机构实际承担固定成本 F_a(z)·y_a：F0 + 项目自付（政府建设支出分账不计入）。"""
        if not y.get(a, 0):
            return 0.0
        f = self.F0[a]
        for pid in self.proj_of_fac.get(a, []):
            f += self.projects[pid]["private"] * z.get(pid, 0)
        return f

    # ---------- 家庭效用与硬资格（式(7)） ----------
    def utility(self, a, j, k):
        return self.H[(a, k)] - self.alpha[j] * self.d[(a, j)] - self.beta_h[j] * self.p[(a, k)] / self.I[j]

    def hard_chi(self, a, j, k):
        """硬资格χ：资质+质量线+价格帽+服务范围+支付上限+U≥U0。返回(0/1, 原因)。"""
        reasons = []
        if self.H[(a, k)] < self.h_min:
            reasons.append("quality_floor")
        cap = self.p_cap[k] if isinstance(self.p_cap, dict) else self.p_cap
        if self.p[(a, k)] > cap:
            reasons.append("price_cap")
        if self.d[(a, j)] > self.tau:
            reasons.append("service_range")
        if self.p[(a, k)] > self.afford_cap * self.I[j]:
            reasons.append("affordability")
        if self.utility(a, j, k) < self.U0[j] - 1e-12:
            reasons.append("household_utility")
        return (0, "+".join(reasons)) if reasons else (1, "")

    # ---------- 基础资格（式(8)(9)） ----------
    def Q0(self, a, j, k):
        chi, _ = self.hard_chi(a, j, k)
        if not chi:
            return 0.0
        G = math.exp(-0.5 * (self.d[(a, j)] / self.d0) ** 2)
        P = math.exp(-self.gamma_p * self.p[(a, k)] / self.I[j])
        wd, wp, wh = self.W
        return wd * G + wp * P + wh * self.H[(a, k)]

    def edges(self):
        """全部 (a,j,k) 边。"""
        return [(a, j, k) for a in self.facilities for j in self.communities for k in self.care_types]

    # ---------- 原QMA适配（式(22)(23)） ----------
    def qma_Qbar(self, Q0_map, delta0):
        """给定全部边上的Q0映射与δ0，返回 Q̄ 映射。

        式(22)(23)：ℓ=1−Q0；分段变换 f_θ；在允许边集 E 上归一化；
        若 fmax=fmin 则 Q̄=1；禁边（χ=0）Q̄=0（仍为禁边，Q=0≠禁边仅指语义）。
        """
        beta, zeta, rho = self.theta
        allowed = [e for e in Q0_map if self.hard_chi(*e)[0]]
        fvals = {}
        for e in allowed:
            lv = 1.0 - Q0_map[e]
            dev = abs(lv - beta)
            if lv < beta and dev > zeta * delta0:
                f = dev / rho
            elif lv > beta and dev > zeta * delta0:
                f = rho * dev
            else:
                f = dev
            fvals[e] = f
        fmin, fmax = min(fvals.values()), max(fvals.values())
        qbar = {}
        for e in Q0_map:
            if e in fvals:
                qbar[e] = 1.0 if fmax - fmin < 1e-15 else 1.0 - (fvals[e] - fmin) / (fmax - fmin)
            else:
                qbar[e] = 0.0  # 禁边
        return qbar, fvals

    # ---------- PA信号（式(24)-(26)） ----------
    def R_signal(self, T_ref):
        R = {}
        for (j, k) in self.L:
            if self.L[(j, k)] > 0:
                served = sum(T_ref.get((a, j, k), 0) for a in self.facilities)
                R[(j, k)] = max(0, self.L[(j, k)] - served) / self.L[(j, k)]
            else:
                R[(j, k)] = 0.0
        return R

    def V_signal(self):
        i_lo, i_hi = self.v_norm_bounds
        x_lo, x_hi = 1.0 / i_hi, 1.0 / i_lo
        V = {}
        for j in self.communities:
            for k in self.care_types:
                if self.L.get((j, k), 0) > 0:
                    x = self.pref.get(k, 1.0) / self.I[j]
                    V[(j, k)] = min(1.0, max(0.0, (x - x_lo) / (x_hi - x_lo)))
        return V

    def pi_signal(self, R, V):
        w = self.omega_R
        return {r: w * R[r] + (1 - w) * V[r] for r in R if r in V}

    def QPA(self, Qbar_map, pi_map, lam):
        """式(27)：Q^PA = χ·Q̄·(1+λπ)/(1+λ)。λ=0 严格恢复 χ·Q̄。"""
        out = {}
        for e, q in Qbar_map.items():
            chi, _ = self.hard_chi(*e)
            r = (e[1], e[2])
            h = (1.0 + lam * pi_map.get(r, 0.0)) / (1.0 + lam)
            out[e] = q * h if chi else 0.0
        return out


def load_params(xlsx_path, config):
    """从输入工作簿读取参数（ID全部字符串化）。"""
    xl = pd.ExcelFile(xlsx_path)
    comm = xl.parse("communities", dtype=str)
    dem = xl.parse("demand", dtype={"community_id": str})
    fac = xl.parse("facilities", dtype={"facility_id": str})
    cp = xl.parse("capacity_price", dtype={"facility_id": str})
    ed = xl.parse("travel_edges", dtype={"facility_id": str, "community_id": str})
    hr = xl.parse("household_rules", dtype={"community_id": str})
    prj = xl.parse("projects", dtype={"project_id": str, "facility_id": str})
    pc = xl.parse("project_capacity", dtype={"project_id": str})
    t0 = xl.parse("baseline_T0", dtype={"facility_id": str, "community_id": str})

    communities = comm.community_id.tolist()
    facilities = fac.facility_id.tolist()
    care_types = sorted(dem.care_type.unique())
    L = {(r.community_id, r.care_type): int(r.demand_L) for r in dem.itertuples()}
    b = {(r.community_id, r.care_type): int(r.guarantee_b) for r in dem.itertuples()}
    I = {r.community_id: float(r.income_value) for r in comm.itertuples()}
    C0, p, cst, H = {}, {}, {}, {}
    for r in cp.itertuples():
        C0[(r.facility_id, r.care_type)] = int(r.capacity_C0)
        p[(r.facility_id, r.care_type)] = float(r.price_p)
        cst[(r.facility_id, r.care_type)] = float(r.unit_cost_c)
        H[(r.facility_id, r.care_type)] = float(r.quality_H)
    F0 = {r.facility_id: float(r.fixed_cost) for r in fac.itertuples()}
    Pi0 = {r.facility_id: float(r.reservation_profit) for r in fac.itertuples()}
    d = {(r.facility_id, r.community_id): float(r.travel_minutes) for r in ed.itertuples()}
    U0 = {r.community_id: float(r.outside_utility) for r in hr.itertuples()}
    alpha = {r.community_id: float(r.alpha_distance) for r in hr.itertuples()}
    beta_h = {r.community_id: float(r.beta_price) for r in hr.itertuples()}
    afford = {r.community_id: float(r.affordability_cap) for r in hr.itertuples()}
    projects = {r.project_id: {"facility": r.facility_id, "K": float(r.public_cost_K),
                               "private": float(r.private_cost)} for r in prj.itertuples()}
    deltaC = {(r.project_id, r.care_type): int(r.delta_capacity) for r in pc.itertuples()}
    proj_of_fac = {}
    for pid, info in projects.items():
        proj_of_fac.setdefault(info["facility"], []).append(pid)
    T0 = {(r.facility_id, r.community_id, r.care_type): int(r.assigned_beds) for r in t0.itertuples()}

    h_rule = hr.iloc[0]
    return Params(
        communities=communities, facilities=facilities, care_types=care_types,
        L=L, b=b, I=I, C0=C0, p=p, cst=cst, H=H, F0=F0, Pi0=Pi0, d=d,
        U0=U0, alpha=alpha, beta_h=beta_h,
        tau=float(h_rule.distance_cap), p_cap=float(h_rule.price_cap),
        h_min=float(h_rule.quality_floor),
        afford_cap=min(afford.values()),
        projects=projects, deltaC=deltaC, proj_of_fac=proj_of_fac,
        W=tuple(config["Q0_weights"]), d0=float(config["d0"]), gamma_p=float(config["gamma_p"]),
        theta=tuple(config["theta"]), lam_grid=tuple(config["lam_grid"]),
        omega_R=float(config["omega_R"]),
        v_norm_bounds=tuple(config["v_norm_income_bounds"]),
        pref=dict(config["pref"]), config=config,
    ), T0
