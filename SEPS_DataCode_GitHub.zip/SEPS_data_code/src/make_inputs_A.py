# -*- coding: utf-8 -*-
"""生成示例A合成输入工作簿 eldercare_inputs_A.xlsx（交接说明§3.2 schema）。

所有数值见 data/raw/ASSUMPTIONS_exampleA.md（透明披露）。自动执行§3.3数据验收校验，
并计算 SHA-256 写入 provenance 表。禁止手工改动本脚本产出的数值。
"""
import hashlib
import itertools
import math
from pathlib import Path

import pandas as pd

RAW = Path(__file__).resolve().parents[1] / "data" / "raw"
XLSX = RAW / "eldercare_inputs_A.xlsx"

CARE = "NH"  # 护理床型（单床型示例）

# ---------- 合成输入（与 ASSUMPTIONS_exampleA.md 严格一致） ----------
COORD = {  # 合成平面坐标 km
    "a1": (0.0, 0.0), "a2": (16.0, 0.0),
    "j1": (3.333, 4.163), "j2": (12.667, 4.163), "j3": (16.667, 13.314),
}
COMMUNITIES = {  # id: (district, n65, income, U0, alpha, beta)
    "j1": ("D1", 1200, 4493, 0.25, 0.006, 0.3),
    "j2": ("D1", 800, 4000, 0.25, 0.006, 0.3),
    "j3": ("D2", 1000, 3052, 0.20, 0.006, 0.3),
}
DEMAND = {"j1": (8, 2), "j2": (5, 1), "j3": (6, 2)}  # L, b
FACILITIES = {  # id: (is_existing, district, H, F0, Pi0)
    "a1": (1, "D1", 0.85, 800.0, 200.0),
    "a2": (1, "D2", 0.70, 600.0, 150.0),
}
CAP_PRICE = {"a1": (4, 3000.0, 2300.0), "a2": (3, 3000.0, 2800.0)}  # C0, p, c
PROJECTS = {"p1": ("a2", "expansion", 2000.0, 500.0)}  # facility, type, K, private
DELTA_C = {"p1": {CARE: 3}}

TAU = 30.0        # 服务范围（分钟）
P_CAP = 3200.0    # 价格帽（元/月）
H_MIN = 0.6       # 质量线
AFFORD_CAP = 1.0  # 支付上限 p <= AFFORD_CAP * I
W = (0.4, 0.3, 0.3)
D0 = 20.0
GAMMA_P = 1.0


def travel_minutes(f, c):
    (x1, y1), (x2, y2) = COORD[f], COORD[c]
    km = math.hypot(x1 - x2, y1 - y2)
    return round(km * 1.25 / 40.0 * 60.0)  # 断链fallback口径，取整分钟


def build_frames():
    comm = pd.DataFrame(
        [{"community_id": j, "district_id": d, "n65": n, "income_period": "month",
          "income_value": i, "income_source": "synthetic_scenario",
          "x": COORD[j][0], "y": COORD[j][1], "coord_crs": "synthetic_planar_km"}
         for j, (d, n, i, *_ ) in COMMUNITIES.items()])
    dem = pd.DataFrame(
        [{"community_id": j, "care_type": CARE, "demand_L": L, "guarantee_b": b,
          "demand_rate": 0.05, "source_or_scenario": "synthetic_exampleA",
          "rounding_rule": "none_integer_input"}
         for j, (L, b) in DEMAND.items()])
    fac = pd.DataFrame(
        [{"facility_id": a, "is_existing": ex, "district_id": d, "period": "month",
          "fixed_cost": F0, "reservation_profit": Pi0, "source": "synthetic_exampleA"}
         for a, (ex, d, _H, F0, Pi0) in FACILITIES.items()])
    # 质量分型记入 capacity_price（合同情景）
    cp = pd.DataFrame(
        [{"facility_id": a, "care_type": CARE, "capacity_C0": C0, "price_p": p,
          "unit_cost_c": c, "quality_H": FACILITIES[a][2], "qualification": 1,
          "source": "synthetic_scenario"}
         for a, (C0, p, c) in CAP_PRICE.items()])
    edges = pd.DataFrame(
        [{"facility_id": a, "community_id": j, "travel_minutes": travel_minutes(a, j),
          "source": "synthetic_planar_fallback", "date": "2026-09-23"}
         for a, j in itertools.product(FACILITIES, COMMUNITIES)])
    hr = pd.DataFrame(
        [{"community_id": j, "care_type": CARE, "outside_utility": COMMUNITIES[j][3],
          "alpha_distance": COMMUNITIES[j][4], "beta_price": COMMUNITIES[j][5],
          "quality_value": 1.0, "affordability_cap": AFFORD_CAP, "distance_cap": TAU,
          "price_cap": P_CAP, "quality_floor": H_MIN,
          "source_or_scenario": "synthetic_transparent"}
         for j in COMMUNITIES])
    prj = pd.DataFrame(
        [{"project_id": p, "facility_id": a, "project_type": t, "public_cost_K": K,
          "private_cost": Fp, "period": "month", "source_or_scenario": "synthetic_exampleA"}
         for p, (a, t, K, Fp) in PROJECTS.items()])
    pc = pd.DataFrame(
        [{"project_id": p, "care_type": k, "delta_capacity": dv}
         for p, dd in DELTA_C.items() for k, dv in dd.items()])
    t0 = pd.DataFrame(
        [{"facility_id": a, "community_id": j, "care_type": CARE, "assigned_beds": 0,
          "baseline_id": "zero_baseline"}
         for a, j in itertools.product(FACILITIES, COMMUNITIES)])
    return {"communities": comm, "demand": dem, "facilities": fac,
            "capacity_price": cp, "travel_edges": edges, "household_rules": hr,
            "projects": prj, "project_capacity": pc, "baseline_T0": t0}


def validate(frames):
    """交接说明§3.3 阻断规则校验。"""
    errs = []
    dem = frames["demand"].set_index(["community_id", "care_type"])
    for _, r in dem.iterrows():
        if r.demand_L < 0 or r.guarantee_b < 0 or r.guarantee_b > r.demand_L:
            errs.append(f"demand b<=L violated: {r.community_id}")
    ids_c = set(frames["communities"].community_id)
    ids_f = set(frames["facilities"].facility_id)
    for df, cols in [(frames["travel_edges"], ["facility_id", "community_id"]),
                     (frames["baseline_T0"], ["facility_id", "community_id"])]:
        for col, ids in zip(cols, [ids_f, ids_c]):
            bad = set(df[col]) - ids
            if bad:
                errs.append(f"orphan ids in {col}: {bad}")
    if set(frames["demand"].community_id) != ids_c:
        errs.append("demand/communities mismatch")
    if set(frames["household_rules"].community_id) != ids_c:
        errs.append("household_rules/communities mismatch")
    for _, r in frames["projects"].iterrows():
        if r.facility_id not in ids_f:
            errs.append(f"project facility missing: {r.project_id}")
    for df in frames.values():
        if df.isna().any().any():
            errs.append(f"NaN in sheet: missing values must not default to 0")
            break
    if errs:
        raise ValueError("data validation failed: " + "; ".join(errs))


def main():
    frames = build_frames()
    validate(frames)
    # 先写不带 provenance 的文件计算 SHA-256，再补 provenance 重写
    tmp = RAW / "_tmp_inputs.xlsx"
    with pd.ExcelWriter(tmp, engine="openpyxl") as w:
        for name, df in frames.items():
            df.to_excel(w, sheet_name=name, index=False)
    sha_tmp = hashlib.sha256(tmp.read_bytes()).hexdigest()
    prov = pd.DataFrame([
        {"field_or_table": "eldercare_inputs_A.xlsx", "source": "synthetic_exampleA",
         "measurement_level": "synthetic", "observed_imputed_scenario": "scenario",
         "notes": f"sha256_pre_provenance={sha_tmp}; see ASSUMPTIONS_exampleA.md"},
        {"field_or_table": "travel_edges", "source": "synthetic_planar_fallback",
         "measurement_level": "scenario", "observed_imputed_scenario": "fallback_formula",
         "notes": "t=round(km*1.25/40*60); coord synthetic planar km"},
        {"field_or_table": "capacity_price", "source": "synthetic_scenario",
         "measurement_level": "scenario", "observed_imputed_scenario": "imputed",
         "notes": "H,c,F,Pi0 no measurement; transparent scenario (A3)"},
    ])
    frames["provenance"] = prov
    with pd.ExcelWriter(XLSX, engine="openpyxl") as w:
        for name, df in frames.items():
            df.to_excel(w, sheet_name=name, index=False)
    tmp.unlink()
    sha = hashlib.sha256(XLSX.read_bytes()).hexdigest()
    (RAW / "eldercare_inputs_A.sha256").write_text(f"{sha}  eldercare_inputs_A.xlsx\n", encoding="utf-8")
    print(f"written: {XLSX}")
    print(f"sha256:  {sha}")
    print("validation: OK (§3.3 checks passed)")


if __name__ == "__main__":
    main()
