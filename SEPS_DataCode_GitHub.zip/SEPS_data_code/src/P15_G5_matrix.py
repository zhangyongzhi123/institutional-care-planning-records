# -*- coding: utf-8 -*-
"""Policy15 G5: 正式实验矩阵（§8 A–F）。授权：作者确认 + 分阶段闸门自查通过（2026-09-30）。

A 同预算三项目集: 共同预算网格 [5,10,20,50,100,200] 百万元（口径A年化）×
    {P_EXP_LEGACY, P_EXP_NEW(BASE), P_EXP_NEW_LOW} × {upround, total_preserving}，
    b=diagnostic（formal 已由 G4 证明物理不可行，min cost=∞ 见 frozen 配置）。
    输出含原服务关系减少量（同预算下 LEGACY 与 NEW 在既有机构边上的服务减少量，
    预注册定义 incumbent_displacement = Σ_e∈incumbent max(0, T_LEGACY−T_NEW)）。
B 同目标最小支出: b=0 诊断宇宙 + 共同总覆盖目标（upround 45/47.5/49%，tp 45/48/50%），
    min C=K(z)+12ΣS s.t. ΣT≥v_tgt，第二阶段 max ΣQ0·T 破同解；嵌套单调性检查
    （NEW 含 LEGACY：min cost 不应更高，违反即报告模型/界问题）。formal b 目标成本=∞（G4 证书）。
C 三方利益协调: 代表预算 50M（BASE），每次只改 收费上限 p_cap / 质量线 h_min /
    保留收益缩放 s 之一（各 2 个非基准档），报告政府支出/机构 IR 裕度/居民负担距离。
D 候选池敏感性: M∈{10,20,40}（同一贪心轨迹嵌套子集，均已在 49 点并集内路由）×
    预算 {10M,50M}；宽池 117 点（wide117 路由矩阵）× 50M。
E QMA/PA-QMA 重跑: 共同新候选池（NEW BASE）+ 同预算 50M + 同服务量截面 v；
    先冻结 T^ref（G5 词典序解），delta0=max(0.01,std(Q0))，R/V/π 预注册 ω_R=0.5，
    λ∈{0,0.5,1,1.5,2}；λ=0 严格恢复 QMA。同锚点覆盖相同是理论预期。
F 数据接口敏感性: 纯分析（G1 T⁰/R⁰ + G2 贪心轨迹 + 共同候选宇宙对比）。

复用 G4 模块（extend_params/evaluate/cert 等）；断点续跑：每个配置独立 JSON，存在即跳过。
用法:
  python src/P15_G5_matrix.py --exp A          # 或 ALL / A,B,C
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pulp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from run_E1_full import load_liuzhou, CONFIG  # noqa: E402
from P15_G4_joint_allocation import (  # noqa: E402
    extend_params, F_active, psi_g4, native_info, build_keys, evaluate, cert,
    sha256, SCEN_K, NEW_PACK, REAL_CSV, DATA_P15, G2, CT)

WIDE_CSV = DATA_P15 / 'travel_edges_newpoints_amap_wide117.csv'

G5_FROZEN = {
    'rule': 'A/C/D/E 用四阶段词典序（同 G4，可加 C≤B 预算）；B 用 minC→maxQ 两阶段',
    'budget_grid_yuan': [5e6, 10e6, 20e6, 50e6, 100e6, 200e6],
    'budget_labels': {5e6: '低/接近新建启动', 10e6: '新建启动+', 20e6: '中低',
                      50e6: '中（代表预算）', 100e6: '中高', 200e6: '较高'},
    'targets': {'upround': [0.45, 0.475, 0.49], 'total_preserving': [0.45, 0.48, 0.50]},
    'C_perturb': {'p_cap': {'low': 3000.0, 'base': 4000.0},
                  'h_min': {'low': 0.55, 'base': 0.60, 'high': 0.65},
                  'pi0_scale': {'half': 0.5, 'base': 1.0, 'double': 2.0}},
    'M_grid': [10, 20, 40], 'D_budgets': [10e6, 50e6], 'wide_pool_budget': 50e6,
    'rep_budget': 50e6, 'lam_grid': [0.0, 0.5, 1.0, 1.5, 2.0], 'omega_R': 0.5,
    'b_note': ('formal b 全部项目集物理不可行（G4 Lemma1 证书 z1 maxflow 2,888 < 5,026），'
               '故 G5-A/C/D/E 全部在 b=0 诊断宇宙运行；G5-B 的 formal-b 最小成本记为 ∞ 不重解'),
    'incumbent_displacement_def': 'Σ_e∈incumbent max(0, T_LEGACY(e) − T_NEW(e))，同(需求,预算)',
    'pi0_scale_scope': '缩放全部机构 Pi0（既有 μ=0.6 公式值与新点 0.05K/12 同比例）',
    'prohibitions': ['不回填摘要', 'formal 与 diagnostic 不合并', '不宣称 PA-QMA 优势（负结果如实报）',
                     '共同锚点覆盖相同=理论预期非算法失败', '规划代理点≠批准地块',
                     '不同保障水平不连成可实施前沿', '月费与年费不同轴'],
}


def g5_solve(P, proj_fixed_f, new_facs, b_mode, time_limit, gap, budget=None, target=None):
    """G5 词典序（budget 可选预算上限）与 minC→maxQ（target 模式）。"""
    keys = build_keys(P)
    by_ak, by_jk = {}, {}
    for e in keys:
        by_ak.setdefault((e[0], e[2]), []).append(e)
        by_jk.setdefault((e[1], e[2]), []).append(e)
    idx = {e: i for i, e in enumerate(keys)}
    Q0 = {e: P.Q0(*e) for e in keys}
    b_use = P.b if b_mode == 'formal' else {kk: 0 for kk in P.b}

    def base_cons():
        T = {e: pulp.LpVariable(f'T_{i}', lowBound=0, cat='Integer') for i, e in enumerate(keys)}
        yv = {a: pulp.LpVariable(f'y_{a}', cat='Binary') for a in P.facilities}
        zv = {pid: pulp.LpVariable(f'z_{pid}', cat='Binary') for pid in P.projects}
        S = {a: pulp.LpVariable(f'S_{a}', lowBound=0) for a in P.facilities}
        cons = []
        for pid, info in P.projects.items():
            cons.append(zv[pid] <= yv[info['facility']])
        for a in new_facs:
            cons.append(yv[a] == zv[P.proj_of_fac[a][0]])
        for a in P.facilities:
            for k in CT:
                add = pulp.lpSum(P.deltaC.get((pid, k), 0) * zv[pid]
                                 for pid in P.proj_of_fac.get(a, []))
                if (a, k) in by_ak or P.C0.get((a, k), 0) > 0:
                    cons.append(pulp.lpSum(T[e] for e in by_ak.get((a, k), []))
                                <= P.C0.get((a, k), 0) + add)
        for (j, k), es in by_jk.items():
            cons.append(pulp.lpSum(T[e] for e in es) >= b_use[(j, k)])
            cons.append(pulp.lpSum(T[e] for e in es) <= P.L[(j, k)])
        for e in keys:
            cons.append(T[e] <= P.L[(e[1], e[2])] * yv[e[0]])
        for a in P.facilities:
            rev = pulp.lpSum((P.p[(a, k)] - P.cst[(a, k)]) * T[e]
                             for k in CT for e in by_ak.get((a, k), []))
            fix = (P.F0[a] * yv[a]
                   + pulp.lpSum((P.projects[pid]['private'] + proj_fixed_f.get(pid, 0.0))
                                * zv[pid] for pid in P.proj_of_fac.get(a, [])))
            cons.append(S[a] >= P.Pi0[a] * yv[a] + fix - rev)
        C = (pulp.lpSum(P.projects[pid]['K'] * zv[pid] for pid in P.projects)
             + 12.0 * pulp.lpSum(S.values()))
        if budget is not None:
            cons.append(C <= float(budget))
        return T, yv, zv, S, C, cons

    def run(name, sense, obj, cons, tl):
        pr = pulp.LpProblem(f'G5_{name}', sense)
        for c in cons:
            pr += c
        pr += obj
        t = time.time()
        pr.solve(pulp.HiGHS(msg=0, timeLimit=tl, gapRel=gap, threads=1))
        st = {'Optimal': 'OPTIMAL', 'Not Solved': 'FEASIBLE_TIMEOUT',
              'Infeasible': 'PROVEN_INFEASIBLE', 'Unbounded': 'UNKNOWN'}.get(
            pulp.LpStatus[pr.status], 'UNKNOWN')
        return st, native_info(pr), round(time.time() - t, 1)

    def snap(T, yv, zv):
        return ({e: int(round(T[e].value())) for e in keys},
                {a: int(round(yv[a].value())) for a in P.facilities},
                {pid: int(round(zv[pid].value())) for pid in P.projects})

    if target is not None:                                   # ---- B: minC → maxQ ----
        T, yv, zv, S, C, cons = base_cons()
        st1, ni1, dt1 = run('b1minC', pulp.LpMinimize, C,
                            cons + [pulp.lpSum(T.values()) >= int(target)], time_limit)
        if st1 != 'OPTIMAL':
            return {'status': st1, 'stages': {'minC': {'status': st1, 'native': ni1, 'time_s': dt1}},
                    'keys_n': len(keys)}
        Cstar = float(pulp.value(C))
        T, yv, zv, S, C2, cons = base_cons()
        st2, ni2, dt2 = run('b2maxQ', pulp.LpMaximize,
                            pulp.lpSum(Q0[e] * T[e] for e in keys),
                            cons + [pulp.lpSum(T.values()) >= int(target), C2 <= Cstar + 1.0],
                            time_limit)
        Tv, yv_, zv_ = snap(T, yv, zv)
        # 无内点防护：HiGHS 填 0 的假解不得作为 B 的返回
        if sum(Tv.values()) < int(target):
            return {'status': f'b1={st1},b2={st2}_no_incumbent',
                    'stages': {'minC': {'status': st1, 'native': ni1, 'time_s': dt1,
                                        'Cstar_annual': Cstar},
                               'maxQ_tiebreak': {'status': st2, 'native': ni2, 'time_s': dt2}},
                    'keys_n': len(keys)}
        return {'status': 'OPTIMAL' if st2 == 'OPTIMAL' else f'b1={st1},b2={st2}',
                'stages': {'minC': {'status': st1, 'native': ni1, 'time_s': dt1,
                                    'Cstar_annual': Cstar},
                           'maxQ_tiebreak': {'status': st2, 'native': ni2, 'time_s': dt2}},
                'T': Tv, 'y': yv_, 'z': zv_, 'keys_n': len(keys)}

    # ---- A/C/D/E: 词典序（budget 可选） ----
    T, yv, zv, S, C, cons = base_cons()
    st1, ni1, dt1, _v = None, None, None, None
    pr = pulp.LpProblem('G5_s1', pulp.LpMaximize)
    for c in cons:
        pr += c
    pr += pulp.lpSum(T.values())
    t0 = time.time()
    pr.solve(pulp.HiGHS(msg=0, timeLimit=time_limit, gapRel=gap, threads=1))
    st1 = {'Optimal': 'OPTIMAL', 'Not Solved': 'FEASIBLE_TIMEOUT',
           'Infeasible': 'PROVEN_INFEASIBLE', 'Unbounded': 'UNKNOWN'}.get(
        pulp.LpStatus[pr.status], 'UNKNOWN')
    ni1, dt1 = native_info(pr), round(time.time() - t0, 1)
    if st1 == 'PROVEN_INFEASIBLE':
        return {'status': 'PROVEN_INFEASIBLE',
                'stages': {'stage1': {'status': st1, 'native': ni1, 'time_s': dt1}},
                'keys_n': len(keys)}
    vstar = int(round(sum(T[e].value() for e in keys)))
    # Stage1 超时且未找到任何正覆盖解（平凡0解）：后续阶段无意义，诚实返回超时，
    # 不得伪装成 v=0 的 SOLVED（v=0 仅在 st1=OPTIMAL 时才是被证实的全阻塞）
    if vstar == 0 and st1 != 'OPTIMAL':
        return {'status': f's1={st1}_zero_incumbent',
                'stages': {'stage1': {'status': st1, 'native': ni1, 'time_s': dt1,
                                      'v': vstar}},
                'keys_n': len(keys)}

    T, yv, zv, S, C2, cons = base_cons()
    st2, ni2, dt2 = run('s2cost', pulp.LpMinimize, C2,
                        cons + [pulp.lpSum(T.values()) == vstar], time_limit)
    T2, y2, z2 = snap(T, yv, zv)
    # PuLP/HiGHS 在「超时且无内点」时会把变量值静默填 0：必须校验快照可行，不得传播假解
    if sum(T2.values()) != vstar:
        return {'status': f's1={st1},s2={st2}_no_incumbent',
                'stages': {'stage1': {'status': st1, 'native': ni1, 'time_s': dt1, 'v': vstar},
                           'stage2_cost': {'status': st2, 'native': ni2, 'time_s': dt2,
                                           'Cstar_annual': None}},
                'keys_n': len(keys)}
    Cstar = float(pulp.value(C2))
    q2 = float(sum(Q0[e] * T2[e] for e in keys))  # stage2 解的 Q 值 = stage3 可行值，可作合法下界割

    T, yv, zv, S, C3, cons = base_cons()
    st3, ni3, dt3 = run('s3q', pulp.LpMaximize, pulp.lpSum(Q0[e] * T[e] for e in keys),
                        cons + [pulp.lpSum(T.values()) == vstar, C3 <= Cstar + 1.0,
                                # 词典序合法割：stage3 最优 ≥ stage2 可行解的 Q，不改变解集
                                pulp.lpSum(Q0[e] * T[e] for e in keys)
                                >= q2 - 1e-6 * max(1.0, abs(q2))], time_limit)
    T3, y3, z3 = snap(T, yv, zv)
    qsum = float(sum(Q0[e] * T3[e] for e in keys))
    # stage3 无内点（快照和≠v*，HiGHS 填 0 所致）：回退 stage2 已认证解（v*,C* 双认证，
    # 仅 Q 认证缺失），t_source 如实披露——与 G4 stage4 超时回退 stage3 同款诚实模式
    if sum(T3.values()) != vstar:
        return {'status': f's1={st1},s2={st2},s3={st3}_no_incumbent_used_stage2',
                'stages': {'stage1': {'status': st1, 'native': ni1, 'time_s': dt1, 'v': vstar},
                           'stage2_cost': {'status': st2, 'native': ni2, 'time_s': dt2,
                                           'Cstar_annual': Cstar},
                           'stage3_q': {'status': st3, 'native': ni3, 'time_s': dt3,
                                        'Qsum': None, 'q2_cut_from_stage2': q2,
                                        't_source': 'stage2_fallback_stage3_no_incumbent'}},
                'T': dict(T2), 'y': dict(y2), 'z': dict(z2), 'keys_n': len(keys)}

    idx_cut = float(sum(idx[e] * T3[e] for e in keys))
    # 大量级割（Σidx·T ~1e7+）的绝对 1e-6 容差数值脆弱，改相对容差（只会更宽松，不会错杀）
    T, yv, zv, S, C4, cons = base_cons()
    st4, ni4, dt4 = run('s4idx', pulp.LpMinimize, pulp.lpSum(idx[e] * T[e] for e in keys),
                        cons + [pulp.lpSum(T.values()) == vstar, C4 <= Cstar + 1.0,
                                pulp.lpSum(Q0[e] * T[e] for e in keys)
                                >= qsum - 1e-6 * max(1.0, abs(qsum)),
                                pulp.lpSum(idx[e] * T[e] for e in keys)
                                <= idx_cut + 1e-6 * max(1.0, abs(idx_cut))],
                        min(time_limit, 300))
    Tv, yv_, zv_ = snap(T, yv, zv)
    if st4 == 'OPTIMAL' and sum(Tv.values()) == vstar:
        t_source = 'stage4_index'
    else:
        Tv, yv_, zv_, t_source = dict(T3), dict(y3), dict(z3), 'stage3_fallback_no_index_cert'
    return {'status': 'OPTIMAL' if st1 == st2 == st3 == 'OPTIMAL' else f's1={st1},s2={st2},s3={st3}',
            'stages': {'stage1': {'status': st1, 'native': ni1, 'time_s': dt1, 'v': vstar},
                       'stage2_cost': {'status': st2, 'native': ni2, 'time_s': dt2,
                                       'Cstar_annual': Cstar},
                       'stage3_q': {'status': st3, 'native': ni3, 'time_s': dt3, 'Qsum': qsum},
                       'stage4_index': {'status': st4, 'native': ni4, 'time_s': dt4,
                                        't_source': t_source}},
            'T': Tv, 'y': yv_, 'z': zv_, 'keys_n': len(keys)}


def qpa_inner(P, proj_fixed_f, new_facs, QPA, v_ref, budget, time_limit, gap):
    """E 内层：max Σ Q^PA·T s.t. ΣT=v_ref, C≤B。"""
    keys = build_keys(P)
    by_ak, by_jk = {}, {}
    for e in keys:
        by_ak.setdefault((e[0], e[2]), []).append(e)
        by_jk.setdefault((e[1], e[2]), []).append(e)
    b_use = {kk: 0 for kk in P.b}
    prob = pulp.LpProblem('G5_qpa', pulp.LpMaximize)
    T = {e: pulp.LpVariable(f'T_{i}', lowBound=0, cat='Integer') for i, e in enumerate(keys)}
    yv = {a: pulp.LpVariable(f'y_{a}', cat='Binary') for a in P.facilities}
    zv = {pid: pulp.LpVariable(f'z_{pid}', cat='Binary') for pid in P.projects}
    S = {a: pulp.LpVariable(f'S_{a}', lowBound=0) for a in P.facilities}
    for pid, info in P.projects.items():
        prob += zv[pid] <= yv[info['facility']]
    for a in new_facs:
        prob += yv[a] == zv[P.proj_of_fac[a][0]]
    for a in P.facilities:
        for k in CT:
            add = pulp.lpSum(P.deltaC.get((pid, k), 0) * zv[pid]
                             for pid in P.proj_of_fac.get(a, []))
            if (a, k) in by_ak or P.C0.get((a, k), 0) > 0:
                prob += pulp.lpSum(T[e] for e in by_ak.get((a, k), [])) <= \
                    P.C0.get((a, k), 0) + add
    for (j, k), es in by_jk.items():
        prob += pulp.lpSum(T[e] for e in es) >= b_use[(j, k)]
        prob += pulp.lpSum(T[e] for e in es) <= P.L[(j, k)]
    for e in keys:
        prob += T[e] <= P.L[(e[1], e[2])] * yv[e[0]]
    for a in P.facilities:
        rev = pulp.lpSum((P.p[(a, k)] - P.cst[(a, k)]) * T[e]
                         for k in CT for e in by_ak.get((a, k), []))
        fix = (P.F0[a] * yv[a]
               + pulp.lpSum((P.projects[pid]['private'] + proj_fixed_f.get(pid, 0.0))
                            * zv[pid] for pid in P.proj_of_fac.get(a, [])))
        prob += S[a] >= P.Pi0[a] * yv[a] + fix - rev
    prob += (pulp.lpSum(P.projects[pid]['K'] * zv[pid] for pid in P.projects)
             + 12.0 * pulp.lpSum(S.values())) <= float(budget)
    prob += pulp.lpSum(T.values()) == int(v_ref)
    prob += pulp.lpSum(QPA[e] * T[e] for e in keys)
    t = time.time()
    prob.solve(pulp.HiGHS(msg=0, timeLimit=time_limit, gapRel=gap, threads=1))
    st = {'Optimal': 'OPTIMAL', 'Not Solved': 'FEASIBLE_TIMEOUT',
          'Infeasible': 'PROVEN_INFEASIBLE', 'Unbounded': 'UNKNOWN'}.get(
        pulp.LpStatus[prob.status], 'UNKNOWN')
    if st != 'OPTIMAL':
        return st, None, None, None, None, round(time.time() - t, 1)
    Tv = {e: int(round(T[e].value())) for e in keys}
    return (st, Tv, {a: int(round(yv[a].value())) for a in P.facilities},
            {pid: int(round(zv[pid].value())) for pid in P.projects},
            {a: round(S[a].value(), 2) for a in P.facilities},
            round(time.time() - t, 1))


# ---------------- 参数扰动（G5-C） ----------------
def perturb(P, kind, value):
    import dataclasses
    if kind == 'p_cap':
        return dataclasses.replace(P, p_cap={k: float(value) for k in CT})
    if kind == 'h_min':
        return dataclasses.replace(P, h_min=float(value))
    if kind == 'pi0_scale':
        return dataclasses.replace(
            P, Pi0={a: P.Pi0[a] * float(value) for a in P.facilities})
    raise ValueError(kind)


def save(out_dir, name, obj):
    (out_dir / f'{name}.json').write_text(
        json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding='utf-8')


def load_or_skip(out_dir, name):
    fp = out_dir / f'{name}.json'
    if fp.exists():
        return json.loads(fp.read_text(encoding='utf-8'))
    return None


# ---------------- 各实验 ----------------
def exp_A(ctx, out_dir, tl, gap):
    for dem in ctx['demands']:
        for set_tag, sites, ktag in [('P_EXP_LEGACY', [], None),
                                     ('P_EXP_NEW', ctx['m40'][dem], 'BASE_15W_PER_BED'),
                                     ('P_EXP_NEW_LOW', ctx['m40'][dem], 'LOW_COST_750K')]:
            cache = f'{set_tag}__{dem}'
            if cache not in ctx['P']:
                K_new = SCEN_K[ktag] if ktag else 0.0
                routing = ctx['routing'] if sites else pd.DataFrame(columns=['site_id'])
                ctx['P'][cache] = extend_params(ctx['P_base'], ctx['dem_file'][dem],
                                                sites, K_new, routing)
            P, ext = ctx['P'][cache]
            for B in G5_FROZEN['budget_grid_yuan']:
                tag = f'A__{set_tag}__{dem}__B{int(B//1e6)}M'
                if load_or_skip(out_dir, tag):
                    continue
                print(f'--- {tag} ---')
                t0 = time.time()
                r = g5_solve(P, ext['proj_fixed_f'], ext['new_facilities'], 'diagnostic',
                             tl, gap, budget=B)
                rec = {'exp': 'A', 'config': tag, 'project_set': set_tag, 'demand_set': dem,
                       'cost_scenario': ktag or 'N/A_LEGACY', 'budget_yuan': B, 'b_mode': 'diagnostic',
                       'time_s': round(time.time() - t0, 1)}
                if 'T' in r:
                    rec['verdict'] = 'SOLVED'
                    # §10 完整解存储：T 仅存>0项（字符串键 a|j|k）；y/z 全量；
                    # S 由 IR 等式 S=max(0,Π⁰+fix−rev) 可由 T,y,z 确定性恢复
                    rec['T_pos'] = {f'{e[0]}|{e[1]}|{e[2]}': v
                                    for e, v in r['T'].items() if v > 0}
                    rec['y'], rec['z'] = r['y'], r['z']
                    rec['solver_stages'] = r['stages']
                    rec['metrics'] = evaluate(P, r, ext['proj_fixed_f'], ext['new_facilities'],
                                              tag, ctx['geo'])
                else:
                    rec['verdict'] = r['status']
                    rec['solver_stages'] = r['stages']
                save(out_dir, tag, rec)
                m = rec.get('metrics')
                print(f"    {rec['verdict']} v={m['v'] if m else '-'} "
                      f"spend={m['spend_annual_accountingA']:,.0f}" if m else f"    {rec['verdict']}")


def exp_B(ctx, out_dir, tl, gap):
    for dem in ctx['demands']:
        D = ctx['D'][dem]
        for frac in G5_FROZEN['targets'][dem]:
            tgt = int(np.ceil(frac * D))
            for set_tag, sites, ktag in [('P_EXP_LEGACY', [], None),
                                         ('P_EXP_NEW', ctx['m40'][dem], 'BASE_15W_PER_BED'),
                                         ('P_EXP_NEW_LOW', ctx['m40'][dem], 'LOW_COST_750K')]:
                cache = f'{set_tag}__{dem}'
                if cache not in ctx['P']:
                    K_new = SCEN_K[ktag] if ktag else 0.0
                    routing = ctx['routing'] if sites else pd.DataFrame(columns=['site_id'])
                    ctx['P'][cache] = extend_params(ctx['P_base'], ctx['dem_file'][dem],
                                                    sites, K_new, routing)
                P, ext = ctx['P'][cache]
                tag = f'B__{set_tag}__{dem}__tgt{frac:g}'
                if load_or_skip(out_dir, tag):
                    continue
                print(f'--- {tag} (v_tgt={tgt}) ---')
                t0 = time.time()
                r = g5_solve(P, ext['proj_fixed_f'], ext['new_facilities'], 'diagnostic',
                             tl, gap, target=tgt)
                rec = {'exp': 'B', 'config': tag, 'project_set': set_tag, 'demand_set': dem,
                       'cost_scenario': ktag or 'N/A_LEGACY', 'target_frac': frac,
                       'v_target': tgt, 'b_mode': 'diagnostic',
                       'time_s': round(time.time() - t0, 1)}
                if 'T' in r:
                    rec['verdict'] = 'SOLVED'
                    # §10 完整解存储：T 仅存>0项（字符串键 a|j|k）；y/z 全量；
                    # S 由 IR 等式 S=max(0,Π⁰+fix−rev) 可由 T,y,z 确定性恢复
                    rec['T_pos'] = {f'{e[0]}|{e[1]}|{e[2]}': v
                                    for e, v in r['T'].items() if v > 0}
                    rec['y'], rec['z'] = r['y'], r['z']
                    rec['solver_stages'] = r['stages']
                    rec['metrics'] = evaluate(P, r, ext['proj_fixed_f'], ext['new_facilities'],
                                              tag, ctx['geo'])
                else:
                    rec['verdict'] = r['status']
                    rec['solver_stages'] = r['stages']
                save(out_dir, tag, rec)
                print(f"    {rec['verdict']} C*={r['stages']['minC'].get('Cstar_annual')}")


def exp_C(ctx, out_dir, tl, gap):
    B = G5_FROZEN['rep_budget']
    for dem in ctx['demands']:
        cache = f'P_EXP_NEW__{dem}'
        if cache not in ctx['P']:
            ctx['P'][cache] = extend_params(ctx['P_base'], ctx['dem_file'][dem],
                                            ctx['m40'][dem], SCEN_K['BASE_15W_PER_BED'],
                                            ctx['routing'])
        P0, ext = ctx['P'][cache]
        for kind, levels in [('p_cap', ['low']), ('h_min', ['low', 'high']),
                             ('pi0_scale', ['half', 'double'])]:
            for lv in levels:
                val = G5_FROZEN['C_perturb'][kind][lv]
                tag = f'C__{kind}_{lv}__{dem}__B50M'
                if load_or_skip(out_dir, tag):
                    continue
                print(f'--- {tag} ({kind}={val}) ---')
                P = perturb(P0, kind, val)
                t0 = time.time()
                r = g5_solve(P, ext['proj_fixed_f'], ext['new_facilities'], 'diagnostic',
                             tl, gap, budget=B)
                rec = {'exp': 'C', 'config': tag, 'perturb_kind': kind, 'level': lv,
                       'value': val, 'demand_set': dem, 'cost_scenario': 'BASE_15W_PER_BED',
                       'budget_yuan': B, 'b_mode': 'diagnostic',
                       'time_s': round(time.time() - t0, 1)}
                if 'T' in r:
                    rec['verdict'] = 'SOLVED'
                    # §10 完整解存储：T 仅存>0项（字符串键 a|j|k）；y/z 全量；
                    # S 由 IR 等式 S=max(0,Π⁰+fix−rev) 可由 T,y,z 确定性恢复
                    rec['T_pos'] = {f'{e[0]}|{e[1]}|{e[2]}': v
                                    for e, v in r['T'].items() if v > 0}
                    rec['y'], rec['z'] = r['y'], r['z']
                    rec['solver_stages'] = r['stages']
                    rec['metrics'] = evaluate(P, r, ext['proj_fixed_f'], ext['new_facilities'],
                                              tag, ctx['geo'])
                else:
                    rec['verdict'] = r['status']
                    rec['solver_stages'] = r['stages']
                save(out_dir, tag, rec)
                print(f"    {rec['verdict']}")


def exp_D(ctx, out_dir, tl, gap):
    for dem in ctx['demands']:
        for M in G5_FROZEN['M_grid']:
            sites = ctx['m40'][dem][:M]
            for B in G5_FROZEN['D_budgets']:
                tag = f'D__M{M}__{dem}__B{int(B//1e6)}M'
                if load_or_skip(out_dir, tag):
                    continue
                print(f'--- {tag} (sites={len(sites)}) ---')
                P, ext = extend_params(ctx['P_base'], ctx['dem_file'][dem], sites,
                                       SCEN_K['BASE_15W_PER_BED'], ctx['routing'])
                t0 = time.time()
                r = g5_solve(P, ext['proj_fixed_f'], ext['new_facilities'], 'diagnostic',
                             tl, gap, budget=B)
                rec = {'exp': 'D', 'config': tag, 'M': M, 'demand_set': dem,
                       'cost_scenario': 'BASE_15W_PER_BED', 'budget_yuan': B,
                       'b_mode': 'diagnostic', 'n_sites_offered': len(sites),
                       'n_new_ok_edges': ext['n_new_ok_edges'],
                       'time_s': round(time.time() - t0, 1)}
                if 'T' in r:
                    rec['verdict'] = 'SOLVED'
                    # §10 完整解存储：T 仅存>0项（字符串键 a|j|k）；y/z 全量；
                    # S 由 IR 等式 S=max(0,Π⁰+fix−rev) 可由 T,y,z 确定性恢复
                    rec['T_pos'] = {f'{e[0]}|{e[1]}|{e[2]}': v
                                    for e, v in r['T'].items() if v > 0}
                    rec['y'], rec['z'] = r['y'], r['z']
                    rec['solver_stages'] = r['stages']
                    rec['metrics'] = evaluate(P, r, ext['proj_fixed_f'], ext['new_facilities'],
                                              tag, ctx['geo'])
                else:
                    rec['verdict'] = r['status']
                    rec['solver_stages'] = r['stages']
                save(out_dir, tag, rec)
                print(f"    {rec['verdict']}")
        # 宽池 117 点（需 wide117 路由矩阵）
        if WIDE_CSV.exists() and G5_FROZEN.get('run_wide', True):
            man_p = DATA_P15 / 'newpoint_routing_manifest_wide117.json'
            man = json.loads(man_p.read_text(encoding='utf-8')) if man_p.exists() else {}
            if man.get('complete') and man.get('failure_rate', 1) <= 0.01:
                wide = pd.read_csv(WIDE_CSV, dtype={'site_id': str, 'community_id': str})
                sites = man['site_ids']
                B = G5_FROZEN['wide_pool_budget']
                tag = f'D__M{len(sites)}_wide__{dem}__B{int(B//1e6)}M'
                if not load_or_skip(out_dir, tag):
                    print(f'--- {tag} (宽池 sites={len(sites)}) ---')
                    P, ext = extend_params(ctx['P_base'], ctx['dem_file'][dem], sites,
                                           SCEN_K['BASE_15W_PER_BED'], wide)
                    t0 = time.time()
                    r = g5_solve(P, ext['proj_fixed_f'], ext['new_facilities'], 'diagnostic',
                                 tl, gap, budget=B)
                    rec = {'exp': 'D', 'config': tag, 'M': len(sites), 'pool': 'wide117',
                           'demand_set': dem, 'cost_scenario': 'BASE_15W_PER_BED',
                           'budget_yuan': B, 'b_mode': 'diagnostic',
                           'n_new_ok_edges': ext['n_new_ok_edges'],
                           'time_s': round(time.time() - t0, 1)}
                    if 'T' in r:
                        rec['verdict'] = 'SOLVED'
                        rec['T_pos'] = {f'{e[0]}|{e[1]}|{e[2]}': v
                                        for e, v in r['T'].items() if v > 0}
                        rec['y'], rec['z'] = r['y'], r['z']
                        rec['solver_stages'] = r['stages']
                        rec['metrics'] = evaluate(P, r, ext['proj_fixed_f'],
                                                  ext['new_facilities'], tag, ctx['geo'])
                    else:
                        rec['verdict'] = r['status']
                        rec['solver_stages'] = r['stages']
                    save(out_dir, tag, rec)
                    print(f"    {rec['verdict']}")
            else:
                print(f'[D] 宽池路由未就绪/失败率>1%（{man.get("failure_rate")}），跳过宽池')


def exp_E(ctx, out_dir, tl, gap):
    B = G5_FROZEN['rep_budget']
    for dem in ctx['demands']:
        cache = f'P_EXP_NEW__{dem}'
        if cache not in ctx['P']:
            ctx['P'][cache] = extend_params(ctx['P_base'], ctx['dem_file'][dem],
                                            ctx['m40'][dem], SCEN_K['BASE_15W_PER_BED'],
                                            ctx['routing'])
        P, ext = ctx['P'][cache]
        tag_ref = f'E__Tref__{dem}__B50M'
        ref = load_or_skip(out_dir, tag_ref)
        if ref is None:
            print(f'--- {tag_ref}（冻结 T^ref）---')
            t0 = time.time()
            r = g5_solve(P, ext['proj_fixed_f'], ext['new_facilities'], 'diagnostic',
                         tl, gap, budget=B)
            ref = {'exp': 'E', 'config': tag_ref, 'demand_set': dem,
                   'b_mode': 'diagnostic', 'budget_yuan': B,
                   'time_s': round(time.time() - t0, 1)}
            if 'T' in r:
                ref['verdict'] = 'SOLVED'
                ref['solver_stages'] = r['stages']
                ref['metrics'] = evaluate(P, r, ext['proj_fixed_f'], ext['new_facilities'],
                                          tag_ref, ctx['geo'])
                ref['T_ref'] = {f'{e[0]}|{e[1]}|{e[2]}': v for e, v in r['T'].items() if v > 0}
                ref['v_ref'] = r['stages']['stage1']['v']
            else:
                ref['verdict'] = r['status']
                ref['solver_stages'] = r['stages']
            save(out_dir, tag_ref, ref)
        if ref.get('verdict') != 'SOLVED':
            print(f'[E] {dem} T^ref 未解出，跳过 λ 扫描')
            continue
        T_ref = {tuple(k.split('|')): v for k, v in ref['T_ref'].items()}
        keyset = set(build_keys(P))
        T_ref = {e: v for e, v in T_ref.items() if e in keyset}
        v_ref = ref['v_ref']
        keys = build_keys(P)
        Q0 = {e: P.Q0(*e) for e in keys}
        delta0 = max(0.01, float(np.std(list(Q0.values()))))
        Qbar, _ = P.qma_Qbar(Q0, delta0)
        R_sig = P.R_signal(T_ref)
        V_sig = P.V_signal()
        pi_sig = P.pi_signal(R_sig, V_sig)
        for lam in G5_FROZEN['lam_grid']:
            tag = f'E__lam{lam:g}__{dem}__B50M'
            if load_or_skip(out_dir, tag):
                continue
            print(f'--- {tag} (λ={lam}) ---')
            QPA = P.QPA(Qbar, pi_sig, lam)
            t0 = time.time()
            st, Tv, _yv, _zv, _Sv, dt = qpa_inner(P, ext['proj_fixed_f'], ext['new_facilities'],
                                                  QPA, v_ref, B, tl, gap)
            rec = {'exp': 'E', 'config': tag, 'demand_set': dem, 'lam': lam,
                   'delta0': round(delta0, 6), 'v_ref': v_ref, 'budget_yuan': B,
                   'b_mode': 'diagnostic', 'inner_status': st, 'inner_time_s': dt,
                   'time_s': round(time.time() - t0, 1)}
            if Tv is not None:
                diff = sum(1 for e in keys if Tv.get(e, 0) != T_ref.get(e, 0))
                rec['metrics'] = evaluate(P, {'T': Tv, 'y': _yv, 'z': _zv},
                                          ext['proj_fixed_f'], ext['new_facilities'],
                                          tag, ctx['geo'])
                rec['metrics']['n_edges_diff_vs_Tref'] = diff
                rec['metrics']['QPA_objective'] = float(sum(QPA[e] * Tv.get(e, 0) for e in keys))
                rec['metrics']['Q0_objective'] = float(sum(Q0[e] * Tv.get(e, 0) for e in keys))
                # §10 完整解存储（T 仅存>0项；y/z/S 全量）
                rec['T_pos'] = {f'{e[0]}|{e[1]}|{e[2]}': v for e, v in Tv.items() if v > 0}
                rec['y'], rec['z'], rec['S'] = _yv, _zv, _Sv
                if lam == 0.0:
                    rec['note'] = ('λ=0 严格恢复 QMA：Q^PA 系数 (1+λπ)/(1+λ) 在 λ=0 时精确=1.0，'
                                   '即 χ·Q̄；与 T^ref 的边差为 QMA(变换质量)对 GMRA词典序(Q0)的重排效果')
            save(out_dir, tag, rec)
            m = rec.get('metrics')
            print(f"    {st} diff={m['n_edges_diff_vs_Tref'] if m else '-'} "
                  f"v={m['v'] if m else '-'}")


def exp_F(ctx, out_dir):
    """纯分析：两套需求共同候选宇宙对比（G1 comparison + G2 轨迹 + G4 结果引用）。"""
    tag = 'F__demand_interface'
    if load_or_skip(out_dir, tag):
        return
    print('--- F__demand_interface ---')
    comp_fp = ROOT / 'runs' / 'P15_G1' / 'P15_G1_comparison.json'
    comp = json.loads(comp_fp.read_text(encoding='utf-8')) if comp_fp.exists() else {}
    traj = {}
    for dem in ctx['demands']:
        f = G2 / f'greedy_trajectory_{dem}.csv'
        t = pd.read_csv(f)
        traj[dem] = {'n_candidates': int(t.shape[0]),
                     'top10': t.head(10).site_id.tolist(),
                     'top20': t.head(20).site_id.tolist(),
                     'top40': t.head(40).site_id.tolist()}
    rec = {'exp': 'F', 'config': tag,
           'g1_comparison': comp,
           'greedy_trajectories': traj,
           'm40_overlap': len(set(traj['upround']['top40']) & set(traj['total_preserving']['top40'])),
           'm40_union': len(set(traj['upround']['top40']) | set(traj['total_preserving']['top40'])),
           'note': ('共同候选宇宙对比已在 G1 comparison 预览；G5-F 政策差异解读引用 '
                    'G4/G5-A 的 LEGACY vs NEW 结果，不重复求解')}
    save(out_dir, tag, rec)
    print(f"    M40 overlap={rec['m40_overlap']} union={rec['m40_union']}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--exp', default='ALL',
                    help='A,B,C,D,E,F 逗号组合或 ALL')
    ap.add_argument('--time-limit', type=int, default=600)
    ap.add_argument('--gap', type=float, default=1e-4)
    args = ap.parse_args()
    exps = list('ABCDEF') if args.exp == 'ALL' else [x.strip().upper() for x in args.exp.split(',')]

    P_base, coords, fcoords, districts, meta = load_liuzhou(use_osm=True)
    geo = {a: {'lon': fcoords[a][0], 'lat': fcoords[a][1]} for a in fcoords}
    sites_df = pd.read_excel(G2 / 'candidate_sites.xlsx', sheet_name='candidate_sites',
                             dtype={'township_code': str})
    for r in sites_df.itertuples():
        geo[f'NEW_{r.site_id}'] = {'lon': float(r.lon), 'lat': float(r.lat),
                                   'district': r.district_name, 'site_type': 'PLANNING_PROXY'}
    routing = pd.read_csv(REAL_CSV, dtype={'site_id': str, 'community_id': str})
    man = json.loads((DATA_P15 / 'newpoint_routing_manifest.json').read_text(encoding='utf-8'))
    assert man.get('failure_rate', 1) <= 0.01, 'G4 路由失败率 >1%'
    demands = ['upround', 'total_preserving']
    dem_file = {'upround': 'demand_upround.csv', 'total_preserving': 'demand_total_preserving.csv'}
    m40 = {s: pd.read_csv(G2 / f'greedy_trajectory_{s}.csv').head(40).site_id.tolist()
           for s in demands}
    ctx = {'P_base': P_base, 'geo': geo, 'routing': routing, 'demands': demands,
           'dem_file': dem_file, 'm40': m40, 'P': {},
           'D': {s: None for s in demands}}
    for s in demands:
        dem = pd.read_csv(DATA_P15 / dem_file[s], dtype={'community_id': str})
        ctx['D'][s] = int(dem.L.sum())

    out_dir = ROOT / 'runs' / f'P15_G5_{time.strftime("%Y%m%d_%H%M%S")}'
    existing = sorted(ROOT.glob('runs/P15_G5_*'))
    if existing:
        out_dir = existing[-1]          # 断点续跑：复用最近 run 目录
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f'G5 run dir: {out_dir}; exps={exps}')

    for e in exps:
        if e == 'A':
            exp_A(ctx, out_dir, args.time_limit, args.gap)
        elif e == 'B':
            exp_B(ctx, out_dir, args.time_limit, args.gap)
        elif e == 'C':
            exp_C(ctx, out_dir, args.time_limit, args.gap)
        elif e == 'D':
            exp_D(ctx, out_dir, args.time_limit, args.gap)
        elif e == 'E':
            exp_E(ctx, out_dir, args.time_limit, args.gap)
        elif e == 'F':
            exp_F(ctx, out_dir)

    # 汇总宽表 + 冻结配置
    rows = []
    for fp in sorted(out_dir.glob('*.json')):
        if fp.name in ('G5_config_frozen.json',):
            continue
        r = json.loads(fp.read_text(encoding='utf-8'))
        if r.get('exp') in ('F',):
            continue
        row = {k: r.get(k) for k in ('exp', 'config', 'project_set', 'demand_set',
                                     'cost_scenario', 'budget_yuan', 'target_frac',
                                     'v_target', 'perturb_kind', 'level', 'value',
                                     'M', 'pool', 'b_mode', 'verdict', 'time_s')}
        # E 行存的是 inner_status（无 verdict 字段），映射到 verdict 列避免汇总表空值
        if not row.get('verdict') and r.get('inner_status'):
            row['verdict'] = r['inner_status']
        m = r.get('metrics') or r.get('summary')
        if m:
            row.update({k: m.get(k) for k in ('v', 'coverage', 'SDM', 'travel_p90',
                                              'burden_mean', 'buildK_one_time',
                                              'subsidy_annual', 'spend_annual_accountingA',
                                              'operating_cost_annual', 'n_active_projects',
                                              'n_new_activated', 'n_active_facilities')})
        rows.append(row)
    if rows:
        pd.DataFrame(rows).to_csv(out_dir / 'P15_G5_summary.csv', index=False,
                                  encoding='utf-8-sig')
    if not (out_dir / 'G5_config_frozen.json').exists():
        frozen = dict(G5_FROZEN)
        frozen.update({'run_at': pd.Timestamp.now().isoformat(),
                       'input_sha256': meta['sha256_inputs'],
                       'routing_sha256': sha256(REAL_CSV),
                       'routing_wide_sha256': sha256(WIDE_CSV) if WIDE_CSV.exists() else None,
                       'time_limit_per_stage_s': args.time_limit, 'gapRel': args.gap,
                       'solver': f'PuLP {pulp.__version__} + HiGHS threads=1'})
        (out_dir / 'G5_config_frozen.json').write_text(
            json.dumps(frozen, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(f'\n=== G5 exps={exps} 完成 -> {out_dir} ===')


if __name__ == '__main__':
    main()
