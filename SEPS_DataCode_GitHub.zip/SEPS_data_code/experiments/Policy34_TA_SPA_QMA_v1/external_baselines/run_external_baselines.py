# -*- coding: utf-8 -*-
"""Table VI 外部基线补充：
(a) base-GMRA reference —— 直接取归档 E__Tref__{dem}__B50M 的 T_ref，按 M1 同一口径
    重算 G_h、base-QMA 分数保留率；不重跑。
(b) Conv: max-volume —— 与 M1 同一约束块（含 IR/财政、b:=0、z/y、χ、容量），
    去掉 ΣT=v_ref 等式，目标换成 max ΣT；同一 solver/机器。跑两个需求口径。
输出：experiments/Policy34_TA_SPA_QMA_v1/external_baselines/
"""
import json
import platform
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pulp

IMPL = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(IMPL / 'src'))
from P34_common import get_P_variant, RUN_G5, sha256_file  # noqa: E402
from P15_G4_joint_allocation import evaluate, native_info, build_keys, CT  # noqa: E402
import model_io  # noqa: E402
model_io.CARE_TYPES = ('NH', 'BK', 'WELLNESS')

OUT = Path(__file__).resolve().parent
for s in ('solutions', 'results'):
    (OUT / s).mkdir(parents=True, exist_ok=True)

B50M = 50_000_000.0
GAP = 1e-4
TL = 600
DEMS = ('upround', 'total_preserving')
STATUS = {'Optimal': 'OPTIMAL', 'Not Solved': 'FEASIBLE_TIMEOUT',
          'Infeasible': 'PROVEN_INFEASIBLE', 'Unbounded': 'UNKNOWN'}
RUN_ID = f'EXTERNAL_BASELINES__{time.strftime("%Y%m%d_%H%M%S")}'


def tgt_ctx(P, tref):
    keys = build_keys(P)
    keyset = set(keys)
    T_ref = {tuple(k.split('|')): int(v) for k, v in tref['T_ref'].items()
             if tuple(k.split('|')) in keyset}
    Q0 = {e: P.Q0(*e) for e in keys}
    delta0 = max(0.01, float(np.std(list(Q0.values()))))
    Qbar, _ = P.qma_Qbar(Q0, delta0)
    R_sig = P.R_signal(T_ref)
    pi_sig = P.pi_signal(R_sig, P.V_signal())
    roles = [r for r in P.L if P.L[r] > 0]
    pis = sum(pi_sig.get(r, 0.0) for r in roles)
    omega = {r: (pi_sig.get(r, 0.0) / pis if pis > 0 else 1.0 / len(roles)) for r in roles}
    h = {r: 0.5 * P.L[r] for r in roles}
    return keys, T_ref, Qbar, omega, h, delta0


def metrics_ext(P, T, Qbar, omega, h):
    N = {}
    for e, t in T.items():
        if t:
            N[(e[1], e[2])] = N.get((e[1], e[2]), 0) + t
    G_h = sum(omega[r] * max(0.0, h[r] - N.get(r, 0)) for r in h)
    score = sum(Qbar[e] * t for e, t in T.items())
    return G_h, score


def solve_maxvol(P, ext, keys, tref_v, budget, tl, gap):
    """M1 约束块去掉 ΣT=v_ref；目标 max ΣT。"""
    prob = pulp.LpProblem('CONV_MAXVOL', pulp.LpMaximize)
    T = {e: pulp.LpVariable(f'T_{i}', lowBound=0, cat='Integer') for i, e in enumerate(keys)}
    y = {a: pulp.LpVariable(f'y_{a}', cat='Binary') for a in P.facilities}
    z = {pid: pulp.LpVariable(f'z_{pid}', cat='Binary') for pid in P.projects}
    S = {a: pulp.LpVariable(f'S_{a}', lowBound=0) for a in P.facilities}
    for pid, info in P.projects.items():
        prob += z[pid] <= y[info['facility']]
    for a in ext['new_facilities']:
        prob += y[a] == z[P.proj_of_fac[a][0]]
    by_ak, by_jk = {}, {}
    for e in keys:
        by_ak.setdefault((e[0], e[2]), []).append(e)
        by_jk.setdefault((e[1], e[2]), []).append(e)
    for a in P.facilities:
        for k in CT:
            add = pulp.lpSum(P.deltaC.get((pid, k), 0) * z[pid]
                             for pid in P.proj_of_fac.get(a, []))
            if (a, k) in by_ak or P.C0.get((a, k), 0) > 0:
                prob += pulp.lpSum(T[e] for e in by_ak.get((a, k), [])) <= \
                    P.C0.get((a, k), 0) + add
    for (j, k), es in by_jk.items():
        prob += pulp.lpSum(T[e] for e in es) >= 0
        prob += pulp.lpSum(T[e] for e in es) <= P.L[(j, k)]
    for e in keys:
        prob += T[e] <= P.L[(e[1], e[2])] * y[e[0]]
    for a in P.facilities:
        rev = pulp.lpSum((P.p[(a, k)] - P.cst[(a, k)]) * T[e]
                         for k in CT for e in by_ak.get((a, k), []))
        fix = (P.F0[a] * y[a] + pulp.lpSum(
            (P.projects[pid]['private'] + ext['proj_fixed_f'].get(pid, 0.0)) * z[pid]
            for pid in P.proj_of_fac.get(a, [])))
        prob += S[a] >= P.Pi0[a] * y[a] + fix - rev
    prob += (pulp.lpSum(P.projects[pid]['K'] * z[pid] for pid in P.projects)
             + 12.0 * pulp.lpSum(S.values())) <= float(budget)
    prob += pulp.lpSum(T.values())
    t = time.time()
    prob.solve(pulp.HiGHS(msg=0, timeLimit=tl, gapRel=gap, threads=1))
    dt = round(time.time() - t, 1)
    st = STATUS.get(pulp.LpStatus[prob.status], 'UNKNOWN')
    ni = native_info(prob)
    rec = {'status': st, 'native': ni, 'wall_s': dt, 'v_ref': int(tref_v)}
    if ni.get('objective') is None:
        rec['note'] = 'no incumbent'
        return None, rec
    Tv = {e: int(round(T[e].value())) for e in keys}
    rec['v_solution'] = int(sum(Tv.values()))
    if sum(Tv.values()) <= 0:
        rec['note'] = 'zero incumbent — rejected'
        return None, rec
    rec['y'] = {a: int(round(y[a].value())) for a in P.facilities}
    rec['z'] = {pid: int(round(z[pid].value())) for pid in P.projects}
    rec['S_raw'] = {a: float(S[a].value()) for a in P.facilities}
    rec['v_matches_ref'] = bool(sum(Tv.values()) == int(tref_v))
    return Tv, rec


def accounting(P, ext, T, z, y):
    K = float(sum(P.projects[p]['K'] * z.get(p, 0) for p in P.projects))
    D, S = {}, {}
    for a in P.facilities:
        rev = sum((P.p[(a, k)] - P.cst[(a, k)]) * T.get((a, j, k), 0)
                  for j in P.communities for k in CT)
        fix = (P.F0[a] * y.get(a, 0) + sum(
            (P.projects[pid]['private'] + ext['proj_fixed_f'].get(pid, 0.0)) * z.get(pid, 0)
            for pid in P.proj_of_fac.get(a, [])))
        D[a] = P.Pi0[a] * y.get(a, 0) + fix - rev
        S[a] = max(0.0, D[a])
    return {'K_z_yuan': K, 'subsidy_annual_yuan': 12.0 * sum(S.values()),
            'spend_first_year_yuan': K + 12.0 * sum(S.values()),
            'S_monthly_raw': S}


def main():
    m1 = pd.read_csv(IMPL / 'experiments' / 'Policy34_TA_SPA_QMA_v1' / 'stage_C' /
                     'results' / 'stage_C_summary_full.csv')
    rows = []
    for dem in DEMS:
        P, ext = get_P_variant('NEW', dem)
        tref = json.load(open(RUN_G5 / f'E__Tref__{dem}__B50M.json', encoding='utf-8'))
        v_ref = int(tref['v_ref'])
        keys, T_ref, Qbar, omega, h, delta0 = tgt_ctx(P, tref)
        m1row = m1[(m1.demand_set == dem) & (m1.method == 'M1_BASE_QMA')].iloc[0]
        m1score = float(m1row['base_qma_score'])
        m1G = float(m1row['G_h'])

        # (a) base-GMRA = archived T_ref
        G_a, score_a = metrics_ext(P, T_ref, Qbar, omega, h)
        spend_a = tref['metrics']['spend_annual_accountingA']
        rows.append({
            'row': 'base_GMRA_reference', 'demand_set': dem, 'v': v_ref,
            'G_h': G_a, 'M1_G_h': m1G, 'dG_h_vs_M1': G_a - m1G,
            'base_qma_score': score_a, 'M1_base_qma_score': m1score,
            'retention_pct': 100.0 * score_a / m1score,
            'spend_first_year': spend_a, 'spend_M_CNY': spend_a / 1e6,
            'status': 'ARCHIVED', 'wall_s': None,
            'source': f'E__Tref__{dem}__B50M.json T_ref',
            'note': '四阶段 base GMRA（max-flow 主准则、Q0、无 Q̄ 变换）；指标按 M1 同口径重算',
        })

        # (b) Conv max-volume
        print(f'[CONV] {dem} 开始', flush=True)
        T_b, rec_b = solve_maxvol(P, ext, keys, v_ref, B50M, TL, GAP)
        if T_b is None:
            rows.append({'row': 'Conv_max_volume', 'demand_set': dem, 'v': None,
                         'status': rec_b['status'], 'wall_s': rec_b['wall_s'],
                         'note': rec_b.get('note')})
            continue
        y_b, z_b = rec_b['y'], rec_b['z']
        G_b, score_b = metrics_ext(P, T_b, Qbar, omega, h)
        acc = accounting(P, ext, T_b, z_b, y_b)
        met = evaluate(P, {'T': T_b, 'y': y_b, 'z': z_b}, ext['proj_fixed_f'],
                       ext['new_facilities'], 'CONV_MAXVOL', {})
        sol = {'run_id': RUN_ID, 'demand_set': dem, 'v': rec_b['v_solution'],
               'T_pos': {f'{e[0]}|{e[1]}|{e[2]}': v for e, v in T_b.items() if v},
               'y': y_b, 'z': z_b, 'S_monthly_raw': acc['S_monthly_raw'],
               'metrics': met, 'G_h': G_b, 'base_qma_score': score_b,
               'retention_pct': 100.0 * score_b / m1score,
               'stage': rec_b}
        (OUT / 'solutions' / f'conv_max_volume__{dem}__B50M.json').write_text(
            json.dumps(sol, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
        rows.append({
            'row': 'Conv_max_volume', 'demand_set': dem, 'v': rec_b['v_solution'],
            'G_h': G_b, 'M1_G_h': m1G, 'dG_h_vs_M1': G_b - m1G,
            'base_qma_score': score_b, 'M1_base_qma_score': m1score,
            'retention_pct': 100.0 * score_b / m1score,
            'spend_first_year': acc['spend_first_year_yuan'],
            'spend_M_CNY': acc['spend_first_year_yuan'] / 1e6,
            'status': rec_b['status'], 'wall_s': rec_b['wall_s'],
            'source': 'new run: same M1 constraint block, objective=max ΣT, no ΣT=v',
            'note': ('max-volume 最优面不唯一；数值为 HiGHS threads=1 返回的最大服务量解'
                     if rec_b['status'] != 'OPTIMAL'
                     else 'max-volume 最优面不唯一；数值为 HiGHS threads=1 返回的最优解'),
        })
        m1G_m = met.get('SDM')
        print(f"[CONV] {dem} v={rec_b['v_solution']} G_h={G_b:.6f} "
              f"ret={100*score_b/m1score:.2f}% spend={acc['spend_first_year_yuan']:.0f} "
              f"{rec_b['status']} {rec_b['wall_s']}s", flush=True)

    df = pd.DataFrame(rows)
    df.to_csv(OUT / 'results' / 'external_baselines_table_VI.csv', index=False,
              encoding='utf-8-sig')
    frozen = {'run_id': RUN_ID, 'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
              'solver': f'PuLP {pulp.__version__} + HiGHS threads=1 gapRel={GAP} TL={TL}s',
              'machine': {'platform': platform.platform(),
                          'processor': platform.processor(), 'cpu': __import__('os').cpu_count()},
              'definitions': {
                  'base_GMRA': 'Tref（E__Tref，四阶段 max-flow/Q0，无 Q̄）归档解',
                  'Conv_max_volume': 'M1 同一约束块去掉 ΣT=v_ref，目标 max ΣT，其余不变'},
              'G_h_formula': 'Σ_r ω_r max(0,h_r−N_r)，ω=π/Σπ (L>0 roles)，h=0.5L',
              'retention_formula': 'Σ Q̄·T / M1 Σ Q̄·T × 100'}
    (OUT / 'results' / 'external_baselines_config.json').write_text(
        json.dumps(frozen, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(df.to_string(), flush=True)


if __name__ == '__main__':
    main()
