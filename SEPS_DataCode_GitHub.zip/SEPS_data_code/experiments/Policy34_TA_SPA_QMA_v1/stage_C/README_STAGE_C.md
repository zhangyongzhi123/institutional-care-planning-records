# TA-SPA-QMA 阶段C 报告（TA_SPA_STAGE_C_C2__20261010_155854）

- 协议：TA-SPA-QMA-Protocol-v1.0；阶段：C/C2（第三层方法贡献受控验证）
- 授权：GPT6.1 批准 2026-10-10（预注册、独立、可撤回；禁止结果导向调参）
- C1 前提：ALL_PASS=True（2026-10-10，Example A 全枚举核验 M1-M6）
- 配置：UPROUND/NEW/B=50M/b=0/v=13033；
  TOTAL-PRESERVING/NEW/B=50M/b=0/v=12625
- 六方法：M1 Base-QMA / M2 Original PA-QMA / M3 TA-SPA-global / M4 TA-SPA-reachable /
  M5 Target-constrained QMA（两阶段词典序）/ M6 Target-only diagnostic
- λ∈{0,1,2}（0 为 sanity check；主分析用 λ∈{1,2}）
- 参考信号：Policy34 正式 T^ref（E__Tref JSON）→ R/V/π
- 求解：HiGHS threads=1, gapRel=0.0001, TL=600s；共 24 次求解
  （24 个有 incumbent，0 个无 incumbent）
- M4 reachable 角色：1959 个（UPROUND），
  2004 个（TP）
  edge_roles = reachable: True
- M5 两阶段：Stage1 max H(T) → Stage2 max ΣQ̄·T s.t. H=H1*
  （bound closed 精确固定；time-limit 标注 bound-aware）

## 产出文件
- results/stage_C_summary.csv — 主结果表（22 字段）
- results/stage_C_summary_full.csv — 完整汇总（含 global/reachable 双口径 H_T/G_h）
- results/stage_C_constraints_audit.csv — 约束逐项审计
- results/pa_vs_G5E_reconciliation.csv — M2 PA-QMA 与 Policy34 G5-E 对账
- results/target_only_upper_bound_check.csv — M6 Target-only 上界核验
- stage_C_claim_table.csv — 预注册成功标准对照
- stage_C_method_definition.json — 六方法数学定义
- config/stage_C_config_frozen.json — 冻结配置快照
- stage_C_audit.json — 审计总报告
- stage_C_manifest.csv — 文件清单（逐文件 SHA-256）
- solutions/ — 每方法完整解 JSON
- logs/ — 每方法原生日志
- code_snapshot/ — 主脚本快照

## 停止规则
- 停在 C 阶段闸门，等待审查
- 不回填 Policy34 正文/摘要/VII/Conclusion/Fig.8
- 不自动扩大预算/候选池/λ网格
- 不将 time-limit 返回解称为精确最优
- 不将无 incumbent 标记为不可行
- 不同方法 objective 不直接比较异尺度

## C2 结果摘要（audit v2，STAGE_C_AUDIT_V2__20261011_114548；不重解）

审计状态：24 个方法配置（26 次 HiGHS 调用：M5 每配置 Stage1+Stage2 两次）、全部有
incumbent、24/24 硬约束审计通过、M2 与 Policy34 G5-E 6/6 OBJECTIVE_MATCH。

**全部跨方法指标差异均为"已审计返回分配之间的描述性比较"，不是精确最优解间的优势
证明；gap 仅约束各方法自己的优化目标，不认证外部政策覆盖指标。禁止 outperforms。**

### M5 Target-constrained vs M1 Base-QMA（本轮主要发现）
| 指标 | UPROUND | TOTAL-PRESERVING |
|---|---|---|
| 目标内加权服务量 H_T 提高 | +31.18% | +29.39% |
| 加权目标缺口 G_h 下降 | −11.27% | −10.97% |
| 达标角色数增加 | +126 | +160 |
| 基础 QMA 得分变化 | −1.86%（−183.2） | −1.82%（−174.2） |
| 首年公共支出 | −40,200 元 | +600 元 |
| P90 旅行时间 | 29.8 min 不变 | 29.8 min 不变 |
| 平均负担 | 下降 | 下降 |
| SDM | 0.46432→0.43035 | 0.45633→0.42308 |

解释：目标优先规则以约 1.8% 基础资格得分换取约 11% 加权目标缺口下降，公共支出变化小。
M5 是**目标优先、基础资格第二的 bound-aware 两阶段模式**，与 M3 加性 TA-SPA 是
目标感知政策分配层的两种独立决策模式，M5 结果不得写成原 M3 已实现的性能。

### 求解器认证边界（audit v2 修正）
- **两配置 M5 均为 BOUND_AWARE_LEXICOGRAPHIC**：Stage1 独立原生状态/边界/gap 在正式
  JSON 中 NOT_RETAINED（运行时未写盘，不反推不重跑）；仅 H1_incumbent（Stage2 实际
  采用下界）留存。同批次 M6 同模型独立日志 incumbent 与 H1 差 <1e-12，仅作旁证
  （M6 gap 非零，不认证）。TP Stage2 kOptimal gap=1.57e-6 只认证 Stage2 基础QMA目标，
  **不认证 Stage1 H 精确最优**；UP Stage2 kTimeLimit。
- **M5 Stage2 的 w 不要求逐项饱和**（w 不再被最大化）：三条件审计通过——
  (a) w≤min(N,h) 无上界违例；(b) Σωw≥H1_inc；(c) 真实 H(T)≥H1_inc。
  max|w−min(N,h)|：UP 0.0891、TP 0.00374（非错误）。
- M4 λ=1：UP 两端（M1/M4）均 kTimeLimit；TP 两端为容差内 kOptimal（非零 gap）——
  均只能称返回解比较，无"双端认证"。
- M3 TP λ=1 的缺口增加（+0.0033）：M1 返回解代入 M3 λ=1 目标 = 9551.2695，
  高于 M3 返回 incumbent 9550.6855 且 ≤ 所报 bound 9551.6239 ⇒ 属容差终止下的
  返回解事实，不能称精确优化机制必然失败。

### M4 = M3 有效 λ 重标定（权重尺度敏感性）
本实例 reachable 角色 = edge 角色（恒等严格成立，不可达角色 N≡0），故
H_reach(T)=H_global(T)/α，α=0.4600(UP)/0.4730(TP)；M4 目标等价于 M3 使用
λ_eff=λ/α：λ=1→2.174(UP)/2.114(TP)，λ=2→4.347/4.229。
全部 6 个已保存 M4 解恒等差 <1e-9（results/m4_rescaling_equivalence.csv）。
M4 定位为归一化/权重尺度敏感性，不包装为新优先级结构。

### 方法贡献组织（第三层）
目标感知政策分配层在原实施可行域内提供两种政策—资格权衡模式：
M3 加性饱和奖励 / M4 权重尺度敏感性 / M5 目标优先两阶段（bound-aware）；
M2 原乘法 PA-QMA 对照（同 λ 下政策拉动更强：M4 G_h 比 M2 高 0.034–0.040，
但 M4 base_qma 高 26–34）；M6 纯目标诊断对照。实质贡献：显式区分 b/h/L、
达标后奖励饱和、可解释的政策—资格决策模式、两代表配置的实际幅度权衡、硬约束全保持。

### v2 新增/修订证据文件
- stage_C_claim_table.csv（v2：百分比 + 描述性标签 + 措辞修正）
- results/m4_rescaling_equivalence.csv（α 恒等验证）
- results/m5_stage2_w_audit_{upround,total_preserving}.csv（w 三条件）
- solutions/ 两个 M5 JSON 追加 stage_record_retention_v2（NOT_RETAINED 明示）
- stage_C_audit.json → audit_v2
- stage_C_manifest.csv 排除自身；results/stage_C_manifest_verification_v2.json 逐行验证
