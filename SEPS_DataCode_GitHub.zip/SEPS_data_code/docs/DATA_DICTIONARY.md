# Data dictionary

## Inputs

`data/raw/eldercare_inputs.xlsx` sheets: `communities`, `demand`, `facilities`,
`capacity_price`, `travel_edges`, `projects`, `provenance`.
Key fields: `community_id`, `facility_id`, `care_type`, `L`, `guarantee_b`,
`capacity_C0`, `price_p`, `unit_cost_c`, `quality_H`, `travel_min`,
`public_cost_K`, `private_cost`, `delta_capacity`.

`data/raw/eldercare_inputs_A.xlsx` is the same schema for the micro instance.

`data/P15/demand_*.csv`: `community_id`, `care_type`, `L` under each demand
specification. `travel_edges_newpoints_amap.csv`: `community_id`,
`facility_id`, `travel_min`.

## Results

`runs/E3E4/e3e4_raw.csv`: `scale`, `seed`, `method`, `vmax`, `time_s`, `status`,
`peak_mem_mb`, `coverage`, `SDM`, `dist`, `Q0_avg`.
`runs/E3E4/e3e4_summary.csv`: `scale`, `method`, `n`, `cov_mean`, `cov_std`,
`SDM_mean`, `SDM_std`, `time_mean`, `time_p90`, `mem_mean`.

`experiments/.../stage_C/results/stage_C_summary.csv`: `demand_set`, `method`,
`lambda`, `v`, `H_T`, `H_upper`, `G_h`, `n_targets_met`, `n_targets_unmet`,
`worst_role_coverage`, `base_qma_score`, `SDM`, `travel_p90`, `burden_mean`,
`subsidy_annual`, `spend_first_year`, `native_status`, `incumbent`, `dual_bound`,
`gap`, `wall_s`, `constraints_all_pass`.

`experiments/.../external_baselines/results/external_baselines_table_VI.csv`:
`row`, `demand_set`, `v`, `G_h`, `M1_G_h`, `dG_h_vs_M1`, `base_qma_score`,
`M1_base_qma_score`, `retention_pct`, `spend_first_year`, `spend_M_CNY`, `status`,
`wall_s`, `source`.

`runs/scenarios/P15_G5_summary.csv`: `exp`, `config`, `project_set`, `demand_set`,
`cost_scenario`, `budget_yuan`, `v`, `coverage`, `SDM`, `travel_p90`,
`burden_mean`, `buildK_one_time`, `subsidy_annual`, `spend_annual_accountingA`.

`runs/E0/E0A_feasibility.json`: per-instance rows with `total_b`, `total_cap`,
`m3_maxflow_value`, `m3_required`, `starved_communities`, `unlimited_budget_milp_status`.
`runs/E0/E0B_subsidy.json`: per-combination `B_crit_enum`, `psi_distribution_sorted_unique`,
`argmin_allocations`, `threshold_tests` (each with `B`, `status`, `pass`).

`experiments/.../stage_C/logs/*.json`: `config`, `run_id`, `wall_s`,
`native{model_status, objective, bound, gap}`, `wrapper_status`, `certification`.
`experiments/.../stage_C/solutions/*.json`: returned `T_pos`, `y`, `z`, `S_raw`.

`experiments/.../stage_A/ta_spa_enumeration.csv` and `stage_C/c1/stage_C1_enumeration.csv`:
`combo_id`, `z`, `y`, `v`, `T`, per-community allocations, and per-method scores
(`BASE_QMA`, `PA_QMA_lam*`, `TA_SPA_*`, `TARGET_ONLY_lam*`).
