# STATUS NOTES — Solver-status terminology and file-to-claim map

Companion note to the accompanying data and code archive. This note only indexes the archive; it does not modify the manuscript, the Supplementary Information, the cover letter, the title page, or the highlights.

## 1. Three distinct status layers

The archive contains three batches whose status labels are **not interchangeable**.

**(a) Synthetic E3E4 batch — `E3E4/`**
180 runs = 30 instances × 6 variants (GMRA, QMA, PA-QMA lambda=1, PA-QMA lambda=2, No-R, No-V). These six variants are ablation variants of the synthetic study; they are **not** the six allocation modes M1–M6 used in the regional C2 comparison.
The `status` value `Optimal` in `e3e4_raw.csv` is a **PuLP wrapper label**. It cannot distinguish native `kOptimal` from `kTimeLimit`, and no solver manifest was archived for this batch. Reported metrics describe returned feasible plans, possibly time-limit incumbents. See the Supplementary Information, Table S1 discussion, and Manuscript Sec. VII-A.

**(b) Feasibility and threshold verification JSONs — `E0A/`**
`run_stats.status = OPTIMAL` and `threshold_tests.status = PROVEN_INFEASIBLE` are labels written by the verification script, not native HiGHS enumeration states. Refer to them as "solver status labels as recorded by the PuLP wrapper / verification script". The Supplementary Information does not call this batch native.

**(c) Target-layer C2 batch — `C2/`**
This is the batch to which the "native solver records" wording in the Supplementary Information ("Verification and solver records", C2 paragraph) and in Manuscript Secs. VII-A, VII-E refers.

- `stage_C/` holds **24 method configurations** (12 per demand specification: M1 ×1, M2/M3/M4 ×3 each, M5 ×1, M6 ×1) and **26 solver calls** (each M5 configuration invokes two stages). `logs/` contains 24 configuration-level records with native fields, `solutions/` contains the returned `T_pos`, `y`, `z`, `S_raw`, and `stage_C_audit.json` records `n_solver_calls = 26`.
- The native distribution across these 24 configurations is 14 `kOptimal` / 10 `kTimeLimit`. The Supplementary Information does **not** report this count, so there is no discrepancy.
- `E10_reconciliation/` holds the **ten multiplicative-priority allocations** re-run under a frozen configuration. This is the batch supporting "eight terminate as native kOptimal within tolerance and two reach a time limit with an incumbent and bound" (8 / 2, `REPRODUCED_BITWISE`). **Do not read the 8/2 figures as a count over the 24 configurations.**
- M5 Stage 1: `solutions/*M5*` carry `stage_record_retention_v2.stage1_native = NOT_RETAINED` and only `H1_lower_bound`. This is by design, not a missing attachment. The Supplementary Information and Manuscript Table VI note already state it; no reconstruction or re-run was performed.
- No 26-row call-level table exists. The Supplementary Information claims 24 configuration-level records plus an audit note of 26 solver calls; it does not claim 26 individual call rows.

## 2. Provenance files

- `E0A/provenance.csv` is the original archive record. Its first column has been rewritten to `./filename` for portability; the hash column and all referenced file contents are unchanged.
- `E3E4/provenance.csv` was generated when this archive was assembled, because the E3E4 run directory contained only `e3e4_raw.csv` and `e3e4_summary.csv`. Its four SHA-256 prefixes (`2a392e8b`, `f4231100`, `9739f0ce`, `4d2f1e60`) were recomputed directly from the files and match the four prefixes listed in the Supplementary Information. This is the "accompanying provenance record" referenced there and should be kept in the archive.
- `run_E3E4.py` and `solvers.py` in `E3E4/` are the `src/` originals (`9739f0ce` / `4d2f1e60`). Other copies of `solvers.py` in the working tree belong to different batches and are not included.
- `source_E0A_feasibility.json` is byte-identical to `E0A_feasibility.json`; one copy is retained to avoid duplication.

## 3. File-to-claim map (additive to `README.txt`)

| Claim | Archive location |
|---|---|
| Supplementary Information, synthetic-batch four source-file hashes | `E3E4/` |
| SI Table S1 discussion: 180 runs, wrapper labels, no manifest | `E3E4/e3e4_raw.csv` |
| SI Tables S1–S2: SDM, No-R / No-V at lambda=1 | `E3E4/e3e4_summary.csv` |
| SI C2 paragraph: 24 configurations / 26 solver calls | `C2/stage_C_audit.json`, `C2/logs/`, `C2/solutions/` |
| SI C2 paragraph and Manuscript Sec. VII-E: ten re-runs, 8 / 2 | `C2/E10_reconciliation/` |
| SI target-layer enumeration tables | `ENUM/` |
| SI primal–dual bounds; M5 Stage-1 NOT_RETAINED | `C2/solutions/`, `C2/logs/` |
| SI E0-A 29-row three-way cross-check | `E0A/E0A_29rows_detail.csv`, `E0A/E0A_feasibility.json` |
| Title Page "Data availability"; Cover Letter "accompanying data and code archive" | this archive |
